// Reusable content-collection helpers for consumers of @codeyam/cms.
//
// A consumer defines its OWN concrete collections in its `src/content/config.ts`
// (Astro requires that file to live in the consuming project). What the package
// provides here is the shared, site-agnostic scaffolding those definitions are
// built from:
//
//   - `seoFields` — the universal SEO & Social override fields the admin
//     dashboard knows how to edit, spread into every collection schema.
//   - `draftField` — the publish flag the admin's Draft toggle writes, spread
//     the same way, plus `publishedEntries` to act on it when rendering.
//   - `collectionLoader` — a `glob` loader whose `base` is redirected through
//     the same content-root resolution the engine uses, so codeyam scenario
//     seeding writes into the `.codeyam/tmp` sandbox instead of committed source.
//
// Example consumer `src/content/config.ts`:
//
//   import { defineCollection, z } from 'astro:content';
//   import { seoFields, draftField, collectionLoader } from '@codeyam/cms/content';
//
//   const blog = defineCollection({
//     loader: collectionLoader('blog'),
//     schema: z.object({ title: z.string(), date: z.coerce.date(), ...draftField, ...seoFields }),
//   });
//   export const collections = { blog };
//
// …then filter at every render site (listings AND `getStaticPaths`):
//
//   import { publishedEntries } from '@codeyam/cms/content';
//   const posts = publishedEntries(await getCollection('blog'));
import { z } from 'astro:content';
import { glob } from 'astro/loaders';
import * as path from 'path';
import { resolveContentRoot } from './lib/contentRoot';

// The publish filter itself is framework-free (no `astro:content` import) so it
// stays unit-testable without an Astro project; re-exported here because this
// module is the consumer-facing surface.
export {
  isPublished,
  publishedEntries,
  selectPublished,
  type DraftableEntry,
  type PublishedEntriesOptions,
} from './lib/publishFilter';

/**
 * The universal SEO & Social override fields, spread into every collection's
 * schema. All optional — the rendered page resolves the effective value from
 * these, then the entry's own fields, then the site defaults. Kept as one shared
 * object so a consumer's schemas mirror the single field list the admin editor
 * renders.
 */
export const seoFields = {
  seoTitle: z.string().optional(),
  seoDescription: z.string().optional(),
  socialImage: z.string().optional(),
  canonicalUrl: z.string().optional(),
};

/**
 * The publish flag every collection carries, spread into its schema the same way
 * `seoFields` is. The admin appends a Draft toggle to every collection
 * (`DRAFT_FIELD`) and writes `draft: true` when it is ticked; without this field
 * in the consumer's schema Zod silently strips the key, so the toggle has no
 * effect on the rendered site and no build error says so.
 *
 * Optional, and **absent means published** — the CMS never writes `draft: false`
 * (`formValuesToData` omits the key, `buildUnarchiveChange` clears it), so
 * adopting this field changes nothing about content a site already has.
 *
 * Declaring the field only makes the flag survive into `entry.data`; use
 * `publishedEntries` to actually act on it when rendering.
 */
export const draftField = {
  draft: z.boolean().optional(),
};

/**
 * Build a content-layer `glob` loader for a collection whose `base` directory is
 * resolved through the engine's content-root order (env → `.codeyam/tmp` sidecar
 * → committed `src/content`). Use this in place of a bare `glob({ base: ... })`
 * so codeyam scenario seeding stays sandboxed.
 */
export function collectionLoader(collection: string) {
  const contentRoot = resolveContentRoot();
  return glob({ pattern: '**/*.{md,mdx}', base: path.join(contentRoot, collection) });
}
