// Pure, side-effect-free core of the `codeyam-cms integrate` command.
//
// Everything here is string/data in, string/data out — no filesystem, no
// process — so it unit-tests directly. The CLI (`codeyam-cms.js`) wraps these
// with the fs/IO it needs. Keeping the tricky bits (arg parsing, the textual
// astro.config edit) pure is what makes the "integrate" behavior verifiable.

/** Parse `process.argv`-style tokens into `{ _: positional, flags: {...} }`. */
export function parseArgs(argv) {
  const args = { _: [], flags: {} };
  for (const a of argv) {
    if (a.startsWith('--')) {
      const [k, v] = a.slice(2).split('=');
      args.flags[k] = v === undefined ? true : v;
    } else {
      args._.push(a);
    }
  }
  return args;
}

const IMPORT_LINE = "import codeyamCms from '@codeyam/cms';";

/**
 * Given the text of an `astro.config.*`, return the text with the codeyamCms
 * import added and `codeyamCms()` pushed into the `integrations: []` array.
 *
 * Returns `{ source, changed, manual }`:
 *  - `changed: false, manual: false` — already integrated, nothing to do.
 *  - `changed: true` — `source` is the edited config to write back.
 *  - `manual: true` — the config shape was too unusual to edit safely; the
 *    caller should tell the user to add the two lines by hand rather than risk
 *    corrupting their config.
 */
export function patchAstroConfigSource(input) {
  let src = input;
  const alreadyImported = src.includes('@codeyam/cms');
  const alreadyEnabled = /codeyamCms\s*\(/.test(src);

  if (alreadyImported && alreadyEnabled) {
    return { source: src, changed: false, manual: false };
  }

  // 1. Add the import after the last top-level import statement.
  if (!src.includes(IMPORT_LINE)) {
    const importRe = /^import .*$/gm;
    let lastImportEnd = 0;
    let m;
    while ((m = importRe.exec(src)) !== null) {
      lastImportEnd = m.index + m[0].length;
    }
    if (lastImportEnd > 0) {
      src = `${src.slice(0, lastImportEnd)}\n${IMPORT_LINE}${src.slice(lastImportEnd)}`;
    } else {
      src = `${IMPORT_LINE}\n${src}`;
    }
  }

  // 2. Push codeyamCms() into the integrations array (or create one).
  if (/integrations\s*:\s*\[/.test(src)) {
    src = src.replace(/integrations\s*:\s*\[/, (match) => `${match}codeyamCms(), `);
  } else if (/defineConfig\s*\(\s*\{/.test(src)) {
    src = src.replace(/defineConfig\s*\(\s*\{/, (match) => `${match}\n  integrations: [codeyamCms()],`);
  } else {
    return { source: input, changed: false, manual: true };
  }

  return { source: src, changed: true, manual: false };
}

/**
 * Build the ordered list of `{ pattern, file }` admin routes for a given base
 * segment. Mirrors the integration's own route map so the CLI can report what a
 * consumer will get. `base` is normalized (leading/trailing slashes stripped).
 */
export function adminRoutePatterns(base = 'admin') {
  const b = base.replace(/^\/+|\/+$/g, '');
  const rel = [
    { pattern: '', file: 'index.astro' },
    { pattern: 'settings', file: 'settings.astro' },
    { pattern: 'editors', file: 'editors.astro' },
    { pattern: 'publish', file: 'publish.astro' },
    { pattern: 'media', file: 'media/index.astro' },
    { pattern: 'new', file: 'new/index.astro' },
    { pattern: 'new/[collection]', file: 'new/[collection].astro' },
    { pattern: 'collections/new', file: 'collections/new.astro' },
    { pattern: '[collection]', file: '[collection]/index.astro' },
    { pattern: '[collection]/[entry]', file: '[collection]/[entry].astro' },
  ];
  return rel.map(({ pattern, file }) => ({
    pattern: pattern ? `/${b}/${pattern}` : `/${b}`,
    file,
  }));
}
