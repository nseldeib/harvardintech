// Browser-safe markdown → HTML for the live entry preview.
//
// The public site renders posts with Astro's build-time `render()` / `<Content />`,
// which can't run in the editor's client island. This wraps `micromark` — the
// CommonMark engine Astro's own markdown pipeline is built on — plus the GFM
// extension (tables, strikethrough, task lists, autolinks) so the preview matches
// Astro's default GFM. Raw embedded HTML is left DISABLED (micromark's safe
// default, `allowDangerousHtml` unset), so a stray `<script>` in the body renders
// as escaped text rather than executing in the admin origin. Framework-free, so it
// unit-tests directly and runs in the browser island.
import { micromark } from 'micromark';
import { gfm, gfmHtml } from 'micromark-extension-gfm';

/**
 * Render an entry's markdown body to an HTML string. An empty/whitespace-only
 * body yields '' so the preview can show its own empty-state rather than a blank
 * block. CommonMark + GFM; raw HTML is escaped, not executed.
 */
export function renderMarkdown(body: string): string {
  if (!body || body.trim() === '') return '';
  return micromark(body, {
    extensions: [gfm()],
    htmlExtensions: [gfmHtml()],
  });
}
