// Browser persistence for the staging set.
//
// The static site has no server, so pending edits live in the editor's own
// browser via localStorage until committed. This thin wrapper is the ONLY place
// that touches localStorage / the DOM; all set logic is the pure functions in
// `pendingChanges.ts`. Two independent islands share the set — the `EntryEditor`
// that stages a change and the `StagingBar` that lists and commits it — so every
// mutation both writes localStorage AND dispatches a window event the bar
// subscribes to, keeping them in sync within the tab (the native `storage` event
// only fires cross-tab).

import { upsertChange, removeChange, type PendingChange } from './pendingChanges';
import { reloadBaseline, type DriftedChange } from './staleCheck';

const STORAGE_KEY = 'codeyam-cms:pending-changes';
const CHANGE_EVENT = 'codeyam-cms:pending-changed';

function hasStorage(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

/** Current staging set, or `[]` when unavailable (SSR) or corrupt. */
export function loadChanges(): PendingChange[] {
  if (!hasStorage()) return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as PendingChange[]) : [];
  } catch {
    return [];
  }
}

function persist(changes: PendingChange[]): PendingChange[] {
  if (!hasStorage()) return changes;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(changes));
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
  return changes;
}

/** Stage (or, for a no-op edit, unstage) an entry and notify listeners. */
export function stageChange(change: PendingChange): PendingChange[] {
  return persist(upsertChange(loadChanges(), change));
}

/** Drop one staged change by content path. */
export function discardChange(path: string): PendingChange[] {
  return persist(removeChange(loadChanges(), path));
}

/**
 * Resolve one drifted change by adopting the branch's current content as its
 * baseline, so the review diff shows the co-editor's version against this one.
 */
export function reloadChangeBaseline(drift: DriftedChange): PendingChange[] {
  return persist(reloadBaseline(loadChanges(), drift));
}

/** Clear the whole staging set — used after a successful commit. */
export function clearChanges(): PendingChange[] {
  return persist([]);
}

/**
 * Subscribe to staging-set changes (same-tab custom event + cross-tab `storage`
 * event). Returns an unsubscribe function.
 */
export function subscribe(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const onStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) callback();
  };
  window.addEventListener(CHANGE_EVENT, callback);
  window.addEventListener('storage', onStorage);
  return () => {
    window.removeEventListener(CHANGE_EVENT, callback);
    window.removeEventListener('storage', onStorage);
  };
}
