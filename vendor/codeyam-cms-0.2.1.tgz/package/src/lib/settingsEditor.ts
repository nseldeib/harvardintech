// Pure logic for the site-settings editor (the "Site details" + "Social links"
// sections of /admin/settings).
//
// The `SettingsEditor` island is a thin shell over these helpers: they declare
// which scalar fields the form renders, apply immutable edits to the socials
// list, and turn the edited settings into a `PendingChange` the existing
// staging/commit pipeline understands. Framework-free so it unit-tests with no
// DOM and runs unchanged in the browser island.

import type { PendingChange } from './pendingChanges';
import {
  SETTINGS_PATH,
  moveInArray,
  reorderInArray,
  serializeSettings,
  type SiteSettings,
  type SocialLink,
} from './siteConfig';

export type SettingsFieldType = 'text' | 'textarea';

export interface SettingsFieldDef {
  /** Key on `SiteSettings` — also the form input name. */
  name: keyof Pick<SiteSettings, 'siteTitle' | 'siteUrl' | 'description' | 'contactEmail' | 'footerText'>;
  label: string;
  type: SettingsFieldType;
}

/** The editable scalar fields, in display order. The `socials` list is edited
 * separately by its own list controls, so it is not in this list. */
export const SETTINGS_FIELDS: readonly SettingsFieldDef[] = [
  { name: 'siteTitle', label: 'Site title', type: 'text' },
  { name: 'siteUrl', label: 'Public site URL', type: 'text' },
  { name: 'description', label: 'Description', type: 'textarea' },
  { name: 'contactEmail', label: 'Contact email', type: 'text' },
  { name: 'footerText', label: 'Footer text', type: 'textarea' },
];

/** A fresh, blank social link for the "Add social link" control. */
export function emptySocial(): SocialLink {
  return { label: '', url: '' };
}

/** Append a blank social link. */
export function addSocial(socials: SocialLink[]): SocialLink[] {
  return [...socials, emptySocial()];
}

/** Patch the social link at `index`, leaving the rest untouched. */
export function updateSocial(
  socials: SocialLink[],
  index: number,
  patch: Partial<SocialLink>,
): SocialLink[] {
  return socials.map((s, i) => (i === index ? { ...s, ...patch } : s));
}

/** Remove the social link at `index`. */
export function removeSocial(socials: SocialLink[], index: number): SocialLink[] {
  return socials.filter((_, i) => i !== index);
}

/** Move the social link at `index` up (−1) or down (+1); ends are no-ops. */
export function moveSocial(socials: SocialLink[], index: number, delta: number): SocialLink[] {
  return moveInArray(socials, index, delta);
}

/** Drag-reorder: pull the social link at `from` and drop it at `to`. */
export function reorderSocial(socials: SocialLink[], from: number, to: number): SocialLink[] {
  return reorderInArray(socials, from, to);
}

/**
 * Build the `PendingChange` for a settings edit. Both baselines run through the
 * same canonical serializer, so an edit that returns settings to their original
 * value produces `updated === original` and `upsertChange` unstages it as a
 * no-op. The change writes the whole `settings.json` file (a WRITE, kind
 * `edit`) through the normal one-commit flow.
 */
export function buildSettingsChange(original: SiteSettings, current: SiteSettings): PendingChange {
  return {
    collection: 'settings',
    slug: 'settings',
    path: SETTINGS_PATH,
    title: 'Site settings',
    original: serializeSettings(original),
    updated: serializeSettings(current),
    kind: 'edit',
  };
}
