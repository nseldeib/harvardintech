// Pure helpers for the live entry preview — the value-shaping the EntryPreview
// component renders. Framework-free (no React, no DOM) so the date/title/meta
// logic unit-tests directly. The component owns the markup; this owns the rules.
import type { RawFieldValue } from './entryEditor';

/** A field value as a trimmed string ('' for anything non-string). */
export function asStr(v: RawFieldValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

/**
 * Format a `YYYY-MM-DD` value for the meta line. A bare date is parsed in LOCAL
 * time (numeric constructor) so it never renders a day early the way
 * `new Date("2026-01-12")` — parsed as UTC midnight — does in a negative-offset
 * timezone. Anything unparseable passes through so a half-typed date never throws.
 */
export function formatPreviewDate(value: string): string {
  if (!value) return '';
  const ymd = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value.trim());
  const d = ymd ? new Date(Number(ymd[1]), Number(ymd[2]) - 1, Number(ymd[3])) : new Date(value);
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString();
}

/**
 * The article title for the preview. Prefers the collection's designated label
 * field when supplied (a custom collection may name entries by e.g. `company`),
 * then falls back to `title`, then `name`. An entry with none falls back to a
 * placeholder flagged so the component can style it muted, so an untitled draft
 * still previews.
 */
export function previewTitle(
  values: Record<string, RawFieldValue>,
  labelField?: string,
): {
  text: string;
  placeholder: boolean;
} {
  const explicit = labelField ? asStr(values[labelField]) : '';
  const t = (explicit || asStr(values.title) || asStr(values.name)).trim();
  return t ? { text: t, placeholder: false } : { text: 'Untitled', placeholder: true };
}

/** The sub-title meta line: whichever of date / role / location the entry has,
 * joined with a middot. */
export function previewMetaLine(values: Record<string, RawFieldValue>): string {
  return [formatPreviewDate(asStr(values.date)), asStr(values.role), asStr(values.location)]
    .map((s) => s.trim())
    .filter(Boolean)
    .join(' · ');
}
