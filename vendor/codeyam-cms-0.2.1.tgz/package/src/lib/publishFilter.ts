// Pure publish-state filtering for the SITE a consuming project renders.
//
// `entryList.ts` splits entries for the ADMIN, which must see drafts in order to
// edit them. This module answers the other half of the question — what the
// public site should render — and deliberately lives apart from the loader so
// the two concerns stay separate (`collectionLoader` must keep feeding the admin
// everything).
//
// It works on the shape `getCollection()` hands a consuming site (`{ id, data }`)
// rather than the admin's flattened rows, so a listing page can drop it into an
// existing chain without a `.map` in between, and `getStaticPaths` can apply the
// same rule to avoid emitting a draft's own page.
//
// Absent means published. `formValuesToData` only ever writes `draft: true` and
// `buildUnarchiveChange` clears the key outright, so an entry with no `draft` is
// live — which is what makes adopting `draftField` a no-op for the content a
// site already has.
//
// No `astro:content` import: this module is deliberately framework-free so it
// unit-tests without an Astro project.
import { isProductionBuild } from './buildEnv';

/** The minimum shape this module needs — anything carrying a `data.draft` flag. */
export interface DraftableEntry {
  data: { draft?: boolean | undefined };
}

export interface PublishedEntriesOptions {
  /**
   * Force drafts in (`true`) or out (`false`) regardless of environment. Omit
   * for the environment-aware default: hidden in a production build, shown
   * under `astro dev` so drafts stay previewable.
   */
  includeDrafts?: boolean;
}

/**
 * Whether an entry is published — i.e. its draft flag is not `true`. A missing
 * key and an explicit `draft: false` both read as published; the CMS never
 * writes the latter, but a hand-edited file may carry it.
 */
export function isPublished(entry: DraftableEntry): boolean {
  return entry.data.draft !== true;
}

/**
 * The environment-independent core: select entries against an explicit
 * `includeDrafts` decision. Always returns a NEW array in input order, so the
 * caller's sort survives and the input is never mutated.
 */
export function selectPublished<T extends DraftableEntry>(
  entries: readonly T[],
  { includeDrafts }: { includeDrafts: boolean },
): T[] {
  return includeDrafts ? [...entries] : entries.filter(isPublished);
}

/**
 * The entries a public page should render: drafts hidden in a production build,
 * shown under `astro dev`, with `includeDrafts` overriding either way.
 *
 * Use it for listings AND inside `getStaticPaths` — filtering a listing while
 * `getStaticPaths` still generates the draft's own page leaves it publicly
 * reachable at its URL, which looks like working draft support but is not.
 */
export function publishedEntries<T extends DraftableEntry>(
  entries: readonly T[],
  options: PublishedEntriesOptions = {},
): T[] {
  const includeDrafts = options.includeDrafts ?? !isProductionBuild();
  return selectPublished(entries, { includeDrafts });
}
