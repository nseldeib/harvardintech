// Pure logic for the navigation editor (the "Navigation" section of
// /admin/settings).
//
// The nav is one level deep: a list of top-level items, each of which is either
// a direct link (`url`) or a dropdown holding a list of child links
// (`children`). These helpers apply immutable edits to that tree and turn it
// into a `PendingChange`. An item can carry BOTH a `url` and a `children` list
// while being edited — the canonical serializer in `siteConfig` decides which
// one wins (children non-empty → dropdown, url dropped; otherwise → link). That
// means "add a sub-item then remove it" restores the original link cleanly
// instead of wiping its url, so no spurious change is staged. Framework-free so
// it unit-tests with no DOM and runs unchanged in the browser island.

import type { PendingChange } from './pendingChanges';
import {
  NAV_PATH,
  moveInArray,
  reorderInArray,
  serializeNav,
  type NavItem,
  type SiteNav,
} from './siteConfig';

/** A fresh, blank leaf link. */
export function emptyNavItem(): NavItem {
  return { label: '', url: '' };
}

/** Whether an item is currently rendered as a dropdown (has ≥1 child). */
export function isDropdown(item: NavItem): boolean {
  return (item.children?.length ?? 0) > 0;
}

/** Append a blank top-level link. */
export function addNavItem(items: NavItem[]): NavItem[] {
  return [...items, emptyNavItem()];
}

/** Patch the top-level item at `index` (its label or url). */
export function updateNavItem(items: NavItem[], index: number, patch: Partial<NavItem>): NavItem[] {
  return items.map((item, i) => (i === index ? { ...item, ...patch } : item));
}

/** Remove the top-level item at `index`. */
export function removeNavItem(items: NavItem[], index: number): NavItem[] {
  return items.filter((_, i) => i !== index);
}

/** Move the top-level item at `index` up (−1) or down (+1); ends are no-ops. */
export function moveNavItem(items: NavItem[], index: number, delta: number): NavItem[] {
  return moveInArray(items, index, delta);
}

/**
 * Append a blank child to the item at `index`, turning a link into a dropdown
 * on the first child. The item's own `url` is kept (not destroyed) so removing
 * the last child restores the original link.
 */
export function addNavChild(items: NavItem[], index: number): NavItem[] {
  return items.map((item, i) =>
    i === index ? { ...item, children: [...(item.children ?? []), emptyNavItem()] } : item,
  );
}

/** Patch the child at `childIndex` under the item at `index`. */
export function updateNavChild(
  items: NavItem[],
  index: number,
  childIndex: number,
  patch: Partial<NavItem>,
): NavItem[] {
  return items.map((item, i) => {
    if (i !== index) return item;
    const children = (item.children ?? []).map((child, ci) =>
      ci === childIndex ? { ...child, ...patch } : child,
    );
    return { ...item, children };
  });
}

/**
 * Remove the child at `childIndex` under the item at `index`. The (possibly now
 * empty) `children` array is kept, so the editor still shows the item as a
 * dropdown-in-progress; the serializer collapses an empty dropdown back to a
 * plain link.
 */
export function removeNavChild(items: NavItem[], index: number, childIndex: number): NavItem[] {
  return items.map((item, i) => {
    if (i !== index) return item;
    const children = (item.children ?? []).filter((_, ci) => ci !== childIndex);
    return { ...item, children };
  });
}

/** Move a child within its dropdown up (−1) or down (+1); ends are no-ops. */
export function moveNavChild(
  items: NavItem[],
  index: number,
  childIndex: number,
  delta: number,
): NavItem[] {
  return items.map((item, i) =>
    i === index ? { ...item, children: moveInArray(item.children ?? [], childIndex, delta) } : item,
  );
}

// ─── Drag-and-drop reorder + re-nesting ──────────────────────────────────────
//
// The nav is a one-level tree, so a draggable node lives at one of two kinds of
// address: a top-level slot (`parent === null`) or a child slot under a
// dropdown (`parent === <item index>`). `moveNavNode` is the single primitive
// the drag layer calls — it lifts the node at `from` and drops it at `to`,
// covering every gesture the UI offers: reorder within a list, promote a child
// to top level, demote/nest a top-level leaf under a dropdown, and move a child
// between dropdowns. It stays pure so the whole re-nesting matrix unit-tests
// without a DOM.

/** Where a draggable nav node sits: `parent === null` is the top-level list;
 * a number is the index of the dropdown whose children list it lives in. */
export interface NavAddr {
  parent: number | null;
  index: number;
}

/** The list a given address points into (top-level items, or a dropdown's children). */
function listAt(items: NavItem[], parent: number | null): NavItem[] {
  return parent === null ? items : items[parent]?.children ?? [];
}

/** Reorder a top-level item by drag: pull from `from`, drop at `to`. */
export function reorderNavItem(items: NavItem[], from: number, to: number): NavItem[] {
  return reorderInArray(items, from, to);
}

/** Reorder a child within one dropdown by drag: pull from `from`, drop at `to`. */
export function reorderNavChild(
  items: NavItem[],
  parentIndex: number,
  from: number,
  to: number,
): NavItem[] {
  return items.map((item, i) =>
    i === parentIndex ? { ...item, children: reorderInArray(item.children ?? [], from, to) } : item,
  );
}

function removeNavAddr(items: NavItem[], addr: NavAddr): NavItem[] {
  if (addr.parent === null) return items.filter((_, i) => i !== addr.index);
  return items.map((item, i) =>
    i === addr.parent
      ? { ...item, children: (item.children ?? []).filter((_, ci) => ci !== addr.index) }
      : item,
  );
}

function insertNavAddr(items: NavItem[], addr: NavAddr, node: NavItem): NavItem[] {
  const clampInsert = (list: NavItem[], at: number): NavItem[] => {
    const next = [...list];
    next.splice(Math.max(0, Math.min(at, next.length)), 0, node);
    return next;
  };
  if (addr.parent === null) return clampInsert(items, addr.index);
  return items.map((item, i) =>
    i === addr.parent ? { ...item, children: clampInsert(item.children ?? [], addr.index) } : item,
  );
}

/**
 * Move the nav node at `from` so it lands at `to`, returning a new items tree.
 * Handles all four drag gestures uniformly. Two invariants keep it safe:
 *  - The nav is only one level deep, so a dropdown (a node WITH children) may
 *    never become someone's child — such a move is rejected as a no-op.
 *  - Removing the source shifts later indices; the destination address is
 *    re-based against the post-removal tree so a drop lands where the pointer is.
 * A same-slot move (or an out-of-range/into-itself address) returns `items` as-is.
 */
export function moveNavNode(items: NavItem[], from: NavAddr, to: NavAddr): NavItem[] {
  const node = listAt(items, from.parent)[from.index];
  if (!node) return items;
  // One level deep: can't nest a dropdown under another item.
  if (to.parent !== null && (node.children?.length ?? 0) > 0) return items;
  // Can't nest an item inside itself.
  if (from.parent === null && to.parent === from.index) return items;
  if (from.parent === to.parent && from.index === to.index) return items;

  const without = removeNavAddr(items, from);

  // Re-base a NUMERIC destination parent against the tree after removal: pulling
  // a top-level item shifts every later top-level index (and thus every dropdown's
  // index) down by one. The destination index within the target list needs no
  // adjustment — like `reorderInArray`, `to.index` is the drop position in the
  // post-removal list, which keeps drag semantics identical across every list.
  let destParent = to.parent;
  if (from.parent === null && destParent !== null && destParent > from.index) destParent -= 1;

  return insertNavAddr(without, { parent: destParent, index: to.index }, node);
}

/**
 * Build the `PendingChange` for a nav edit. Both baselines run through the same
 * canonical serializer, so an edit that returns the nav to its original value
 * produces `updated === original` and `upsertChange` unstages it as a no-op.
 */
export function buildNavChange(original: SiteNav, current: SiteNav): PendingChange {
  return {
    collection: 'nav',
    slug: 'nav',
    path: NAV_PATH,
    title: 'Navigation menu',
    original: serializeNav(original),
    updated: serializeNav(current),
    kind: 'edit',
  };
}
