// Hold a GitHub commit token in the browser — obtained two ways, no server needed.
//
// A static site can't hold a server secret, so the publish token lives entirely
// in the browser. There are two ways to get one, and a site can offer either or
// both (see `cmsConfig`):
//   1. Paste a token — the editor pastes a fine-grained GitHub token straight
//      into the sign-in gate; `setToken` persists it. Zero infrastructure.
//   2. Worker popup — `ensureGithubToken` drives the Decap/Sveltia postMessage
//      handshake against the `cms-auth-worker` relay: we open its `/auth` popup,
//      it announces `authorizing:github`, we acknowledge, and it replies
//      `authorization:github:success:<json>` carrying the token. This path costs
//      a Cloudflare Worker but gives "Sign in with GitHub" without a paste.
//
// Either way the token is cached in localStorage (NOT sessionStorage), so a
// signed-in editor is remembered across visits until they sign out. Browser-only.

const TOKEN_KEY = 'codeyam-cms:gh-token';
const PROVIDER = 'github';

/** The stored token, if an editor is signed in (persists across visits). */
export function cachedToken(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return window.localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

/**
 * Persist a token in the browser. Public so the paste-a-token sign-in can store
 * a token it obtained without the worker popup; the worker path calls it too.
 */
export function setToken(token: string): void {
  try {
    window.localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* private-mode / disabled storage — proceed without caching */
  }
}

/** Forget the stored token (on sign-out, or after a 401 on commit). */
export function clearToken(): void {
  try {
    window.localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
}

/**
 * Resolve a GitHub token: the cached one if present, otherwise drive the popup
 * handshake against `authEndpoint`. Rejects if the popup is blocked, the editor
 * closes it, or the handshake times out.
 */
export function ensureGithubToken(authEndpoint: string, timeoutMs = 120_000): Promise<string> {
  const existing = cachedToken();
  if (existing) return Promise.resolve(existing);

  return new Promise<string>((resolve, reject) => {
    const popup = window.open(authEndpoint, 'codeyam-cms-auth', 'width=600,height=700');
    if (!popup) {
      reject(new Error('Sign-in popup was blocked. Allow popups and try again.'));
      return;
    }

    const successPrefix = `authorization:${PROVIDER}:success:`;
    let settled = false;

    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      window.removeEventListener('message', onMessage);
      window.clearInterval(closedTimer);
      window.clearTimeout(timer);
      fn();
    };

    const onMessage = (event: MessageEvent) => {
      const data = event.data;
      if (typeof data !== 'string') return;
      if (data === `authorizing:${PROVIDER}`) {
        // The worker is ready; acknowledge so it sends the token.
        popup.postMessage(`authorizing:${PROVIDER}`, '*');
        return;
      }
      if (data.startsWith(successPrefix)) {
        try {
          const payload = JSON.parse(data.slice(successPrefix.length));
          if (payload?.token) {
            setToken(payload.token);
            finish(() => resolve(payload.token));
            return;
          }
        } catch {
          /* fall through to error */
        }
        finish(() => reject(new Error('Sign-in did not return a token.')));
      }
    };

    const closedTimer = window.setInterval(() => {
      if (popup.closed) finish(() => reject(new Error('Sign-in was cancelled.')));
    }, 500);
    const timer = window.setTimeout(
      () => finish(() => reject(new Error('Sign-in timed out.'))),
      timeoutMs,
    );

    window.addEventListener('message', onMessage);
  });
}
