// The editable-field contract for the entry editor, plus the pure glue that
// turns edited form values back into a frontmatter data map.
//
// Each collection in `src/content/config.ts` has its own schema; the editor form
// renders one input per field, so it needs a field descriptor list per
// collection. This list is the single source of truth for BOTH what inputs the
// `EntryEditor` island renders AND the frontmatter key order `serializeEntry`
// writes — so a saved entry's frontmatter always comes out in a stable,
// reviewable order. Framework-free so it unit-tests and runs in the browser.

import type { BuiltinCollectionName, CollectionName } from './adminDashboard';
import type { FrontmatterScalar, FrontmatterValue } from './frontmatter';
// Type-only (erased at runtime, so no import cycle with collectionRegistry, which
// imports the SEO/field values from this module).
import type { CollectionsRegistry } from './collectionRegistry';

export type FieldType = 'text' | 'textarea' | 'date' | 'number' | 'boolean' | 'image' | 'list';

export interface FieldDef {
  /** Frontmatter key — also the form input name. */
  name: string;
  /** Human label shown beside the input. */
  label: string;
  type: FieldType;
  /** Row sub-schema for a `list` field — the scalar fields each repeatable row
   * holds. Present only when `type === 'list'`; sub-fields are scalar-only
   * (no nested lists, matching the frontmatter engine's 2-level cap). */
  fields?: FieldDef[];
  /** Optional fields may be left blank; a blank optional field is omitted from
   * the written frontmatter (matching the "missing optional" content scenarios). */
  optional?: boolean;
  /** Groups a field into a distinct editor section. `'seo'` fields render under
   * the "SEO & Social" panel (with the share-card preview) instead of inline with
   * the content fields; undefined means a normal content field. */
  group?: 'seo';
  /** Optional hint shown under the input — e.g. what a blank override falls back to. */
  hint?: string;
}

/**
 * The implicit publish toggle every collection carries, appended last so it sits
 * at the foot of the editor form. Built-in collections list it explicitly in
 * `COLLECTION_FIELDS`; custom collections get it appended when their registry
 * definition is resolved to an editor field list.
 */
export const DRAFT_FIELD: FieldDef = { name: 'draft', label: 'Draft', type: 'boolean' };

/**
 * The universal SEO & Social override group appended to EVERY collection
 * (built-in and custom), the way `DRAFT_FIELD` is. All optional — a blank field
 * is omitted from frontmatter and the rendered page + card preview fall back to
 * the entry's own title/summary/cover image and the site defaults. Kept as one
 * shared list so a new collection gets a consistent SEO panel for free.
 */
export const SEO_FIELDS: FieldDef[] = [
  {
    name: 'seoTitle',
    label: 'SEO title',
    type: 'text',
    optional: true,
    group: 'seo',
    hint: 'The <title> and share-card title. Falls back to the entry title.',
  },
  {
    name: 'seoDescription',
    label: 'Meta description',
    type: 'textarea',
    optional: true,
    group: 'seo',
    hint: 'The search + social description. Falls back to the summary, then the site default.',
  },
  {
    name: 'socialImage',
    label: 'Social share image',
    type: 'image',
    optional: true,
    group: 'seo',
    hint: 'The image shown when the page is shared. Falls back to the cover image.',
  },
  {
    name: 'canonicalUrl',
    label: 'Canonical URL',
    type: 'text',
    optional: true,
    group: 'seo',
    hint: 'For cross-posted content. Falls back to this page’s own URL.',
  },
];

// The content fields per collection, in display + serialization order. Mirrors
// the zod schemas in `src/content/config.ts`. `draft` is last so the publish
// toggle sits at the foot of the content fields; the SEO group is appended after
// it (see `COLLECTION_FIELDS`).
export const CONTENT_FIELDS: Record<BuiltinCollectionName, FieldDef[]> = {
  blog: [
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'date', label: 'Date', type: 'date' },
    { name: 'summary', label: 'Summary', type: 'textarea', optional: true },
    { name: 'coverImage', label: 'Cover image', type: 'image', optional: true },
    { name: 'draft', label: 'Draft', type: 'boolean' },
  ],
  pages: [
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'description', label: 'Description', type: 'textarea', optional: true },
    { name: 'order', label: 'Order', type: 'number', optional: true },
    { name: 'draft', label: 'Draft', type: 'boolean' },
  ],
  events: [
    { name: 'title', label: 'Title', type: 'text' },
    { name: 'date', label: 'Date', type: 'date' },
    { name: 'location', label: 'Location', type: 'text', optional: true },
    { name: 'description', label: 'Description', type: 'textarea', optional: true },
    { name: 'link', label: 'Registration link', type: 'text', optional: true },
    { name: 'draft', label: 'Draft', type: 'boolean' },
  ],
  team: [
    { name: 'name', label: 'Name', type: 'text' },
    { name: 'role', label: 'Role', type: 'text' },
    { name: 'photo', label: 'Photo', type: 'image', optional: true },
    { name: 'bio', label: 'Bio', type: 'textarea', optional: true },
    { name: 'order', label: 'Order', type: 'number', optional: true },
    { name: 'draft', label: 'Draft', type: 'boolean' },
  ],
};

/**
 * Editable fields per collection, in display + serialization order: the content
 * fields followed by the universal SEO group. This is the single source of truth
 * for BOTH what the editor renders AND the frontmatter key order, so a saved
 * entry's SEO keys always serialize in a stable, reviewable order after `draft`.
 */
export const COLLECTION_FIELDS: Record<BuiltinCollectionName, FieldDef[]> = {
  blog: [...CONTENT_FIELDS.blog, ...SEO_FIELDS],
  pages: [...CONTENT_FIELDS.pages, ...SEO_FIELDS],
  events: [...CONTENT_FIELDS.events, ...SEO_FIELDS],
  team: [...CONTENT_FIELDS.team, ...SEO_FIELDS],
};

/**
 * The site's SEO & Social field group: the consumer's `seo` list from the
 * collections registry when it defines one, else the built-in {@link SEO_FIELDS}
 * default. Consumer-declared fields are forced into the `'seo'` group so they
 * always render in the SEO panel (with the share-card preview) regardless of
 * whether the registry entry set `group`. Their `name`s are what the rendered
 * page + `content-helpers` `seoFields` schema must agree on.
 */
export function resolveSeoFields(reg: CollectionsRegistry): FieldDef[] {
  const seo = reg.seo && reg.seo.length > 0 ? reg.seo : SEO_FIELDS;
  return seo.map((f) => ({ ...f, group: 'seo' as const }));
}

/** The field order used when serializing an entry's frontmatter — the declared
 * order of the collection's resolved fields. */
export function fieldOrder(fields: FieldDef[]): string[] {
  return fields.map((f) => f.name);
}

/**
 * The name of the field whose value labels an entry: `title` if the collection
 * has one, else `name`, else the first prose (text/textarea) field, else the
 * first non-toggle field. This lets a custom collection with neither `title` nor
 * `name` still name its entries from whatever it does have.
 */
export function labelFieldName(fields: FieldDef[]): string {
  const names = fields.map((f) => f.name);
  if (names.includes('title')) return 'title';
  if (names.includes('name')) return 'name';
  const firstProse = fields.find((f) => f.type === 'text' || f.type === 'textarea');
  if (firstProse) return firstProse.name;
  const firstNonToggle = fields.find((f) => f.type !== 'boolean');
  return firstNonToggle?.name ?? names[0] ?? 'title';
}

/**
 * The human label for an entry in lists and the staging review. Uses the
 * collection's designated label field when given (`labelField`), otherwise falls
 * back to `title` then `name`. Falls back to the slug so an entry missing its
 * label field still shows something identifiable.
 */
export function entryLabel(
  data: Record<string, FrontmatterValue | undefined>,
  slug: string,
  labelField?: string,
): string {
  const explicit = labelField ? data[labelField] : undefined;
  const title = explicit ?? data.title ?? data.name;
  return typeof title === 'string' && title.trim() !== '' ? title : slug;
}

/** Repo-relative path of an entry's markdown file under the content root. */
export function entryContentPath(collection: CollectionName, slug: string): string {
  return `src/content/${collection}/${slug}.md`;
}

/** A raw scalar form value as it comes off an input, before typing. */
export type RawScalarValue = string | boolean;

/** The raw form value of one `list` row: a map of scalar sub-field values. */
export type RawRowValue = Record<string, RawScalarValue>;

/** A raw form value: a scalar (from a plain input) or, for a `list` field, an
 * array of row maps. Widened for the list field type — every scalar field's
 * value is still just a `string | boolean`. */
export type RawFieldValue = RawScalarValue | RawRowValue[];

/**
 * Convert one raw SCALAR field value to its typed frontmatter form, following the
 * field's declared type. Returns `undefined` for a blank optional field (so it is
 * omitted) and `''` for a blank required field (so a schema-required key still
 * round-trips). A `boolean` yields `true` only when checked, else `undefined`
 * (a false flag is omitted). Shared by the flat field loop and each `list` row. */
function scalarToData(field: FieldDef, raw: RawScalarValue | undefined): FrontmatterValue | undefined {
  if (field.type === 'boolean') return raw === true ? true : undefined;
  const str = typeof raw === 'string' ? raw : raw == null ? '' : String(raw);
  const trimmed = str.trim();
  if (trimmed === '') return field.optional ? undefined : '';
  if (field.type === 'number') {
    const n = Number(trimmed);
    return Number.isFinite(n) ? n : trimmed;
  }
  return str;
}

/** True when a form value is a `list` field's array-of-rows (vs. a scalar). */
function isRowArray(value: RawFieldValue | undefined): value is RawRowValue[] {
  return Array.isArray(value);
}

/**
 * Convert a `list` field's form rows into the array-of-maps the frontmatter engine
 * serializes. Each row's scalar sub-fields run through {@link scalarToData}; a
 * blank optional sub-field is dropped from its row, and a row left wholly empty
 * (every key blank) is dropped entirely — so an untouched "add a row" click never
 * writes an empty `{}` to frontmatter.
 */
function listToData(subFields: FieldDef[], rows: RawRowValue[]): Record<string, FrontmatterScalar>[] {
  const out: Record<string, FrontmatterScalar>[] = [];
  for (const row of rows) {
    // A row the user added but never filled (every input blank / unticked) is
    // dropped, even if it has required sub-fields — so a stray "+ Add" click
    // never writes a junk `{ name: "" }` to frontmatter.
    if (subFields.every((sub) => isBlankScalar(sub, row?.[sub.name]))) continue;
    const mapped: Record<string, FrontmatterScalar> = {};
    for (const sub of subFields) {
      const v = scalarToData(sub, row?.[sub.name]);
      // Sub-values are always scalars (no nested lists), so this narrowing holds.
      if (v !== undefined) mapped[sub.name] = v as FrontmatterScalar;
    }
    if (Object.keys(mapped).length > 0) out.push(mapped);
  }
  return out;
}

/** True when a scalar sub-field's raw value is blank — '' (after trim) for a
 * text input, or unticked for a toggle. Used to detect a wholly-empty list row. */
function isBlankScalar(field: FieldDef, raw: RawScalarValue | undefined): boolean {
  if (field.type === 'boolean') return raw !== true;
  const str = typeof raw === 'string' ? raw : raw == null ? '' : String(raw);
  return str.trim() === '';
}

/** The label as it reads mid-sentence: "Title" → "title", while an acronym or
 * proper noun ("SEO title", "URL") keeps the case it was written with. */
function labelPhrase(label: string): string {
  return /^[A-Z][a-z]/.test(label) ? label[0].toLowerCase() + label.slice(1) : label;
}

/** One required field the form has left blank. */
export interface MissingField {
  /** The top-level field's name. */
  field: string;
  /** Row index, when the blank sits inside a `list` field's row. */
  row?: number;
  /** Sub-field name, when the blank sits inside a `list` field's row. */
  sub?: string;
  /** How the footer names it — `"Title"`, or `"Chapters row 2 · Heading"`. */
  label: string;
  /** The message shown beneath the input itself. */
  message: string;
  /** True when the entry ARRIVED with this blank. Surfaced inline all the same,
   * but excluded from the staging gate so an entry already invalid in the repo
   * stays repairable rather than trapping the editor in it. */
  preExisting: boolean;
}

export interface RequiredFieldStatus {
  /** Every blank required field, pre-existing ones included. */
  missing: MissingField[];
  /** Any blank required field at all — what the inline errors render from. */
  hasMissing: boolean;
  /** Any blank required field this editing session is answerable for — the
   * staging gate. Pre-existing blanks are excluded. */
  blocked: boolean;
  /** Inline message per top-level field, keyed by field name. */
  fieldErrors: Record<string, string>;
  /** Inline message per list-row sub-field: `[field][rowIndex][sub]`. */
  rowErrors: Record<string, Record<number, Record<string, string>>>;
  /** The footer line explaining what is blank; '' when nothing is. */
  message: string;
}

export interface RequiredFieldInput {
  fields: FieldDef[];
  values: Record<string, RawFieldValue>;
  /** The entry's committed baseline values, when editing an existing entry. A
   * required field already blank here is reported but never blocking. Omit for
   * the new-entry flow, where every blank is the editor's own doing. */
  baseline?: Record<string, RawFieldValue>;
}

/** Stable identity for one missing value, so a blank can be matched against the
 * baseline's blanks. List rows key by index — a reordered row therefore reads as
 * newly blank, which is right: reordering is an edit the editor made. */
function missingKey(field: string, row?: number, sub?: string): string {
  return row === undefined ? field : `${field}[${row}].${sub}`;
}

/** Collect the blank required values in one set of form values, keyed by
 * {@link missingKey}. Shared by the reported pass and the baseline pass. */
function collectMissing(
  fields: FieldDef[],
  values: Record<string, RawFieldValue>,
): Omit<MissingField, 'preExisting'>[] {
  const out: Omit<MissingField, 'preExisting'>[] = [];
  for (const field of fields) {
    const raw = values[field.name];
    if (field.type === 'list') {
      const subFields = field.fields ?? [];
      const rows = isRowArray(raw) ? raw : [];
      rows.forEach((row, i) => {
        // A row the editor added but never filled is dropped by `listToData`, so
        // a stray "+ Add" click must not read as an error.
        if (subFields.every((sub) => isBlankScalar(sub, row?.[sub.name]))) return;
        for (const sub of subFields) {
          if (sub.optional || sub.type === 'boolean') continue;
          if (!isBlankScalar(sub, row?.[sub.name])) continue;
          out.push({
            field: field.name,
            row: i,
            sub: sub.name,
            label: `${field.label} row ${i + 1} · ${sub.label}`,
            message: `Enter a ${labelPhrase(sub.label)}.`,
          });
        }
      });
      continue;
    }
    if (field.optional) continue;
    // An unticked toggle is a legitimate `false`, never a missing value —
    // treating it as one would make a required boolean permanently unstageable.
    if (field.type === 'boolean') continue;
    if (!isBlankScalar(field, raw as RawScalarValue | undefined)) continue;
    out.push({
      field: field.name,
      label: field.label,
      message: `Enter a ${labelPhrase(field.label)}.`,
    });
  }
  return out;
}

/**
 * Report every required field the form has left blank, and whether that should
 * block staging.
 *
 * Required-ness comes from `FieldDef.optional` — the same contract the editor
 * already surfaces as the "· optional" marker — so enforcement and display
 * finally agree. Blankness comes from the same rule serialization uses
 * (`isBlankScalar`: '' after trim, unticked for a toggle), so validation cannot
 * drift from what actually gets written. The markdown body is not a `FieldDef`
 * and is not covered: an entry with an empty body is legitimate.
 *
 * Pure and framework-free — the components render the result, they don't compute
 * it.
 */
export function validateRequiredFields({
  fields,
  values,
  baseline,
}: RequiredFieldInput): RequiredFieldStatus {
  const wasBlank = new Set(
    baseline ? collectMissing(fields, baseline).map((m) => missingKey(m.field, m.row, m.sub)) : [],
  );

  const missing: MissingField[] = collectMissing(fields, values).map((m) => ({
    ...m,
    preExisting: wasBlank.has(missingKey(m.field, m.row, m.sub)),
  }));

  const fieldErrors: Record<string, string> = {};
  const rowErrors: Record<string, Record<number, Record<string, string>>> = {};
  for (const m of missing) {
    if (m.row === undefined || m.sub === undefined) {
      fieldErrors[m.field] = m.message;
      continue;
    }
    const rows = (rowErrors[m.field] ??= {});
    (rows[m.row] ??= {})[m.sub] = m.message;
  }

  const blocking = missing.filter((m) => !m.preExisting);
  const names = (list: MissingField[]) => list.map((m) => m.label).join(', ');
  // Phrased about the fields rather than the action, so the same line reads
  // correctly under "Stage change" and under "Create entry".
  const message =
    blocking.length > 0
      ? `${names(blocking)} ${blocking.length === 1 ? 'is' : 'are'} required and still blank.`
      : missing.length > 0
        ? `This entry arrived with ${names(missing)} blank — you can still stage other edits.`
        : '';

  return {
    missing,
    hasMissing: missing.length > 0,
    blocked: blocking.length > 0,
    fieldErrors,
    rowErrors,
    message,
  };
}

export interface StageStatusInput {
  /** Form differs from the last-committed baseline. */
  dirty: boolean;
  /** A change for this entry currently sits in the staging set. */
  staged: boolean;
  required: RequiredFieldStatus;
}

/**
 * The entry editor's footer status line. A greyed Stage button with no reason is
 * its own bug, so a blocking required field outranks every other state and says
 * which field. Below that the order is the pre-existing one — unsaved, then
 * staged, then idle — with a pre-existing blank (surfaced but not blocking)
 * shown in the idle slot rather than silently dropped.
 */
export function stageStatusMessage({ dirty, staged, required }: StageStatusInput): string {
  if (required.blocked) return required.message;
  if (dirty) return 'Unsaved edits — stage them to add to your pending changes.';
  if (staged) return 'Staged for the next commit.';
  if (required.hasMissing) return required.message;
  return 'No changes yet.';
}

/**
 * Convert the editor's raw form values into a typed frontmatter data map,
 * following each field's declared type. A blank OPTIONAL field becomes
 * `undefined` (so `serializeEntry` omits it); a blank REQUIRED field is kept as
 * an empty string so the entry still round-trips rather than silently dropping a
 * schema-required key. `number` fields parse to a number when non-blank.
 *
 * `extras` are frontmatter keys the CMS does not render (they're not in
 * `fields`) — e.g. a consumer site's `embedUrl` or `chapter`. They seed the
 * output first so they survive a save; the known-field loop then runs exactly
 * as before, so an edited or cleared known field always overrides a same-named
 * passthrough value. This is what stops editing an entry from erasing the
 * frontmatter the CMS happens not to know about.
 */
export function formValuesToData(
  fields: FieldDef[],
  values: Record<string, RawFieldValue>,
  extras: Record<string, FrontmatterValue> = {},
): Record<string, FrontmatterValue | undefined> {
  const out: Record<string, FrontmatterValue | undefined> = { ...extras };
  for (const field of fields) {
    const raw = values[field.name];
    if (field.type === 'list') {
      // A list always writes its (possibly empty) array, overriding any
      // same-named passthrough; the engine renders `[]` for an empty list.
      out[field.name] = listToData(field.fields ?? [], isRowArray(raw) ? raw : []);
      continue;
    }
    if (field.type === 'boolean') {
      // Only emit `draft: true`; a false draft flag is omitted so published
      // entries stay flag-free, matching how the rest of the CMS reads them.
      if (raw === true) out[field.name] = true;
      continue;
    }
    // A known scalar field always assigns (even `undefined`) so an edited or
    // cleared value overrides a same-named passthrough in `extras`.
    out[field.name] = scalarToData(field, raw as RawScalarValue | undefined);
  }
  return out;
}

/**
 * The frontmatter keys of a parsed entry that the given `fields` do NOT cover —
 * the passthrough set the editor must preserve verbatim on save (e.g. a consumer
 * site's `embedUrl` or `chapter`). Feed the result back into `formValuesToData`'s
 * `extras` argument so editing an entry never drops these keys.
 */
export function extractExtras(
  fields: FieldDef[],
  data: Record<string, FrontmatterValue>,
): Record<string, FrontmatterValue> {
  const known = new Set(fields.map((f) => f.name));
  return Object.fromEntries(Object.entries(data).filter(([k]) => !known.has(k)));
}

/** The blank form value for one scalar sub-field: `false` for a toggle, else ''. */
function emptyScalar(field: FieldDef): RawScalarValue {
  return field.type === 'boolean' ? false : '';
}

/** A fresh, empty row for a `list` field — every sub-field at its blank value.
 * Used by the "+ Add" button so a new row starts editable. */
export function emptyRowValues(subFields: FieldDef[]): RawRowValue {
  const row: RawRowValue = {};
  for (const sub of subFields) row[sub.name] = emptyScalar(sub);
  return row;
}

/** Turn a frontmatter array-of-maps into the row form values the list editor
 * binds to. A missing/blank value yields no rows; each row is filled to the full
 * sub-schema (missing keys become '' / `false`) so every input is controlled. */
function rowsToFormValues(subFields: FieldDef[], value: FrontmatterValue | undefined): RawRowValue[] {
  if (!Array.isArray(value)) return [];
  return value.map((item) => {
    const row: RawRowValue = {};
    const map = (item !== null && typeof item === 'object') ? (item as Record<string, FrontmatterScalar>) : {};
    for (const sub of subFields) {
      const v = map[sub.name];
      row[sub.name] = sub.type === 'boolean' ? v === true : v === undefined || v === null ? '' : String(v);
    }
    return row;
  });
}

/** Turn a parsed frontmatter map into the string/boolean values the form binds
 * to. Missing keys become '' (or `false` for the draft toggle). */
export function dataToFormValues(
  fields: FieldDef[],
  data: Record<string, FrontmatterValue>,
): Record<string, RawFieldValue> {
  const out: Record<string, RawFieldValue> = {};
  for (const field of fields) {
    const value = data[field.name];
    if (field.type === 'list') {
      out[field.name] = rowsToFormValues(field.fields ?? [], value);
    } else if (field.type === 'boolean') {
      out[field.name] = value === true;
    } else {
      out[field.name] = value === undefined || value === null ? '' : String(value);
    }
  }
  return out;
}
