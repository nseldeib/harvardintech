// Pure logic for the magic-link sign-in experience (the editor-facing side of
// the invite feature).
//
// A non-technical editor never sees GitHub: they get an invite email, click a
// link, and land in the CMS. This module models that flow as a small state
// machine + the human-readable copy for each state, so the `MagicLinkSignIn`
// island is a thin shell that renders `describeMagicLink(status)` and advances
// on the user's action. Framework-free — unit-tests with no DOM.
import { isValidEmail } from './editorsRegistry';

export type MagicLinkStatus =
  | 'landing' // just followed the invite — asked for their email to send the link
  | 'link-sent' // "check your email"
  | 'signing-in' // validating the clicked link
  | 'welcome' // success, about to enter the dashboard
  | 'expired'; // the link was too old / already used

/** Every state, in flow order — used by scenarios and by tests to enumerate. */
export const MAGIC_LINK_STATES: readonly MagicLinkStatus[] = [
  'landing',
  'link-sent',
  'signing-in',
  'welcome',
  'expired',
];

/** The two-line copy a state renders. Deliberately free of GitHub/commit/branch
 * vocabulary — this is the surface non-technical editors read. */
export interface MagicLinkCopy {
  title: string;
  body: string;
}

export interface MagicLinkContext {
  /** The site being edited, e.g. "Harvard in Tech". */
  siteTitle: string;
  /** The editor's email, shown on the "check your email" confirmation. */
  email?: string;
}

/** The headline + body for a given state. Keeps all user-facing wording in one
 * pure, testable place instead of scattered through JSX. */
export function describeMagicLink(
  status: MagicLinkStatus,
  ctx: MagicLinkContext,
): MagicLinkCopy {
  const site = ctx.siteTitle || 'this site';
  const email = ctx.email && ctx.email.trim() ? ctx.email.trim() : 'your email';
  switch (status) {
    case 'landing':
      return {
        title: `You've been invited to edit ${site}`,
        body: 'Enter your email and we’ll send you a secure sign-in link. No password to remember, no account to create.',
      };
    case 'link-sent':
      return {
        title: 'Check your email',
        body: `We sent a sign-in link to ${email}. Click it and you’ll be editing in seconds — the link works on any device.`,
      };
    case 'signing-in':
      return {
        title: 'Signing you in…',
        body: 'Hang tight while we verify your link.',
      };
    case 'welcome':
      return {
        title: 'You’re in 🎉',
        body: `Taking you to ${site}…`,
      };
    case 'expired':
      return {
        title: 'That link has expired',
        body: 'Sign-in links expire after a while to keep your site safe. Request a fresh one and we’ll email it right over.',
      };
  }
}

/** The result of the editor submitting their email on the landing screen. */
export interface SendResult {
  status: MagicLinkStatus;
  /** Inline validation error when the email was blank/malformed. */
  error?: string;
}

/**
 * Advance from `landing` when the editor submits an email: a valid address
 * moves to `link-sent`; a blank/malformed one stays on `landing` with an inline
 * error. Pure — the island applies the returned status.
 */
export function submitEmail(email: string): SendResult {
  if (!email.trim()) {
    return { status: 'landing', error: 'Enter your email to get a sign-in link.' };
  }
  if (!isValidEmail(email)) {
    return { status: 'landing', error: 'That doesn’t look like a valid email address.' };
  }
  return { status: 'link-sent' };
}

/** Whether the primary button should show a busy/disabled state. */
export function isBusy(status: MagicLinkStatus): boolean {
  return status === 'signing-in' || status === 'welcome';
}
