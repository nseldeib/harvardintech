// Pure grouping for a collection's entry list.
//
// The list view puts unfinished work first: a "Drafts" group, then "Published".
// This is the framework-free split the `[collection]/index.astro` page feeds its
// loaded entries through, so the ordering rule is unit-tested rather than baked
// into markup. Within each group the incoming order is preserved (the page sorts
// before grouping), so the caller controls sort while this controls the split.

export interface EntryListItem {
  slug: string;
  label: string;
  draft: boolean;
  /** The entry's raw markdown — the row island needs it to build an archive /
   * delete PendingChange (the same baseline the editor stages against). */
  raw: string;
}

export interface GroupedEntries<T extends EntryListItem = EntryListItem> {
  drafts: T[];
  published: T[];
}

/** Split entries into drafts-first groups, preserving each group's input order.
 * Generic over the item type so a caller passing a richer row (e.g. one carrying
 * a search index) gets that same type back, not the bare `EntryListItem`. */
export function groupByDraft<T extends EntryListItem>(items: T[]): GroupedEntries<T> {
  return {
    drafts: items.filter((i) => i.draft),
    published: items.filter((i) => !i.draft),
  };
}
