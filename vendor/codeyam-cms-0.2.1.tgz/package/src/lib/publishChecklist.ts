// The Publish Checklist — pure preflight checks run over the staging set before
// an editor commits. It answers a non-technical editor's implicit question at the
// moment of publishing: "is anything obviously wrong with what I'm about to ship?"
//
// Four advisory checks, all computed here without a DOM or network so they
// unit-test directly and run in the browser island on the Publish page:
//   • broken internal links — a body link to a content page that doesn't exist
//     (or is still a draft, so it won't be live);
//   • missing image alt text — a body image or a cover/social image with no alt;
//   • missing SEO — a page with no per-page title or no meta description;
//   • oversized images — an image being shipped that's over the weight budget.
//
// ADVISORY ONLY: this module never decides whether a publish is allowed. It
// returns findings; the Publish action stays enabled regardless. The point is to
// inform and reassure, not to gate.
//
// It reads the same staged `PendingChange` set the review list uses, parses each
// entry's `updated` text back through `frontmatter.parseEntry`, and resolves
// image sizes/alt through the media manifest — reusing the existing pure helpers
// so a check can never diverge from what actually ships.

import type { PendingChange, ChangeArea, SingletonName } from './pendingChanges';
import { isBinary, isDeletion } from './pendingChanges';
import { parseEntry } from './frontmatter';
import type { FrontmatterValue } from './frontmatter';
import { findAssetByUrl, formatSize, type MediaManifest } from './mediaLibrary';
import { NAV_PATH, type NavItem, type SiteNav } from './siteConfig';

/** The site singletons — areas the checklist never runs entry checks on. */
const SINGLETONS: readonly SingletonName[] = ['settings', 'nav', 'media', 'collections', 'cms'];

/** The four checks, in display order. Stable ids so the UI can key/icon them. */
export type CheckId = 'broken-links' | 'missing-alt' | 'missing-seo' | 'oversized-images';

/** Default per-image weight budget: 1 MB. Above this, a photo noticeably slows a
 * page — the threshold the "oversized" check flags against. */
export const DEFAULT_IMAGE_BUDGET_BYTES = 1024 * 1024;

/** A known content page the broken-link check validates targets against. */
export interface PageRef {
  collection: string;
  slug: string;
  /** Draft pages exist in the repo but aren't live — a link to one is flagged. */
  draft: boolean;
}

/** One menu item's link, flattened out of the nav tree. */
export interface NavLinkRef {
  /** The human path through the menu — "Chapters → Seattle" for a dropdown
   * child, just the label for a top-level item. What the editor recognizes. */
  label: string;
  /** The item's raw url, judged by the same rules as a body link. */
  url: string;
}

/** The menu label separator, so the flattener and its callers agree on one form. */
const NAV_LABEL_SEPARATOR = ' → ';

/** The title `buildNavChange` gives the nav singleton, reused so a nav finding's
 * byline reads the same as the nav's row in the review list. */
const NAV_TITLE = 'Navigation menu';

/**
 * A `SiteNav` flattened to the links worth validating: every item that carries a
 * `url` of its own, labelled with its full path through the menu. Dropdown
 * parents are recursed into but contribute no link themselves — a dropdown has
 * no url, only children. Exported so the Publish page and the tests share one
 * flattening rule rather than each writing their own.
 */
export function flattenNavLinks(nav: SiteNav | null | undefined): NavLinkRef[] {
  const links: NavLinkRef[] = [];
  const walk = (items: NavItem[] | undefined, trail: string[]) => {
    for (const item of items ?? []) {
      const path = [...trail, item.label ?? ''];
      if (typeof item.url === 'string' && item.url.trim() !== '') {
        links.push({ label: path.filter(Boolean).join(NAV_LABEL_SEPARATOR), url: item.url });
      }
      walk(item.children, path);
    }
  };
  walk(nav?.items, []);
  return links;
}

/** Everything the checklist needs beyond the staged changes themselves. The
 * Publish page builds this at load; isolated scenarios inject it directly. */
export interface ChecklistContext {
  /** Known content collection ids, so a link like `/blog/x` is recognized as a
   * content-page link (and thus validatable) vs. an arbitrary static route. */
  collections: string[];
  /** Committed content pages, for resolving internal link targets. Staged
   * additions/edits/removals are layered on top of this at check time. */
  pages: PageRef[];
  /** Frontmatter image field names per collection id (e.g. blog → ['coverImage',
   * 'socialImage']). Drives the cover/social alt check. */
  imageFields: Record<string, string[]>;
  /** The committed media manifest, for alt text and sizes of referenced images. */
  manifest: MediaManifest;
  /** Site-wide meta description — the last-resort fallback for the SEO check. */
  siteDescription: string;
  /** Per-image weight budget in bytes. Defaults to {@link DEFAULT_IMAGE_BUDGET_BYTES}. */
  imageBudgetBytes?: number;
  /** The COMMITTED nav menu's links, flattened by {@link flattenNavLinks}. The
   * menu breaks when an *entry* is drafted or deleted, not when the nav itself
   * changes, so these are validated on every publish rather than only when a nav
   * edit is staged. A staged `nav.json` change supersedes this at check time, so
   * the editor is checked against the menu they are about to ship. */
  navLinks?: NavLinkRef[];
}

/** One thing the editor may want to look at before publishing. Advisory — a
 * finding never blocks the commit. */
export interface Finding {
  /** The entry/file the finding is about, for the "on «Welcome»" byline. */
  entryTitle: string;
  /** Repo-relative path — stable identity, matches the review list. */
  path: string;
  /** Plain-English description of the single issue. */
  message: string;
}

/** All findings for one check, plus the human framing the panel renders. */
export interface CheckResult {
  id: CheckId;
  /** Short check name, e.g. "Broken links". */
  label: string;
  /** The reassuring line shown when this check has no findings. */
  okLabel: string;
  findings: Finding[];
}

/** The whole preflight result: one entry per check, plus a rolled-up count. */
export interface ChecklistResult {
  checks: CheckResult[];
  /** Total findings across every check. 0 → the all-clear state. */
  totalIssues: number;
  /** True when nothing needs attention — the green, ready-to-ship state. */
  allClear: boolean;
}

function clean(v: FrontmatterValue | undefined): string {
  return typeof v === 'string' ? v.trim() : '';
}

/** Whether an area is a site singleton (settings/nav/media/…) rather than a
 * content collection. */
function isSingleton(area: ChangeArea): boolean {
  return (SINGLETONS as readonly string[]).includes(area);
}

/** A staged change the entry checks apply to: a content entry (not a singleton),
 * written as text (not a binary upload), and not a deletion (a removed file has
 * nothing to check). */
function isContentEntryChange(change: PendingChange): boolean {
  return !isSingleton(change.collection) && !isBinary(change) && !isDeletion(change);
}

/**
 * All `[text](url)` links and `![alt](url)` images in a markdown body, tagged by
 * which they are. One scan handles both because an image is just a link with a
 * leading `!` — so we capture that `!` and branch on it. The optional trailing
 * `"title"` / `'title'` is tolerated and dropped.
 */
export interface MarkdownRef {
  isImage: boolean;
  /** The link/alt text between the brackets, verbatim (may be empty). */
  text: string;
  /** The URL/href inside the parentheses. */
  url: string;
}

const REF_RE = /(!?)\[([^\]]*)\]\(\s*([^)\s]+)(?:\s+(?:"[^"]*"|'[^']*'))?\s*\)/g;

export function extractRefs(body: string): MarkdownRef[] {
  const refs: MarkdownRef[] = [];
  for (const m of body.matchAll(REF_RE)) {
    refs.push({ isImage: m[1] === '!', text: m[2], url: m[3] });
  }
  return refs;
}

/**
 * Whether a URL points somewhere inside this site (so a content-page link is
 * worth validating). External URLs, `mailto:`/`tel:`, protocol-relative `//host`,
 * and pure `#anchor` fragments are all "not internal" and left alone.
 */
export function isInternalUrl(url: string): boolean {
  const u = url.trim();
  if (u === '') return false;
  if (u.startsWith('#')) return false;
  if (u.startsWith('//')) return false;
  if (/^[a-z][a-z0-9+.-]*:/i.test(u)) return false; // any scheme: http:, mailto:, tel:, data:
  return true;
}

/**
 * Resolve an internal URL to the content page it targets, if any. Splits the path
 * into segments (dropping a query/hash and any leading base-path segments) and
 * looks for a `<collection>/<slug>` pair where the collection is known. Returns
 * `null` when the link isn't a content-page link (a static route, an asset, the
 * home page) — those are deliberately never flagged, to avoid false positives on
 * routes the checklist can't know about.
 */
export function resolveInternalTarget(
  url: string,
  collections: string[],
): { collection: string; slug: string } | null {
  const path = url.split(/[?#]/)[0];
  const segments = path.split('/').filter((s) => s !== '' && s !== '.');
  const known = new Set(collections);
  for (let i = 0; i < segments.length - 1; i++) {
    if (known.has(segments[i])) {
      return { collection: segments[i], slug: segments[i + 1] };
    }
  }
  return null;
}

/**
 * The effective set of content pages once the staged changes are applied to the
 * committed set: staged additions/edits set (or update) a page's draft flag, and
 * a staged deletion removes it. Keyed `<collection>/<slug>`. This is what link
 * targets are validated against, so a link to a brand-new page being published in
 * the SAME batch resolves correctly rather than reading as broken.
 */
function effectivePages(changes: PendingChange[], context: ChecklistContext): Map<string, PageRef> {
  const pages = new Map<string, PageRef>();
  for (const p of context.pages) {
    pages.set(`${p.collection}/${p.slug}`, p);
  }
  const collections = new Set(context.collections);
  for (const change of changes) {
    if (isSingleton(change.collection) || isBinary(change)) continue;
    if (!collections.has(change.collection)) continue;
    const key = `${change.collection}/${change.slug}`;
    if (isDeletion(change)) {
      pages.delete(key);
      continue;
    }
    const { data } = parseEntry(change.updated);
    pages.set(key, { collection: change.collection, slug: change.slug, draft: data.draft === true });
  }
  return pages;
}

/** Whether a parsed entry is a draft in its staged state (won't be live). Draft
 * pages are skipped by the live-site checks — a hidden page's links/SEO don't
 * affect visitors. */
function isDraftEntry(data: Record<string, FrontmatterValue>): boolean {
  return data.draft === true;
}

/** The entry's own title for SEO purposes: the `title` or `name` field, blank if
 * neither is set. (Unlike `entryLabel`, this does NOT fall back to the slug —
 * the slug is not a real page title.) */
function entryTitleValue(data: Record<string, FrontmatterValue>): string {
  return clean(data.title) || clean(data.name);
}

/** The entry's own description prose for SEO. Different collections name their
 * prose field differently — `summary` (blog), `description` (pages/events), `bio`
 * (team), `excerpt` (custom) — so any of them counts as "has a description",
 * which keeps the check from false-flagging a team member who wrote a full bio. */
function entryDescriptionValue(data: Record<string, FrontmatterValue>): string {
  return clean(data.summary) || clean(data.description) || clean(data.bio) || clean(data.excerpt);
}

/** Decoded byte size of a base64 payload (a staged image upload's bytes), without
 * allocating the decoded buffer. */
export function base64ByteLength(base64: string): number {
  const s = base64.trim();
  if (s === '') return 0;
  const padding = s.endsWith('==') ? 2 : s.endsWith('=') ? 1 : 0;
  return Math.floor((s.length * 3) / 4) - padding;
}

/**
 * Build a url → byte-size map for every image in play: committed assets from the
 * manifest, plus each staged upload sized directly from its base64 bytes (which
 * override the committed size for a re-uploaded filename). Lets the oversized
 * check size both a freshly-uploaded image and a committed one referenced in
 * staged content.
 */
function imageSizeMap(changes: PendingChange[], manifest: MediaManifest): Map<string, number> {
  const sizes = new Map<string, number>();
  for (const asset of manifest.assets) {
    if (asset.sizeBytes != null) sizes.set(asset.url, asset.sizeBytes);
  }
  for (const change of changes) {
    if (change.collection === 'media' && isBinary(change)) {
      // path is `public/images/<filename>`; the referenced url is `/images/<filename>`.
      const url = change.path.replace(/^public/, '');
      sizes.set(url, base64ByteLength(change.updated));
    }
  }
  return sizes;
}

/** A display filename for an image url, for the "hero.jpg is 3.4 MB" message. */
function imageName(url: string): string {
  const last = url.split('/').filter(Boolean).pop() ?? url;
  return last || url;
}

// ── The four checks ────────────────────────────────────────────────────────

/**
 * What's wrong with the page a link points at, or `null` when nothing is:
 * `'missing'` — no such page; `'draft'` — it exists but won't be live. A link
 * this check can't judge is also `null`: an external url, or an internal one
 * that resolves to no known collection (a static route, an asset, the home
 * page). Those are deliberately never flagged, to avoid false positives on
 * routes the checklist can't know about.
 *
 * The single place "is this link broken?" is decided, so a body link and a nav
 * link are judged by identical rules by construction rather than by two copies
 * that happen to agree.
 */
export function linkTargetStatus(
  url: string,
  collections: string[],
  pages: Map<string, PageRef>,
): 'missing' | 'draft' | null {
  if (!isInternalUrl(url)) return null;
  const target = resolveInternalTarget(url, collections);
  if (!target) return null;
  const page = pages.get(`${target.collection}/${target.slug}`);
  if (!page) return 'missing';
  return page.draft ? 'draft' : null;
}

function checkBrokenLinks(entries: ParsedContentChange[], context: ChecklistContext, all: PendingChange[]): Finding[] {
  const pages = effectivePages(all, context);
  const findings: Finding[] = [];
  for (const entry of entries) {
    for (const ref of entry.refs) {
      if (ref.isImage) continue;
      const status = linkTargetStatus(ref.url, context.collections, pages);
      if (!status) continue;
      findings.push({
        entryTitle: entry.title,
        path: entry.path,
        message:
          status === 'missing'
            ? `Links to “${ref.url}”, a page that doesn’t exist.`
            : `Links to “${ref.url}”, which is still a draft and won’t be live.`,
      });
    }
  }
  return [...findings, ...checkNavLinks(all, context, pages)];
}

/**
 * Menu items pointing at pages that won't be there. Run against the same
 * effective page set as the body links, so an item pointing at an entry this
 * batch drafts or deletes is caught — and one whose item is removed in the SAME
 * batch resolves clean, for free. Findings are filed against the nav singleton
 * so the byline matches the nav's row in the review list.
 */
function checkNavLinks(all: PendingChange[], context: ChecklistContext, pages: Map<string, PageRef>): Finding[] {
  const findings: Finding[] = [];
  for (const link of navLinksToCheck(all, context)) {
    const status = linkTargetStatus(link.url, context.collections, pages);
    if (!status) continue;
    findings.push({
      entryTitle: NAV_TITLE,
      path: NAV_PATH,
      message:
        status === 'missing'
          ? `The menu item “${link.label}” points to “${link.url}”, a page that doesn’t exist.`
          : `The menu item “${link.label}” points to “${link.url}”, which is still a draft and won’t be live.`,
    });
  }
  return findings;
}

/**
 * The nav links to validate for this publish: the staged `nav.json` when the
 * batch edits the menu (so the editor is checked against what they are about to
 * ship), else the committed nav from the context. A malformed staged nav falls
 * back to the committed one rather than throwing the whole checklist — a
 * half-typed menu must never blank the panel.
 */
function navLinksToCheck(all: PendingChange[], context: ChecklistContext): NavLinkRef[] {
  const committed = context.navLinks ?? [];
  const staged = all.find((c) => c.path === NAV_PATH && !isDeletion(c) && !isBinary(c));
  if (!staged) return committed;
  try {
    return flattenNavLinks(JSON.parse(staged.updated) as SiteNav);
  } catch {
    return committed;
  }
}

function checkMissingAlt(entries: ParsedContentChange[], context: ChecklistContext): Finding[] {
  const findings: Finding[] = [];
  for (const entry of entries) {
    // Body images: an empty `![](url)` alt is missing.
    for (const ref of entry.refs) {
      if (!ref.isImage) continue;
      if (ref.text.trim() === '') {
        findings.push({
          entryTitle: entry.title,
          path: entry.path,
          message: `An image in the body has no alt text${describeImage(ref.url)}.`,
        });
      }
    }
    // Cover / social frontmatter images: alt lives on the media asset, not the
    // frontmatter — flag when the referenced asset has no alt recorded.
    const fields = context.imageFields[entry.collection] ?? [];
    for (const field of fields) {
      const url = clean(entry.data[field]);
      if (url === '') continue;
      const asset = findAssetByUrl(context.manifest, url);
      if (asset && (asset.alt == null || asset.alt.trim() === '')) {
        findings.push({
          entryTitle: entry.title,
          path: entry.path,
          message: `The ${humanField(field)} (${imageName(url)}) has no alt text.`,
        });
      }
    }
  }
  return findings;
}

function checkMissingSeo(entries: ParsedContentChange[], context: ChecklistContext): Finding[] {
  const findings: Finding[] = [];
  for (const entry of entries) {
    const seoTitle = clean(entry.data.seoTitle);
    const title = entryTitleValue(entry.data);
    if (seoTitle === '' && title === '') {
      findings.push({
        entryTitle: entry.title,
        path: entry.path,
        message: 'No page title — search results and share cards will show only the site name.',
      });
    }
    const seoDescription = clean(entry.data.seoDescription);
    const entryDescription = entryDescriptionValue(entry.data);
    if (seoDescription === '' && entryDescription === '' && clean(context.siteDescription) === '') {
      findings.push({
        entryTitle: entry.title,
        path: entry.path,
        message: 'No meta description — add a summary so search and social previews read well.',
      });
    }
  }
  return findings;
}

function checkOversizedImages(entries: ParsedContentChange[], context: ChecklistContext, all: PendingChange[]): Finding[] {
  const budget = context.imageBudgetBytes ?? DEFAULT_IMAGE_BUDGET_BYTES;
  const sizes = imageSizeMap(all, context.manifest);
  const findings: Finding[] = [];
  const seen = new Set<string>();

  const flag = (url: string, bytes: number, title: string, path: string) => {
    if (bytes <= budget || seen.has(url)) return;
    seen.add(url);
    findings.push({
      entryTitle: title,
      path,
      message: `${imageName(url)} is ${formatSize(bytes)} — over the ${formatSize(budget)} budget. Recompress it to speed up the page.`,
    });
  };

  // Staged uploads always ship in the commit — size them directly.
  for (const change of all) {
    if (change.collection === 'media' && isBinary(change)) {
      const url = change.path.replace(/^public/, '');
      flag(url, base64ByteLength(change.updated), change.title, change.path);
    }
  }
  // Images referenced in staged content, sized via committed/staged manifest.
  for (const entry of entries) {
    const urls = [
      ...entry.refs.filter((r) => r.isImage).map((r) => r.url),
      ...(context.imageFields[entry.collection] ?? []).map((f) => clean(entry.data[f])).filter(Boolean),
    ];
    for (const url of urls) {
      const bytes = sizes.get(url);
      if (bytes != null) flag(url, bytes, entry.title, entry.path);
    }
  }
  return findings;
}

/** A staged content entry parsed once, so every check reuses the same parse. */
interface ParsedContentChange {
  title: string;
  path: string;
  collection: string;
  data: Record<string, FrontmatterValue>;
  body: string;
  refs: MarkdownRef[];
}

/** Human-friendly frontmatter image field name for a finding message. */
function humanField(field: string): string {
  switch (field) {
    case 'coverImage':
      return 'cover image';
    case 'socialImage':
      return 'social share image';
    case 'photo':
      return 'photo';
    default:
      return field;
  }
}

/** A trailing " (filename.jpg)" clause when the image url has a filename, else ''. */
function describeImage(url: string): string {
  const name = imageName(url);
  return name ? ` (${name})` : '';
}

/**
 * Run every preflight check over the staging set and return the grouped,
 * advisory result. Pure: given the same changes + context it always returns the
 * same findings, so the panel and the unit tests exercise identical logic. Draft
 * entries and non-content areas are excluded from the live-site checks; staged
 * image uploads are always sized because they ship in the commit regardless.
 */
export function runPublishChecklist(changes: PendingChange[], context: ChecklistContext): ChecklistResult {
  const entries: ParsedContentChange[] = [];
  for (const change of changes) {
    if (!isContentEntryChange(change)) continue;
    const { data, body } = parseEntry(change.updated);
    if (isDraftEntry(data)) continue; // a hidden draft doesn't affect the live site
    entries.push({
      title: change.title,
      path: change.path,
      collection: change.collection,
      data,
      body,
      refs: extractRefs(body),
    });
  }

  const checks: CheckResult[] = [
    {
      id: 'broken-links',
      label: 'Links work',
      okLabel: 'All internal links point to real, published pages',
      findings: checkBrokenLinks(entries, context, changes),
    },
    {
      id: 'missing-alt',
      label: 'Images have alt text',
      okLabel: 'Every image has descriptive alt text',
      findings: checkMissingAlt(entries, context),
    },
    {
      id: 'missing-seo',
      label: 'Pages are search-ready',
      okLabel: 'Every page has a title and description for search & social',
      findings: checkMissingSeo(entries, context),
    },
    {
      id: 'oversized-images',
      label: 'Images are web-sized',
      okLabel: 'No oversized images slowing the page down',
      findings: checkOversizedImages(entries, context, changes),
    },
  ];

  const totalIssues = checks.reduce((sum, c) => sum + c.findings.length, 0);
  return { checks, totalIssues, allClear: totalIssues === 0 };
}

/**
 * The one-line summary shown in the panel header: reassuring when all-clear, and
 * an advisory, pressure-free nudge ("N things worth a look … you can still
 * publish") otherwise, with singular/plural grammar. Pure so the exact copy is
 * unit-tested rather than asserted against a rendered screenshot.
 */
export function checklistHeadline(result: Pick<ChecklistResult, 'allClear' | 'totalIssues'>): string {
  if (result.allClear) return 'Looks good — nothing to fix before you publish.';
  const n = result.totalIssues;
  const thing = n === 1 ? 'thing' : 'things';
  return `${n} ${thing} worth a look. You can still publish — these are just suggestions.`;
}
