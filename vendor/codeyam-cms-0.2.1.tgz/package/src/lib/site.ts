// Site-wide data loaded from editable JSON singletons under `src/data/`.
//
// `settings.json` and `nav.json` are content, not code: the CMS edits them as
// Sveltia "file" collections, and every layout reads them through this module.
// Changing the contact email, a social link, or a menu item is therefore a
// data edit (a commit the CMS makes), never a source change. codeyam's
// `content-collection` seed adapter rewrites these same files per scenario, so
// a scenario can render "site with 3 socials and a chapters dropdown" vs a
// minimal nav without touching markup.
//
// The singletons are read at build/render time with `fs` (rather than a static
// `import ... from '../data/settings.json'`) so the data root can be
// redirected: in production it resolves to `src/data`, but during a codeyam
// session it points at the `.codeyam/tmp` sandbox so seeding never mutates
// committed source. A static import is bundled from a fixed path and cannot be
// redirected. This runs in Node at build/render time, so `fs` is available for
// both the dev server and the production GitHub Pages build.
import * as fs from 'fs';
import * as path from 'path';
import { resolveDataRoot } from './contentRoot';
import type { SiteNav, SiteSettings } from './siteConfig';
import { EMPTY_REGISTRY, type CollectionsRegistry } from './collectionRegistry';
import { EMPTY_EDITORS, readEditorsRegistry, type EditorsRegistry } from './editorsRegistry';

// The editable shape of these singletons lives in `siteConfig.ts` (browser-safe,
// no `fs`) so the admin editor islands can import it without pulling `fs` into
// the client bundle. Re-exported here for the layouts that already import their
// types from `site.ts`.
export type { SocialLink, SiteSettings, NavItem, SiteNav } from './siteConfig';

const readSingletonFrom = <T>(name: string): T =>
  JSON.parse(fs.readFileSync(path.join(resolveDataRoot(), `${name}.json`), 'utf-8')) as T;

/** Read the site settings fresh from disk — used by the admin editor page so it
 * reflects the current (per-scenario seeded) singleton, not a module-load snapshot. */
export const readSettings = (): SiteSettings => readSingletonFrom<SiteSettings>('settings');
/** Read the nav menu fresh from disk. */
export const readNav = (): SiteNav => readSingletonFrom<SiteNav>('nav');

/**
 * Read the custom-collection registry fresh from disk. Unlike settings/nav this
 * singleton is optional — a project that predates the feature (or a scenario that
 * seeds none) has no `collections.json`, so a missing/empty file resolves to the
 * empty registry rather than throwing.
 */
export const readCollectionsRegistry = (): CollectionsRegistry => {
  try {
    const reg = readSingletonFrom<CollectionsRegistry>('collections');
    return Array.isArray(reg?.collections) ? reg : EMPTY_REGISTRY;
  } catch {
    return EMPTY_REGISTRY;
  }
};

/**
 * Read the editor roster fresh from disk. Like the custom-collection registry
 * this singleton is optional — a project that predates the invite feature (or a
 * scenario that seeds none) has no `editors.json`, so a missing/empty file
 * resolves to the empty roster rather than throwing.
 */
export const readEditors = (): EditorsRegistry => {
  try {
    return readEditorsRegistry(readSingletonFrom<EditorsRegistry>('editors'));
  } catch {
    return EMPTY_EDITORS;
  }
};

export const settings = readSettings();
export const nav = readNav();
