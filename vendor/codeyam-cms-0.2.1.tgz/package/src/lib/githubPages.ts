// Track the GitHub Pages build that a "Commit all" kicked off, so the editor can
// watch its change go from "Committed" to "Live" without leaving the review
// drawer.
//
// Same server-free model as `githubCommit`: a static GitHub Pages site has no
// server of ours, so we poll the GitHub REST API straight from the browser with
// the same token the committer used. The network layer is injected (`fetchFn`),
// so the pure mapping unit-tests against a fake transport and the scenarios can
// drive each pipeline stage (queued / building / live / failed) without a live
// repo.
//
// We read the *legacy* Pages build endpoint (`GET /pages/builds/latest`), which
// covers a branch-based Pages site — exactly the "commit to the branch → Pages
// rebuilds" model this CMS commits into. Its `status` is one of
// queued → building → built | errored, which maps 1:1 onto the stages the drawer
// surfaces.

import type { FetchFn, RepoTarget } from './githubCommit';

/**
 * The stages the deploy view surfaces, in pipeline order. `committed` is the
 * moment the commit landed (before Pages has reacted to it); `queued` and
 * `building` are the live Pages-build states; `verifying` is the gap between a
 * finished build and the new bytes actually being served; `live` and `failed`
 * are terminal.
 */
export type DeployStage = 'committed' | 'queued' | 'building' | 'verifying' | 'live' | 'failed';

/** GitHub's raw Pages build `status` values (plus a catch-all for forward-compat). */
export type PagesBuildStatus = 'queued' | 'building' | 'built' | 'errored' | (string & {});

/** The slice of `GET /pages/builds/latest` we consume. The `commit` /
 * `createdAt` / `updatedAt` fields are only needed for the "last deploy"
 * summary (the poller ignores them), so they are optional and back-compatible
 * with fixtures that predate them. */
export interface PagesBuild {
  status: PagesBuildStatus;
  error?: { message?: string | null } | null;
  /** SHA of the commit this build published. */
  commit?: string | null;
  /** ISO timestamp the build was created. */
  createdAt?: string | null;
  /** ISO timestamp the build last changed (its finish time once terminal). */
  updatedAt?: string | null;
}

/** The editor-facing state of the deploy, derived from the latest Pages build. */
export interface DeployState {
  stage: DeployStage;
  /** GitHub's error message when the build errored. */
  error?: string;
}

/** The ordered stages a deploy passes through, for rendering the stepper. */
export const DEPLOY_STAGES: readonly DeployStage[] = ['committed', 'queued', 'building', 'verifying', 'live'];

/** How a step reads in the stepper relative to the current stage. */
export type StepVisual = 'done' | 'active' | 'pending' | 'failed';

/** Human label for each stepper row. */
export const STAGE_LABEL: Record<DeployStage, string> = {
  committed: 'Committed to GitHub',
  queued: 'Build queued',
  building: 'Building site',
  // Says what is actually happening rather than naming the mechanism: the build
  // is finished and we are waiting for the change to reach the reader.
  verifying: 'Waiting for the site to update',
  live: 'Live',
  failed: 'Build failed',
};

// A failed build reports `errored` without saying which step it died on; we pin
// the failure marker to "Building", the step where a Pages build does its work.
const FAILED_AT = DEPLOY_STAGES.indexOf('building');

/** One row of the deploy stepper: which stage it is, its label, and how it reads. */
export interface DeployStepView {
  stage: DeployStage;
  label: string;
  visual: StepVisual;
}

/**
 * Derive the whole stepper — a row per `DEPLOY_STAGES` entry — from the current
 * deploy stage. Rows before the current one read `done`, the current one is
 * `active` (or `done` once `live`), later ones `pending`. A `failed` stage marks
 * the Building row `failed`, everything before it `done`, and everything after
 * `pending`. The `live` row's label collapses to "Live" once reached (no "site"
 * suffix). Pure, so the stepper's logic unit-tests without rendering.
 */
export function deploySteps(stage: DeployStage): DeployStepView[] {
  const failed = stage === 'failed';
  const live = stage === 'live';
  const currentIdx = failed ? FAILED_AT : DEPLOY_STAGES.indexOf(stage);

  return DEPLOY_STAGES.map((s, i) => {
    let visual: StepVisual;
    if (failed) visual = i < FAILED_AT ? 'done' : i === FAILED_AT ? 'failed' : 'pending';
    else if (i < currentIdx) visual = 'done';
    else if (i === currentIdx) visual = live ? 'done' : 'active';
    else visual = 'pending';
    return { stage: s, label: STAGE_LABEL[s], visual };
  });
}

/**
 * The one-line explanation under the deploy heading, derived from the stage.
 *
 * Pure and beside `deploySteps` for the same reason that one is: `deploySteps`
 * derives the stepper's ROWS from a stage, this derives its COPY, and both are
 * decisions about a stage rather than about rendering. Keeping it here puts
 * every stage-dependent string under test.
 *
 * `verifying` needs its own line rather than sharing the in-flight default:
 * by then GitHub has finished building, so the "rebuilding" copy would be
 * describing work that is already over.
 */
export function deploySubhead(stage: DeployStage, target: RepoTarget): string {
  switch (stage) {
    case 'live':
      return `Published to ${target.owner}/${target.repo} on ${target.branch}.`;
    case 'failed':
      return 'Your changes are committed, but GitHub Pages could not build the site.';
    case 'verifying':
      return 'The build finished. Waiting for your change to reach the live site.';
    default:
      return `GitHub Pages is rebuilding ${target.owner}/${target.repo} from ${target.branch}.`;
  }
}

/**
 * Map a Pages build `status` to the stage the drawer shows. Unknown/undefined
 * statuses are treated as still-in-flight (`queued`) rather than terminal, so a
 * forward-incompatible value never falsely reads as "live" or "failed".
 */
export function stageFromBuildStatus(status: PagesBuildStatus | undefined): DeployStage {
  switch (status) {
    case 'building':
      return 'building';
    case 'built':
      return 'live';
    case 'errored':
      return 'failed';
    case 'queued':
    default:
      return 'queued';
  }
}

/** Is this a terminal stage — the deploy is done polling? */
export function isTerminalStage(stage: DeployStage): boolean {
  return stage === 'live' || stage === 'failed';
}

/** Reduce a fetched Pages build to the editor-facing deploy state. */
export function deployStateFromBuild(build: PagesBuild): DeployState {
  const stage = stageFromBuildStatus(build.status);
  const error = stage === 'failed' ? build.error?.message ?? undefined : undefined;
  return error ? { stage, error } : { stage };
}

/**
 * The live URL of the published site. GitHub Pages for `owner/repo` serves at
 * `https://<owner>.github.io/<repo>/` unless a custom domain is set; that derived
 * URL is the reliable default for the "View live site" link. A project on a
 * custom domain can pass its `siteUrl` through instead (the caller has it from
 * settings).
 */
export function pagesSiteUrl(target: RepoTarget): string {
  return `https://${target.owner}.github.io/${target.repo}/`;
}

/** The GitHub page listing this repo's Pages deployments — where a failed build's log lives. */
export function pagesLogUrl(target: RepoTarget): string {
  return `https://github.com/${target.owner}/${target.repo}/deployments/github-pages`;
}

// ---------------------------------------------------------------------------
// Propagation verification
//
// A finished Pages build is not the same event as the new bytes being served:
// the build reports `built` before the CDN has necessarily caught up, so an
// editor who clicks "View live site" at that moment can be handed the OLD page
// and reasonably conclude the CMS lied. The site itself is the only witness that
// can settle this, so every build stamps a marker file with the commit it was
// built from; when the *served* marker changes, new bytes are live by
// construction — no API can tell us that.
// ---------------------------------------------------------------------------

/**
 * The build-time marker a deployed site serves at `<site>/deploy-status.json`.
 * Every field is optional: the file is written by whatever version of the
 * package built the site, and an older or hand-rolled marker may carry fewer
 * keys. Only `commit` participates in the change check.
 */
export interface DeployMarker {
  /** SHA the build was made from (`GITHUB_SHA`), or `local` off-CI. */
  commit?: string | null;
  /** Actions run that produced the build (`GITHUB_RUN_ID`), for debugging. */
  runId?: string | null;
  /** ISO timestamp the marker was generated. */
  builtAt?: string | null;
}

/**
 * The marker's URL for a given site. Resolved *against* the site URL rather than
 * assumed at the origin root, because a project site is served under
 * `https://owner.github.io/repo/` — hard-coding `/deploy-status.json` would 404
 * on every project-site consumer and silently disable the check.
 */
export function deployMarkerUrl(siteUrl: string): string {
  const base = siteUrl.endsWith('/') ? siteUrl : `${siteUrl}/`;
  return new URL('deploy-status.json', base).toString();
}

/**
 * Has the deploy propagated? Compares the marker read *before* the commit
 * against one read now.
 *
 * Two rules matter more than precision here:
 *
 * 1. **Absent marker ⇒ confirmed.** A site built by an older version of the
 *    package serves no marker, and neither does one that has not rebuilt yet. If
 *    a missing or unfetchable marker blocked confirmation, upgrading would hang
 *    every existing consumer's stepper on a file that will never appear. Failure
 *    to verify is not evidence of failure to deploy.
 * 2. **Compare by CHANGE, not against a specific SHA.** Matching the commit the
 *    CMS just created looks more precise but breaks the moment anyone else
 *    pushes inside the same window: the deployed build then carries a later SHA
 *    and an equality check waits forever for a value that will never be served.
 *    "It changed" is the property that actually means "new bytes".
 *
 * Pure, so the whole rule unit-tests without a network.
 */
export function isPropagationConfirmed(
  baseline: DeployMarker | null | undefined,
  current: DeployMarker | null | undefined,
): boolean {
  if (!baseline?.commit) return true;
  if (!current?.commit) return true;
  return current.commit !== baseline.commit;
}

/**
 * Read the deployed site's marker. Returns `null` for anything that is not a
 * readable marker — a 404, a network error, a body that is not JSON — because
 * every one of those means "cannot verify", which the caller degrades to
 * "confirmed" rather than treating as a deploy failure.
 *
 * `cacheBust` must vary between calls: the marker is a static file behind a CDN,
 * so an un-busted poll can be served the same cached copy indefinitely and would
 * measure the cache rather than the deploy.
 */
export async function fetchDeployMarker(
  markerUrl: string,
  fetchFn: FetchFn,
  cacheBust: string | number,
): Promise<DeployMarker | null> {
  const sep = markerUrl.includes('?') ? '&' : '?';
  try {
    const res = await fetchFn(`${markerUrl}${sep}_cb=${cacheBust}`, {
      method: 'GET',
      headers: { 'Cache-Control': 'no-cache, no-store', Pragma: 'no-cache' },
    });
    if (!res.ok) return null;
    return (await res.json()) as DeployMarker;
  } catch {
    return null;
  }
}

async function ghPages(
  fetchFn: FetchFn,
  token: string,
  target: RepoTarget,
  endpoint: string,
): Promise<{ ok: boolean; status: number; body: any }> {
  const url = `https://api.github.com/repos/${target.owner}/${target.repo}/${endpoint}`;
  const res = await fetchFn(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
    },
  });
  if (!res.ok) return { ok: false, status: res.status, body: null };
  return { ok: true, status: res.status, body: await res.json() };
}

/**
 * Fetch the most recent Pages build. Returns `null` when Pages has no build yet
 * — a 404 right after the first commit means the build is still being enqueued,
 * which the poller treats as "queued", not an error.
 */
export async function fetchLatestBuild(
  target: RepoTarget,
  token: string,
  fetchFn: FetchFn,
): Promise<PagesBuild | null> {
  const res = await ghPages(fetchFn, token, target, 'pages/builds/latest');
  if (!res.ok) {
    if (res.status === 404) return null;
    throw new Error(`GitHub GET pages/builds/latest failed (${res.status})`);
  }
  return {
    status: res.body?.status,
    error: res.body?.error ?? null,
    commit: res.body?.commit ?? null,
    createdAt: res.body?.created_at ?? null,
    updatedAt: res.body?.updated_at ?? null,
  };
}

/**
 * The most recent deploy, summarized for the Publish page's "you're all caught
 * up" resting state: which stage it reached, when it landed, the commit it
 * published, and the live URL.
 */
export interface LastDeploy {
  /** Stage of the latest build (usually `live`; `failed` if the last build errored). */
  stage: DeployStage;
  /** ISO timestamp of the build — its finish time when terminal. */
  when?: string;
  /** Human URL of the published commit, when the build names one. */
  commitUrl?: string;
  /** The live site URL. */
  siteUrl: string;
}

/**
 * Format a deploy timestamp for display in the Publish resting state. Pinned to
 * a fixed locale and UTC so a server render and its client hydration agree — a
 * default (system-locale, local-timezone) format renders differently on the
 * Node server than in the browser and trips a React hydration mismatch. Returns
 * '' for an absent or unparseable value so the caller can omit the clause.
 */
export function formatDeployTime(iso: string | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'UTC' })} UTC`;
}

/** Reduce a fetched Pages build to the last-deploy summary. Pure mapping — the
 * network is the caller's concern — so the timestamp/commit derivation
 * unit-tests without a live repo. */
export function lastDeployFromBuild(build: PagesBuild, target: RepoTarget): LastDeploy {
  const when = build.updatedAt ?? build.createdAt ?? undefined;
  const commitUrl = build.commit
    ? `https://github.com/${target.owner}/${target.repo}/commit/${build.commit}`
    : undefined;
  return {
    stage: stageFromBuildStatus(build.status),
    ...(when ? { when } : {}),
    ...(commitUrl ? { commitUrl } : {}),
    siteUrl: pagesSiteUrl(target),
  };
}

/**
 * Fetch the most recent deploy for the Publish resting state. Returns `null`
 * when Pages has never built this repo (a 404 from the builds endpoint) — the
 * "no deploys yet" case — so a first-time project reads as un-deployed rather
 * than errored.
 */
export async function fetchLastDeploy(
  target: RepoTarget,
  token: string,
  fetchFn: FetchFn,
): Promise<LastDeploy | null> {
  const build = await fetchLatestBuild(target, token, fetchFn);
  if (!build) return null;
  return lastDeployFromBuild(build, target);
}

/** A sampled marker plus where it was read from, ready to hand to `pollDeploy`. */
export interface DeployBaseline {
  markerUrl: string;
  markerBaseline: DeployMarker | null;
}

/**
 * Sample the deployed site's marker so a later poll can watch it change. MUST be
 * called before the commit — once the commit lands, the site may already be
 * serving the new marker and there is nothing left to compare against.
 *
 * Both commit paths call this rather than assembling the URL and the read
 * themselves, so the base-path derivation and the "a failed read is not an
 * error" rule can't be re-derived differently (or forgotten) by a third caller.
 * A failure here yields a null baseline, which downstream disables verification.
 */
export async function readDeployBaseline(
  target: RepoTarget,
  fetchFn: FetchFn,
  siteUrl?: string,
): Promise<DeployBaseline> {
  const markerUrl = deployMarkerUrl(siteUrl || pagesSiteUrl(target));
  return { markerUrl, markerBaseline: await fetchDeployMarker(markerUrl, fetchFn, Date.now()) };
}

export interface PollOptions {
  /** Delay between polls while the build is in-flight. Default 3000ms. */
  intervalMs?: number;
  /** Give up (stay on the last in-flight stage) after this long. Default 180000ms. */
  timeoutMs?: number;
  /** Injected sleep so tests advance without real time. */
  sleep?: (ms: number) => Promise<void>;
  /** Injected clock so tests control the timeout deadline. */
  now?: () => number;
  /**
   * Where the deployed site serves its marker. Omit to skip propagation
   * verification entirely — the poll then behaves exactly as it did before the
   * check existed.
   */
  markerUrl?: string;
  /**
   * The marker as it read *before* this commit. Passed in rather than fetched
   * here because it must be sampled before the commit lands, which only the
   * caller can sequence. A null/marker-less baseline disables verification.
   */
  markerBaseline?: DeployMarker | null;
  /** How long to wait for the served marker to change. Default 45000ms. */
  verifyTimeoutMs?: number;
}

const defaultSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/**
 * Poll the deployed marker until it differs from `baseline` or the budget runs
 * out. Returns whether propagation was confirmed — but note the caller reports
 * `live` either way: an unconfirmed deploy is an unproven one, not a failed one.
 */
async function awaitPropagation(
  markerUrl: string,
  baseline: DeployMarker,
  fetchFn: FetchFn,
  intervalMs: number,
  verifyTimeoutMs: number,
  sleep: (ms: number) => Promise<void>,
  now: () => number,
): Promise<boolean> {
  const deadline = now() + verifyTimeoutMs;
  // The injected clock may be constant in tests, so the attempt counter — not
  // the timestamp — is what guarantees the cache-buster actually varies.
  let attempt = 0;

  while (true) {
    const current = await fetchDeployMarker(markerUrl, fetchFn, `${now()}-${attempt++}`);
    if (isPropagationConfirmed(baseline, current)) return true;
    if (now() >= deadline) return false;
    await sleep(intervalMs);
  }
}

/**
 * Poll the latest Pages build until it reaches a terminal stage (live / failed)
 * or the timeout elapses, calling `onUpdate` on every stage change so the drawer
 * animates through queued → building → verifying → live. A missing build (404)
 * reads as `queued` — the build is still being enqueued. Returns the final state.
 *
 * When the build reports built, the poll does NOT immediately report `live`: it
 * emits `verifying` and waits for the site's own marker to change, so `live`
 * means the change is actually being served. Verification is skipped entirely
 * unless the caller supplies both a `markerUrl` and a `markerBaseline` that
 * carries a commit, which is what keeps this invisible to a consumer whose site
 * serves no marker.
 */
export async function pollDeploy(
  target: RepoTarget,
  token: string,
  fetchFn: FetchFn,
  onUpdate: (state: DeployState) => void,
  opts: PollOptions = {},
): Promise<DeployState> {
  const intervalMs = opts.intervalMs ?? 3000;
  const timeoutMs = opts.timeoutMs ?? 180000;
  const sleep = opts.sleep ?? defaultSleep;
  const now = opts.now ?? (() => Date.now());

  const deadline = now() + timeoutMs;
  let last: DeployState = { stage: 'committed' };
  onUpdate(last);

  // Verification needs somewhere to look AND something to compare against. A
  // baseline with no commit means the site served no marker before the commit,
  // so waiting for one to change would wait forever — skip straight to `live`,
  // exactly as this poll behaved before the check existed.
  const baseline = opts.markerBaseline;
  const verify = Boolean(opts.markerUrl && baseline?.commit);

  while (true) {
    const build = await fetchLatestBuild(target, token, fetchFn);
    const state: DeployState = build ? deployStateFromBuild(build) : { stage: 'queued' };

    // `built` is where the old behavior stopped. Hold here instead: the build is
    // done, but the reader may still be served the previous page.
    if (state.stage === 'live') {
      if (verify) {
        last = { stage: 'verifying' };
        onUpdate(last);
        await awaitPropagation(
          opts.markerUrl!,
          baseline!,
          fetchFn,
          intervalMs,
          opts.verifyTimeoutMs ?? 45000,
          sleep,
          now,
        );
      }
      // Reported live whether or not propagation was confirmed: a slow marker is
      // not a broken deploy, and calling a successful publish "failed" would be
      // a worse lie than the one this check exists to fix.
      last = state;
      onUpdate(state);
      return state;
    }

    if (state.stage !== last.stage || state.error !== last.error) {
      last = state;
      onUpdate(state);
    }
    if (isTerminalStage(state.stage)) return state;
    if (now() >= deadline) return last;
    await sleep(intervalMs);
  }
}
