// The custom-collection registry: the framework-free heart of "create a
// collection from the admin UI".
//
// Built-in collections (pages/blog/events/team) are defined in code
// (`content/config.ts` + `adminDashboard`/`entryEditor`). Editor-created
// collections live in the `src/data/collections.json` singleton instead, edited
// the same way settings.json / nav.json are: stage a canonical-serialized change,
// review it, commit it in one GitHub commit. This module owns that singleton's
// shape, the merge of built-ins + custom into one resolved list the admin renders,
// the builder's field-row edit helpers (the `navEditor` pattern), validation, and
// the `PendingChange` builder. `fs`-free and DOM-free so it runs in the browser
// builder island AND unit-tests directly.

import {
  CONTENT_FIELDS,
  DRAFT_FIELD,
  SEO_FIELDS,
  resolveSeoFields,
  type FieldDef,
  type FieldType,
} from './entryEditor';
import { ADMIN_COLLECTIONS, type BuiltinCollectionName, type CollectionName } from './adminDashboard';
import { slugify } from './slug';
import { moveInArray, reorderInArray } from './siteConfig';
import type { PendingChange } from './pendingChanges';

/** Repo-relative path of the registry singleton — the staged change's identity. */
export const COLLECTIONS_PATH = 'src/data/collections.json';

/** The field types an editor can choose in the builder — the editor's full
 * `FieldType`, since every member is declarable. `number` writes a real JSON
 * number to frontmatter (the shape a built-in `order` field already has), and
 * `boolean` renders as a toggle via the existing `EntryField` boolean input, so
 * a consumer field like `team.active` can be declared. `list` is a repeatable
 * group of scalar sub-fields (top-level only — a list's sub-fields cannot be
 * lists). The markdown body is not here: it is implicit on every entry. */
export type CustomFieldType = Extract<
  FieldType,
  'text' | 'number' | 'textarea' | 'date' | 'image' | 'boolean' | 'list'
>;

/** The scalar sub-field types a `list` row may hold — {@link CUSTOM_FIELD_TYPES}
 * minus `list`, since nested lists are not supported. */
export type SubFieldType = Exclude<CustomFieldType, 'list'>;

/** The picker options for a field's type, in menu order. */
export const CUSTOM_FIELD_TYPES: { type: CustomFieldType; label: string }[] = [
  { type: 'text', label: 'Short text' },
  { type: 'number', label: 'Number' },
  { type: 'textarea', label: 'Long text' },
  { type: 'date', label: 'Date' },
  { type: 'image', label: 'Image' },
  { type: 'boolean', label: 'Toggle' },
  { type: 'list', label: 'Repeatable list' },
];

/** The type picker for a `list`'s sub-fields — scalar types only. */
export const SUBFIELD_TYPES = CUSTOM_FIELD_TYPES.filter((t) => t.type !== 'list');

/** One editor-defined collection stored in the registry. Its `fields` are the
 * structured frontmatter fields only — the markdown Body and the Draft toggle are
 * implicit and re-attached when the collection is resolved for the editor. */
export interface CustomCollection {
  id: string;
  label: string;
  singular: string;
  fields: FieldDef[];
}

/** The `collections.json` singleton. */
export interface CollectionsRegistry {
  collections: CustomCollection[];
  /**
   * Consumer-declared EXTRA fields appended to a built-in collection's editor,
   * keyed by built-in name. Merged after the built-in's core fields and before
   * the SEO group; an extra that would shadow a core field, the SEO group, or a
   * reserved id is dropped. Absent → the built-in shows only its core fields.
   */
  builtins?: Partial<Record<BuiltinCollectionName, FieldDef[]>>;
  /**
   * Consumer-defined SEO & Social group. When present it replaces the default
   * {@link SEO_FIELDS} across every collection (built-in and custom), so a site
   * whose frontmatter uses `metaTitle`/`ogImage` can edit those keys. Absent →
   * the default group. The field `name`s must match the consumer's content
   * schema (`content-helpers` `seoFields`).
   */
  seo?: FieldDef[];
}

/** Production / never-seeded default: no custom collections. */
export const EMPTY_REGISTRY: CollectionsRegistry = { collections: [] };

/** A collection resolved for the admin: identity + the full editor field list
 * (custom collections get `draft` appended so they render exactly like built-ins). */
export interface ResolvedCollection {
  id: CollectionName;
  label: string;
  singular: string;
  builtin: boolean;
  /** The editable fields the entry editor renders, in order. */
  fields: FieldDef[];
}

// Field ids that would collide with the frontmatter/body machinery or the
// implicit draft toggle, and collection ids that would collide with an existing
// /admin route. Blocked in the builder so a custom definition can't shadow them.
const RESERVED_FIELD_IDS = new Set([
  'draft',
  'body',
  'content',
  'slug',
  'id',
  // The universal SEO group is appended to every collection, so a custom field
  // can't shadow one of its keys.
  ...SEO_FIELDS.map((f) => f.name),
]);
const RESERVED_COLLECTION_IDS = new Set(['new', 'media', 'settings', 'collections']);

// ─── Merge built-ins + custom ────────────────────────────────────────────────

/** Consumer extras for a built-in, minus any whose id would shadow one of the
 * built-in's core fields, the resolved SEO group, or a reserved id — and
 * de-duplicated within the list. Invalid extras are dropped silently so a stray
 * registry line can't break the dashboard. */
function validBuiltinExtras(extras: FieldDef[], core: FieldDef[], seo: FieldDef[]): FieldDef[] {
  const taken = new Set<string>([
    ...core.map((f) => f.name),
    ...seo.map((f) => f.name),
    ...RESERVED_FIELD_IDS,
  ]);
  const out: FieldDef[] = [];
  for (const f of extras ?? []) {
    if (!f?.name || taken.has(f.name)) continue;
    taken.add(f.name);
    out.push(normalizeField(f));
  }
  return out;
}

function builtinResolved(reg: CollectionsRegistry): ResolvedCollection[] {
  const seo = resolveSeoFields(reg);
  return ADMIN_COLLECTIONS.map((def) => {
    const name = def.collection as BuiltinCollectionName;
    const core = CONTENT_FIELDS[name];
    return {
      id: def.collection,
      label: def.label,
      singular: def.singular,
      builtin: true,
      fields: [...core, ...validBuiltinExtras(reg.builtins?.[name] ?? [], core, seo), ...seo],
    };
  });
}

/** Resolve one custom collection to the admin shape — appending the implicit
 * Draft toggle plus the universal SEO group so its editor form (and its SEO panel)
 * match the built-in collections'. */
export function customToResolved(c: CustomCollection, seo: FieldDef[] = SEO_FIELDS): ResolvedCollection {
  return {
    id: c.id,
    label: c.label,
    singular: c.singular,
    builtin: false,
    fields: [...c.fields, DRAFT_FIELD, ...seo],
  };
}

/** All collections the admin manages: the built-in four followed by the registry's
 * custom collections, in registry order. Every collection's SEO panel uses the
 * registry's resolved SEO group so built-ins and custom collections stay consistent. */
export function resolveCollections(reg: CollectionsRegistry): ResolvedCollection[] {
  const seo = resolveSeoFields(reg);
  return [...builtinResolved(reg), ...(reg.collections ?? []).map((c) => customToResolved(c, seo))];
}

/** One resolved collection by id, or `undefined` if no collection has that id. */
export function resolveCollection(
  id: CollectionName,
  reg: CollectionsRegistry,
): ResolvedCollection | undefined {
  return resolveCollections(reg).find((c) => c.id === id);
}

/** Every collection id currently in use (built-in + custom) — the builder's
 * uniqueness guard. */
export function existingCollectionIds(reg: CollectionsRegistry): string[] {
  return resolveCollections(reg).map((c) => c.id);
}

// ─── Canonical serialization ─────────────────────────────────────────────────

function toJson(value: unknown): string {
  return `${JSON.stringify(value, null, 2)}\n`;
}

function normalizeField(f: FieldDef): FieldDef {
  const out: FieldDef = { name: f.name, label: f.label, type: f.type };
  if (f.optional) out.optional = true;
  // A list carries its scalar sub-schema; normalize each sub-field the same way
  // so the serialized registry stays canonical for the nested shape.
  if (f.type === 'list') out.fields = (f.fields ?? []).map(normalizeField);
  return out;
}

function normalizeCollection(c: CustomCollection): CustomCollection {
  return {
    id: c.id,
    label: c.label,
    singular: c.singular,
    fields: (c.fields ?? []).map(normalizeField),
  };
}

/** The built-in names in canonical serialization order. */
const BUILTIN_ORDER: BuiltinCollectionName[] = ['pages', 'blog', 'events', 'team'];

/** Canonical form of one SEO field: fixed key order, keeping the optional `hint`. */
function normalizeSeoField(f: FieldDef): FieldDef {
  const out: FieldDef = { name: f.name, label: f.label, type: f.type };
  if (f.optional) out.optional = true;
  if (f.hint) out.hint = f.hint;
  return out;
}

/** Canonical form of the per-built-in extras map: built-ins in fixed order,
 * empty lists dropped. */
function normalizeBuiltins(
  builtins: Partial<Record<BuiltinCollectionName, FieldDef[]>>,
): Partial<Record<BuiltinCollectionName, FieldDef[]>> {
  const out: Partial<Record<BuiltinCollectionName, FieldDef[]>> = {};
  for (const name of BUILTIN_ORDER) {
    const fields = builtins[name];
    if (fields && fields.length > 0) out[name] = fields.map(normalizeField);
  }
  return out;
}

/** Serialize the registry to the canonical JSON the commit writes — fixed key
 * order + 2-space indent + trailing newline, so a no-op edit never stages. The
 * optional `builtins`/`seo` sections are emitted only when non-empty, so a
 * registry that uses neither serializes exactly as it did before the feature. */
export function serializeRegistry(reg: CollectionsRegistry): string {
  const out: CollectionsRegistry = { collections: (reg.collections ?? []).map(normalizeCollection) };
  if (reg.builtins) {
    const builtins = normalizeBuiltins(reg.builtins);
    if (Object.keys(builtins).length > 0) out.builtins = builtins;
  }
  if (reg.seo && reg.seo.length > 0) out.seo = reg.seo.map(normalizeSeoField);
  return toJson(out);
}

// ─── Builder working state + field-row helpers ───────────────────────────────

/** A field row while it's being designed (ids/labels still mid-edit). */
export interface DraftField {
  label: string;
  /** Editable frontmatter key; auto-derivable from the label. */
  id: string;
  type: CustomFieldType;
  optional: boolean;
  /** The row sub-fields when `type === 'list'` — scalar rows, one level deep. */
  fields?: DraftField[];
}

/** The whole collection while it's being designed in the builder. */
export interface CollectionDraft {
  label: string;
  id: string;
  singular: string;
  fields: DraftField[];
}

/** A fresh blank field row (short text, required). */
export function emptyDraftField(): DraftField {
  return { label: '', id: '', type: 'text', optional: false };
}

/** A fresh blank collection with one starter field row. */
export function emptyDraft(): CollectionDraft {
  return { label: '', id: '', singular: '', fields: [emptyDraftField()] };
}

export function addDraftField(fields: DraftField[]): DraftField[] {
  return [...fields, emptyDraftField()];
}

export function updateDraftField(
  fields: DraftField[],
  index: number,
  patch: Partial<DraftField>,
): DraftField[] {
  return fields.map((f, i) => (i === index ? { ...f, ...patch } : f));
}

export function removeDraftField(fields: DraftField[], index: number): DraftField[] {
  return fields.filter((_, i) => i !== index);
}

/** Move a field row up (−1) or down (+1); ends are no-ops (shared reorder util). */
export function moveDraftField(fields: DraftField[], index: number, delta: number): DraftField[] {
  return moveInArray(fields, index, delta);
}

/** Drag-reorder: pull the field row at `from` and drop it at `to`. */
export function reorderDraftField(fields: DraftField[], from: number, to: number): DraftField[] {
  return reorderInArray(fields, from, to);
}

// ─── Validation ──────────────────────────────────────────────────────────────

/** The strict id a field row would serialize under (its typed id, or derived
 * from the label). */
export function fieldFinalId(field: DraftField): string {
  return slugify(field.id.trim() || field.label);
}

/** The strict id a collection draft would serialize under. */
export function collectionFinalId(draft: CollectionDraft): string {
  return slugify(draft.id.trim() || draft.label);
}

export interface BuilderStatus {
  /** The slug the collection will be created under. */
  finalId: string;
  labelError?: string;
  idError?: string;
  /** Per-field error message, or null when the row is valid. Same order as fields. */
  fieldErrors: (string | null)[];
  /** Per-list-field, per-sub-field error messages (null when valid), keyed by the
   * top-level field index. Only list fields appear; each array is parallel to that
   * field's `fields`. Empty when no list field has a sub-field problem. */
  subFieldErrors: Record<number, (string | null)[]>;
  /** True only when the whole draft is valid and can be created. */
  canCreate: boolean;
  /** The footer status line describing the current state. */
  message: string;
}

/**
 * Validate a `list` field's sub-fields: each needs a label and a unique,
 * non-reserved id, and nested lists are rejected. Returns one message per
 * sub-field (null when valid) — shared by {@link builderStatus} for gating and by
 * the builder row UI for inline display, so both agree on the rules.
 */
export function subFieldErrors(fields: DraftField[]): (string | null)[] {
  const seen = new Set<string>();
  return fields.map((field) => {
    if (field.type === 'list') return 'A list field can’t contain another list.';
    if (field.label.trim() === '') return 'Give this field a label.';
    const id = fieldFinalId(field);
    if (id === '') return 'This field needs an id.';
    if (RESERVED_FIELD_IDS.has(id)) return `"${id}" is a reserved field name.`;
    if (seen.has(id)) return `Duplicate field id "${id}".`;
    seen.add(id);
    return null;
  });
}

/**
 * Derive the builder's gating + status from the current draft. A collection needs
 * a label, a valid id that doesn't collide with a built-in or an existing custom
 * collection, and at least one valid field (each with a label and a unique,
 * non-reserved id). Message priority: id collision, missing label, then the first
 * field problem, then ready.
 */
export function builderStatus(draft: CollectionDraft, existingIds: string[]): BuilderStatus {
  const finalId = collectionFinalId(draft);
  const missingLabel = draft.label.trim() === '';

  let idError: string | undefined;
  if (finalId === '') {
    idError = 'Enter an id for the collection.';
  } else if (RESERVED_COLLECTION_IDS.has(finalId) || existingIds.includes(finalId)) {
    idError = `The id "${finalId}" is already taken — pick a different one.`;
  }

  // Per-field validation, with within-collection id-uniqueness. A list field also
  // needs at least one valid sub-field (validated by `subFieldErrors`); its
  // top-level message summarizes the first sub-field problem.
  const seen = new Map<string, number>();
  const subErrors: Record<number, (string | null)[]> = {};
  const fieldErrors: (string | null)[] = draft.fields.map((field, i) => {
    if (field.label.trim() === '') return 'Give this field a label.';
    const id = fieldFinalId(field);
    if (id === '') return 'This field needs an id.';
    if (RESERVED_FIELD_IDS.has(id)) return `"${id}" is a reserved field name.`;
    const firstAt = seen.get(id);
    if (firstAt !== undefined) return `Duplicate field id "${id}".`;
    seen.set(id, 1);
    if (field.type === 'list') {
      const subs = field.fields ?? [];
      if (subs.length === 0) return 'Add at least one field to this list.';
      const errs = subFieldErrors(subs);
      subErrors[i] = errs;
      const firstSub = errs.find((e) => e !== null);
      if (firstSub) return `List field “${field.label.trim()}”: ${firstSub}`;
    }
    return null;
  });

  const hasField = draft.fields.length > 0;
  const anyFieldError = fieldErrors.some((e) => e !== null);
  const canCreate = !missingLabel && !idError && hasField && !anyFieldError;

  const firstFieldError = fieldErrors.find((e) => e !== null) ?? undefined;
  const message = idError
    ? idError
    : missingLabel
      ? 'Name the collection to get started.'
      : !hasField
        ? 'Add at least one field.'
        : firstFieldError
          ? firstFieldError
          : `Ready to create "${draft.label.trim()}".`;

  return {
    finalId,
    labelError: missingLabel ? 'Name the collection.' : undefined,
    idError,
    fieldErrors,
    subFieldErrors: subErrors,
    canCreate,
    message,
  };
}

// ─── Draft → registry ────────────────────────────────────────────────────────

/** A rough singular guess from a plural label ("Sponsors" → "sponsor"); the
 * editor can override it. */
function singularFromLabel(label: string): string {
  const trimmed = label.trim();
  const lower = trimmed.toLowerCase();
  return lower.endsWith('s') && lower.length > 1 ? lower.slice(0, -1) : lower;
}

function draftFieldToDef(field: DraftField): FieldDef {
  const def: FieldDef = { name: fieldFinalId(field), label: field.label.trim(), type: field.type };
  if (field.optional) def.optional = true;
  if (field.type === 'list') def.fields = (field.fields ?? []).map(draftFieldToDef);
  return def;
}

/** Turn a validated draft into the normalized `CustomCollection` stored in the
 * registry. Assumes `builderStatus(...).canCreate` — callers gate on it. */
export function draftToCollection(draft: CollectionDraft): CustomCollection {
  return {
    id: collectionFinalId(draft),
    label: draft.label.trim(),
    singular: draft.singular.trim() || singularFromLabel(draft.label),
    fields: draft.fields.map(draftFieldToDef),
  };
}

/** Append a collection to the registry (immutably). */
export function addCollection(
  reg: CollectionsRegistry,
  collection: CustomCollection,
): CollectionsRegistry {
  return { collections: [...(reg.collections ?? []), collection] };
}

// ─── Staging ─────────────────────────────────────────────────────────────────

/**
 * Build the `PendingChange` for a registry edit. Both baselines run through the
 * same canonical serializer, so a change that returns the registry to its
 * original value stages as a no-op and `upsertChange` drops it.
 */
export function buildCollectionsChange(
  original: CollectionsRegistry,
  current: CollectionsRegistry,
): PendingChange {
  return {
    collection: 'collections',
    slug: 'collections',
    path: COLLECTIONS_PATH,
    title: 'Custom collections',
    original: serializeRegistry(original),
    updated: serializeRegistry(current),
    kind: 'edit',
  };
}
