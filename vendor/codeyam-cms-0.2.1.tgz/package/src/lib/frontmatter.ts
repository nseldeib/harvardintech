// Parse and re-serialize a content entry's YAML frontmatter + markdown body.
//
// CodeYam CMS edits the same `src/content/*` markdown files the static site builds
// from, so the editor needs to read an entry into editable field values and write
// the edited values back as byte-for-byte-valid frontmatter. Astro's
// `getCollection` gives *coerced* data (e.g. `date` becomes a JS Date), which is
// lossy for round-tripping — so the editor reads the RAW file through this parser
// instead. Kept framework-free (no `astro:content`, no DOM) so it unit-tests
// under vitest and runs both at build time (in `getStaticPaths`) and in the
// browser island on save.
//
// Scope: a small, well-specified YAML subset covering exactly what content
// collections use:
//   • scalars — string / number / boolean / date-string (e.g. `title: Hello`)
//   • block sequences of scalars — a bare `key:` then `  - value` lines
//   • block sequences of flat maps — `  - key: value` with `    key: value`
//     continuation lines (arrays of objects, e.g. `leads: [{ name, role }]`)
// An empty sequence is written inline as `key: []`. Explicitly out of scope:
// anchors, multi-doc, non-empty flow-style arrays, and deep (>2-level) nesting.
// This is a deliberately small frontmatter dialect, not a general YAML engine.
// `parse ∘ serialize` is a stable identity for every shape it supports (2-space
// indent, `- ` item markers), so a no-op CMS save never produces a spurious diff.

/** A leaf frontmatter value. Dates live as their `YYYY-MM-DD` string form. */
export type FrontmatterScalar = string | number | boolean;

/**
 * A frontmatter value: a scalar, a sequence of scalars, or a sequence of flat
 * maps (an array of objects). Recursive but shallow — maps hold only scalars,
 * matching the supported dialect.
 */
export type FrontmatterValue =
  | FrontmatterScalar
  | FrontmatterScalar[]
  | Record<string, FrontmatterScalar>[];

export interface ParsedEntry {
  /** Frontmatter keys in the order they appeared in the source. */
  data: Record<string, FrontmatterValue>;
  /** Everything after the closing `---`, verbatim (no leading blank line). */
  body: string;
}

const FENCE = '---';

/**
 * Split raw file text into `{ data, body }`. A file with no frontmatter fence
 * yields empty `data` and the whole text as `body`, so an unfenced note still
 * round-trips.
 */
export function parseEntry(raw: string): ParsedEntry {
  const normalized = raw.replace(/\r\n/g, '\n');
  // A valid frontmatter block is a leading `---` line, some keys, then a `---`
  // line. Anything else is treated as a bodyonly file.
  if (!normalized.startsWith(FENCE + '\n') && normalized !== FENCE) {
    return { data: {}, body: normalized };
  }
  const closeIdx = normalized.indexOf('\n' + FENCE, FENCE.length);
  if (closeIdx === -1) {
    return { data: {}, body: normalized };
  }
  const yaml = normalized.slice(FENCE.length + 1, closeIdx);
  // Body starts after the closing fence line. Drop the newline that terminates
  // the fence line, then one conventional blank line if present, so the stored
  // body excludes the frontmatter/body separator that `serializeEntry` re-adds.
  // This keeps parse∘serialize a stable identity — without it, every save would
  // accrete an extra blank line on files that already have the standard one.
  let body = normalized.slice(closeIdx + 1 + FENCE.length);
  if (body.startsWith('\n')) body = body.slice(1);
  if (body.startsWith('\n')) body = body.slice(1);

  const data: Record<string, FrontmatterValue> = {};
  const lines = yaml.split('\n');
  // Indentation-aware pass: top-level (indent 0) `key: value` lines are scalars;
  // a bare `key:` followed by more-indented `- ` lines is a sequence whose block
  // is consumed here rather than re-read by the outer loop.
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '') {
      i++;
      continue;
    }
    const indent = indentOf(line);
    const sep = line.indexOf(':');
    if (sep === -1) {
      i++;
      continue;
    }
    const key = line.slice(0, sep).trim();
    if (!key) {
      i++;
      continue;
    }
    const rest = line.slice(sep + 1).trim();
    if (rest === '[]') {
      data[key] = [];
      i++;
      continue;
    }
    if (rest !== '') {
      data[key] = parseScalar(rest);
      i++;
      continue;
    }
    // Empty `rest`: gather the indented block that follows (skipping blanks) and
    // interpret it as a sequence. A bare `key:` with no block stays an empty
    // string, matching the pre-sequence behaviour.
    i++;
    const block: string[] = [];
    while (i < lines.length) {
      const l = lines[i];
      if (l.trim() === '') {
        i++;
        continue;
      }
      if (indentOf(l) <= indent) break;
      block.push(l);
      i++;
    }
    data[key] = block.length === 0 ? '' : parseSequence(block);
  }
  return { data, body };
}

/** Count the leading spaces of a line (its indentation depth). */
function indentOf(line: string): number {
  let n = 0;
  while (n < line.length && line[n] === ' ') n++;
  return n;
}

/**
 * Interpret an indented block of `- ` lines as either a sequence of scalars or a
 * sequence of flat maps. The first item decides which: a `- key: value` head is
 * a map (with `    key: value` continuation lines at deeper indent as its
 * siblings); anything else is a scalar item.
 */
function parseSequence(
  block: string[],
): FrontmatterScalar[] | Record<string, FrontmatterScalar>[] {
  const itemIndent = indentOf(block[0]);
  // Group each `- ` item line with the continuation lines beneath it.
  const groups: string[][] = [];
  for (const line of block) {
    const content = line.slice(indentOf(line));
    if (indentOf(line) === itemIndent && (content === '-' || content.startsWith('- '))) {
      groups.push([line]);
    } else if (groups.length > 0) {
      groups[groups.length - 1].push(line);
    }
  }

  const firstHead = groups.length > 0 ? afterDash(groups[0][0]) : '';
  const isMap = looksLikeKeyValue(firstHead);
  if (!isMap) {
    return groups.map((group) => parseScalar(afterDash(group[0])));
  }
  return groups.map((group) => {
    const map: Record<string, FrontmatterScalar> = {};
    assignKeyValue(map, afterDash(group[0]));
    for (let k = 1; k < group.length; k++) assignKeyValue(map, group[k].trim());
    return map;
  });
}

/** Strip the leading `- ` (or bare `-`) item marker from a sequence line. */
function afterDash(line: string): string {
  return line.slice(indentOf(line)).replace(/^-\s*/, '');
}

/** A `key: value` (or bare `key:`) token — the shape of a map entry line. */
function looksLikeKeyValue(text: string): boolean {
  return /^[\w-]+:(\s|$)/.test(text);
}

/** Split a `key: value` token and store the parsed scalar on `map`. */
function assignKeyValue(map: Record<string, FrontmatterScalar>, text: string): void {
  const sep = text.indexOf(':');
  if (sep === -1) return;
  const key = text.slice(0, sep).trim();
  if (!key) return;
  map[key] = parseScalar(text.slice(sep + 1).trim());
}

/** Interpret a bare frontmatter scalar into a boolean, number, or string. */
function parseScalar(token: string): FrontmatterScalar {
  if (token === '') return '';
  if (token === 'true') return true;
  if (token === 'false') return false;
  // Quoted string — strip the matching quotes and unescape.
  if (
    (token.startsWith('"') && token.endsWith('"') && token.length >= 2) ||
    (token.startsWith("'") && token.endsWith("'") && token.length >= 2)
  ) {
    const inner = token.slice(1, -1);
    return token[0] === '"' ? inner.replace(/\\"/g, '"').replace(/\\\\/g, '\\') : inner;
  }
  // A plain integer or decimal (no leading zeros like a date part).
  if (/^-?(0|[1-9]\d*)(\.\d+)?$/.test(token)) return Number(token);
  return token;
}

/**
 * Render `{ data, body }` back to file text. `keyOrder` fixes the frontmatter
 * key sequence (the editor passes its field order so output is stable and
 * reviewable); any keys in `data` not named in `keyOrder` are appended in
 * insertion order. Keys whose value is `undefined` are omitted — that is how the
 * editor drops an optional field the user cleared.
 */
export function serializeEntry(
  entry: { data: Record<string, FrontmatterValue | undefined>; body: string },
  keyOrder: string[] = [],
): string {
  const seen = new Set<string>();
  const orderedKeys: string[] = [];
  for (const k of keyOrder) {
    if (k in entry.data && !seen.has(k)) {
      orderedKeys.push(k);
      seen.add(k);
    }
  }
  for (const k of Object.keys(entry.data)) {
    if (!seen.has(k)) {
      orderedKeys.push(k);
      seen.add(k);
    }
  }

  const lines: string[] = [];
  for (const k of orderedKeys) {
    const value = entry.data[k];
    if (value === undefined) continue;
    if (Array.isArray(value)) {
      lines.push(...serializeSequence(k, value));
    } else {
      lines.push(`${k}: ${serializeScalar(value)}`);
    }
  }

  const bodyText = entry.body ?? '';
  return `${FENCE}\n${lines.join('\n')}\n${FENCE}\n\n${bodyText}`;
}

/**
 * Render an array value: an empty array as inline `key: []`, otherwise a block
 * sequence — scalars as `  - value`, maps as a `  - key: value` head plus
 * `    key: value` continuation lines. Every leaf goes through `serializeScalar`
 * so quoting stays consistent with top-level scalars.
 */
function serializeSequence(
  key: string,
  value: FrontmatterScalar[] | Record<string, FrontmatterScalar>[],
): string[] {
  if (value.length === 0) return [`${key}: []`];
  const lines = [`${key}:`];
  for (const item of value) {
    if (item !== null && typeof item === 'object') {
      const entries = Object.entries(item);
      if (entries.length === 0) {
        lines.push('  - {}');
        continue;
      }
      entries.forEach(([k, v], idx) => {
        lines.push(`${idx === 0 ? '  - ' : '    '}${k}: ${serializeScalar(v)}`);
      });
    } else {
      lines.push(`  - ${serializeScalar(item)}`);
    }
  }
  return lines;
}

/** Render a scalar, quoting only strings that would otherwise be mis-parsed. */
function serializeScalar(value: FrontmatterScalar): string {
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') return String(value);
  return needsQuoting(value) ? `"${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"` : value;
}

/**
 * A bare string needs quotes when it would reparse as a different type or break
 * the `key: value` line: empty, wrapping whitespace, a leading indicator char,
 * an embedded `: ` or `#`, or a token that looks like a boolean/number.
 */
function needsQuoting(value: string): boolean {
  if (value === '') return true;
  if (value !== value.trim()) return true;
  if (/^[-?:,\[\]{}#&*!|>'"%@`]/.test(value)) return true;
  if (value.includes(': ') || value.includes(' #') || value.endsWith(':')) return true;
  if (value === 'true' || value === 'false') return true;
  if (/^-?(0|[1-9]\d*)(\.\d+)?$/.test(value)) return true;
  return false;
}
