// Detect that the branch moved underneath a staged change.
//
// Every `PendingChange` captures the file's content as `original` at the moment
// it was staged. Until now that baseline was used only for client-side
// dirty/no-op detection — it was never compared against what is actually on the
// branch. So two editors working at once silently overwrote each other: an
// edited file is written WHOLE by `commitAll`, so whatever the other editor
// wrote to it vanished with no warning and no conflict.
//
// The window is not narrow. On a static site the editor's baseline comes from
// the last *build*, so any browser tab opened before a co-editor's change
// already holds a stale baseline — as does any tab left open across a deploy.
// This is a CMS with an invite flow and an editors roster; concurrent editing is
// the intended use, not an edge case.
//
// This module is the framework-free, `fetch`-free heart of the pre-commit
// freshness check: given the staged changes plus a map of what each path looks
// like on the branch RIGHT NOW, it returns the subset that drifted and why.
// Keeping the comparison pure means it unit-tests directly with no network —
// the same boundary `mediaLibrary` / `siteConfig` draw against their `fs` /
// `fetch` counterparts. The network half lives in `githubCommit.ts`.

import { isDeletion, removeChange, upsertChange, type PendingChange } from './pendingChanges';

/**
 * Why a staged change is no longer safe to commit.
 *
 * - `modified` — a write whose non-empty baseline no longer matches the branch
 * - `created-elsewhere` — a creation (empty baseline) whose path now exists
 * - `already-gone` — a delete whose path is already absent
 * - `deleted-elsewhere` — a write whose path has been removed on the branch
 */
export type DriftKind = 'modified' | 'created-elsewhere' | 'already-gone' | 'deleted-elsewhere';

/** A staged change whose baseline no longer reflects the branch. */
export interface DriftedChange {
  /** Repo-relative path — the stable identity of the change. */
  path: string;
  /** The change's display title, for naming the entry in the warning. */
  title: string;
  /** What went stale. */
  kind: DriftKind;
  /** The baseline the change captured when it was staged. */
  original: string;
  /** What is on the branch now. `null` means the path is absent there. */
  remote: string | null;
}

/**
 * What the branch currently holds for each staged path. `null` marks a path that
 * is absent on the branch — a meaningful answer here, not a failure.
 */
export type RemoteContents = Map<string, string | null>;

/**
 * A creation stages an empty baseline, because the file does not exist yet
 * (`buildNewEntryChange`). Matching `changeVerb`'s `new` rule keeps the two
 * definitions of "this change creates the file" from drifting apart.
 */
function isCreation(change: PendingChange): boolean {
  return change.original.trim() === '';
}

/**
 * Classify ONE staged change against what the branch holds for its path now,
 * returning the drift kind or `null` when the change is still safe to commit.
 *
 * The four rules are the substance of this check, so they live in one small
 * total function that takes a single change and a single remote value: each
 * rule is then stated once and testable on its own, rather than only reachable
 * through a list-shaped setup.
 *
 * `current` is `null` when the path is absent on the branch.
 */
export function classifyDrift(change: PendingChange, current: string | null): DriftKind | null {
  if (isDeletion(change)) {
    // Deleting content you have not seen is the same hazard as overwriting it.
    if (current === null) return 'already-gone';
    return current === change.original ? null : 'modified';
  }

  if (isCreation(change)) {
    // The equivalent staleness for a creation is "someone already created this
    // path" — without this, two editors creating the same slug still clobber.
    return current === null ? null : 'created-elsewhere';
  }

  if (current === null) return 'deleted-elsewhere';
  return current === change.original ? null : 'modified';
}

/**
 * Compare each staged change's captured baseline against what the branch holds
 * now, and return the subset that drifted.
 *
 * A path missing from `remote` is treated as "not checked" and skipped rather
 * than assumed absent — only an explicit `null` means "absent on the branch".
 * That distinction matters: guessing absence from a missing key would report
 * every unfetched path as `deleted-elsewhere`.
 */
export function detectDrift(changes: PendingChange[], remote: RemoteContents): DriftedChange[] {
  const drifted: DriftedChange[] = [];

  for (const change of changes) {
    if (!remote.has(change.path)) continue;
    const current = remote.get(change.path) ?? null;
    const kind = classifyDrift(change, current);
    if (kind === null) continue;
    drifted.push({ path: change.path, title: change.title, original: change.original, kind, remote: current });
  }

  return drifted;
}

/**
 * Plain-language explanation of one drifted entry.
 *
 * This copy appears at the moment someone is about to lose work, so it names the
 * entry and says what happened — "conflict" alone tells an editor nothing.
 */
export function describeDrift(drift: DriftedChange): string {
  const name = drift.title.trim() === '' ? drift.path : drift.title;
  switch (drift.kind) {
    case 'created-elsewhere':
      return `Someone else has already created “${name}”. Publishing would replace their version with yours.`;
    case 'already-gone':
      return `“${name}” has already been deleted by someone else, so there is nothing left to remove.`;
    case 'deleted-elsewhere':
      return `Someone else deleted “${name}” while you were editing it. Publishing would bring it back with your version.`;
    default:
      return `Someone else changed “${name}” since you started editing it. Publishing would overwrite their version with yours.`;
  }
}

/**
 * The "reload current" resolution: adopt what the branch holds now as the
 * change's baseline, keeping the editor's own edit as the staged content. The
 * review diff then shows the co-editor's version against the editor's, so they
 * can SEE what landed and re-apply their change against it — the alternative to
 * discarding, and the reason this is not just a second discard button.
 *
 * Three cases fall out of the existing set semantics rather than needing special
 * handling: a delete whose file is already gone has nothing left to do and is
 * unstaged; a write whose file was deleted on the branch rebases onto an empty
 * baseline, becoming a creation; and an edit that turns out to match the branch
 * exactly is unstaged by `upsertChange`'s no-op rule.
 */
export function reloadBaseline(changes: PendingChange[], drift: DriftedChange): PendingChange[] {
  const change = changes.find((c) => c.path === drift.path);
  if (!change) return changes;
  if (drift.remote === null && isDeletion(change)) return removeChange(changes, drift.path);
  return upsertChange(changes, { ...change, original: drift.remote ?? '' });
}

/** Headline for the drift warning — names the scale of the problem. */
export function summarizeDrift(drifted: DriftedChange[]): string {
  if (drifted.length === 0) return '';
  if (drifted.length === 1) return '1 of your changes is out of date';
  return `${drifted.length} of your changes are out of date`;
}
