// Build-time reader for raw entry markdown.
//
// The editor routes need each entry's RAW file text (to round-trip frontmatter
// losslessly — see `frontmatter.ts`), not Astro's coerced `getCollection` data.
// This reads straight off the resolved content root, which is the committed
// `src/content` in production and the `.codeyam/tmp` sandbox during a codeyam
// session — so the editor lists and edits exactly the seeded scenario content.
// Node-only (runs in `getStaticPaths` at build time), never shipped to the
// browser.
import * as fs from 'fs';
import * as path from 'path';
import { resolveContentRoot } from './contentRoot';
import type { CollectionName } from './adminDashboard';

export interface EntrySource {
  slug: string;
  raw: string;
}

/** All entries in a collection, slug-sorted. Missing folder → empty list. */
export function listEntrySources(collection: CollectionName): EntrySource[] {
  const dir = path.join(resolveContentRoot(), collection);
  let names: string[];
  try {
    names = fs.readdirSync(dir);
  } catch {
    return [];
  }
  return names
    .filter((n) => /\.(md|mdx)$/.test(n))
    .map((n) => ({
      slug: n.replace(/\.(md|mdx)$/, ''),
      raw: fs.readFileSync(path.join(dir, n), 'utf-8'),
    }))
    .sort((a, b) => a.slug.localeCompare(b.slug));
}

/** One entry's raw text, or `null` if it does not exist. */
export function readEntrySource(collection: CollectionName, slug: string): string | null {
  return listEntrySources(collection).find((e) => e.slug === slug)?.raw ?? null;
}
