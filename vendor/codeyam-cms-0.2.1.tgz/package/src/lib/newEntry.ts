// Pure, framework-free logic for the create-an-entry flow.
//
// The `NewEntryEditor` island is a thin shell over these helpers: they decide the
// blank starting form, which field names the entry, whether "Create" is allowed
// (a title/name and a slug are present and the slug doesn't collide with an
// existing file), and how to turn the filled form into a `PendingChange` the
// existing staging/commit pipeline understands. Keeping it here — beside
// `entryEditor.ts` and `pendingChanges.ts` — means it unit-tests with no DOM and
// runs unchanged in the browser island.

import type { CollectionName } from './adminDashboard';
import {
  fieldOrder,
  formValuesToData,
  entryContentPath,
  entryLabel,
  labelFieldName,
  validateRequiredFields,
  type FieldDef,
  type RawFieldValue,
  type RequiredFieldStatus,
} from './entryEditor';
import { serializeEntry } from './frontmatter';
import { slugify } from './slug';
import type { PendingChange } from './pendingChanges';

/** The blank starting value for each field: '' for inputs, false for the draft toggle. */
export function emptyFieldValues(fields: FieldDef[]): Record<string, RawFieldValue> {
  const out: Record<string, RawFieldValue> = {};
  for (const field of fields) {
    out[field.name] = field.type === 'list' ? [] : field.type === 'boolean' ? false : '';
  }
  return out;
}

/**
 * Whether the editor has put ANYTHING into the create form yet — any field, the
 * slug, or the body.
 *
 * An untouched create form is blank by definition, so flagging every required
 * field before a character has been typed is scolding rather than helping. The
 * footer still explains the gate from the start; the inline errors wait for this
 * to turn true. A ticked toggle counts as input; an unticked one does not.
 */
export function hasAnyInput(
  values: Record<string, RawFieldValue>,
  slug: string,
  body: string,
): boolean {
  if (slug.trim() !== '' || body.trim() !== '') return true;
  return Object.values(values).some((v) => {
    if (Array.isArray(v)) return v.length > 0;
    // Booleans must be tested as booleans: `String(false)` is the non-empty
    // "false", so falling through to the string test would make every form with
    // an unticked toggle — i.e. every blank form, since `draft` starts false —
    // look like it had input.
    if (typeof v === 'boolean') return v;
    return String(v ?? '').trim() !== '';
  });
}

export interface NewEntryStatusInput {
  collection: CollectionName;
  /** The collection's resolved editable fields — drives the label/create gate. */
  fields: FieldDef[];
  values: Record<string, RawFieldValue>;
  /** The raw slug field value (possibly mid-typing, e.g. "spring-"). */
  slug: string;
  /** Slugs already present in the collection — the collision guard. */
  existingSlugs: string[];
  /** Whether this entry is already in the staging set. */
  staged: boolean;
}

export interface NewEntryStatus {
  /** The strict slug used for the file path and collision check. */
  finalSlug: string;
  /** Repo-relative content path, or '' when there is no slug yet. */
  path: string;
  collision: boolean;
  missingLabel: boolean;
  missingSlug: boolean;
  /** Every required field still blank, with the per-field messages the form
   * renders inline. A new entry has no committed baseline, so every blank here
   * is the editor's own and all of them block. */
  required: RequiredFieldStatus;
  /** True only when the entry can be created: labelled, slugged, unique, every
   * required field filled, and not already staged. */
  canCreate: boolean;
  /** The footer status line describing the current state. */
  message: string;
}

/**
 * Derive the create form's gating + status from its current values. The strict
 * `finalSlug` (title/hand-typed slug run through `slugify`) drives the path and
 * the collision check even while the editable field still holds an in-progress
 * value. Message priority: staged, then collision, then a missing title, then a
 * missing slug, then ready.
 */
export function newEntryStatus({
  collection,
  fields,
  values,
  slug,
  existingSlugs,
  staged,
}: NewEntryStatusInput): NewEntryStatus {
  const labelValue = String(values[labelFieldName(fields)] ?? '');
  const finalSlug = slugify(slug);
  const path = finalSlug ? entryContentPath(collection, finalSlug) : '';

  const missingLabel = labelValue.trim() === '';
  const missingSlug = finalSlug === '';
  const collision = finalSlug !== '' && existingSlugs.includes(finalSlug);
  // Slug collision stays a slug-level concern; the field-level gate covers every
  // required field, the label included.
  const required = validateRequiredFields({ fields, values });
  const canCreate = !missingLabel && !missingSlug && !collision && !required.blocked && !staged;

  const message = staged
    ? 'New entry staged for the next commit.'
    : collision
      ? `An entry named "${finalSlug}" already exists here — pick a different slug.`
      : missingLabel
        ? 'Enter a title to name this entry.'
        : missingSlug
          ? 'Enter a slug for the file name.'
          : required.blocked
            ? required.message
            : 'Ready to create.';

  return { finalSlug, path, collision, missingLabel, missingSlug, required, canCreate, message };
}

export interface NewEntryChangeInput {
  collection: CollectionName;
  /** The collection's resolved editable fields — drives typing + serialization order. */
  fields: FieldDef[];
  values: Record<string, RawFieldValue>;
  body: string;
  /** The strict slug (already collision-checked) the new file is created under. */
  slug: string;
}

/**
 * Build the `PendingChange` for a newly-created entry. Its baseline is the empty
 * string — the file does not exist yet — so the review renders it as an
 * all-additions creation and `commitAll` writes a brand-new blob.
 */
export function buildNewEntryChange({ collection, fields, values, body, slug }: NewEntryChangeInput): PendingChange {
  const data = formValuesToData(fields, values);
  return {
    collection,
    slug,
    path: entryContentPath(collection, slug),
    title: entryLabel(data, slug, labelFieldName(fields)),
    original: '',
    updated: serializeEntry({ data, body }, fieldOrder(fields)),
  };
}
