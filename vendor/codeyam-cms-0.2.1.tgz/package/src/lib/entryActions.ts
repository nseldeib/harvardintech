// Pure builders for the row-level entry actions: archive, unarchive, delete.
//
// The entry list lets an editor archive (hide from the published site by
// setting `draft: true`), unarchive (clear the flag), or delete an entry — each
// staged as a PendingChange that flows through the same review-and-commit drawer
// as an editor edit. This module turns an entry's RAW markdown into the right
// PendingChange, mirroring how `EntryEditor` builds its baseline: the `original`
// is the file NORMALIZED through parse∘serialize, so an archive change diffs as
// exactly the one `draft:` line and re-serialization never reads as noise.
// Framework-free (no DOM, no fs) so it unit-tests and runs in the row island.

import { parseEntry, serializeEntry, type FrontmatterValue } from './frontmatter';
import { COLLECTION_FIELDS, entryLabel, entryContentPath, type FieldDef } from './entryEditor';
import type { CollectionName } from './adminDashboard';
import type { PendingChange } from './pendingChanges';

/**
 * The stable frontmatter key order to serialize a collection's entries under. For
 * a built-in collection it's the `COLLECTION_FIELDS` order (so scrambled keys come
 * back canonical, `draft` last); for a custom collection — whose field list isn't
 * available in this browser-side island — it falls back to the entry's own key
 * order. Ordering only has to be stable BETWEEN an action's `original`/`updated`
 * for the diff to stay one line, so the fallback is safe.
 */
function keyOrderFor(
  collection: CollectionName,
  data: Record<string, FrontmatterValue | undefined>,
): string[] {
  const builtin = (COLLECTION_FIELDS as Record<string, FieldDef[]>)[collection];
  return builtin ? builtin.map((f) => f.name) : Object.keys(data);
}

/**
 * Re-serialize `data`/`body` in the collection's stable key order. A resolved
 * `keyOrder` (the collection's full field list, passed down from the page that
 * knows the registry) takes precedence; without it we fall back to the built-in
 * `COLLECTION_FIELDS` order so this browser island stays registry-free.
 */
function serialize(
  collection: CollectionName,
  data: Record<string, FrontmatterValue | undefined>,
  body: string,
  keyOrder?: string[],
): string {
  return serializeEntry({ data, body }, keyOrder ?? keyOrderFor(collection, data));
}

/** An entry's raw markdown normalized to the editor's stable baseline. */
export function normalizeEntry(collection: CollectionName, raw: string, keyOrder?: string[]): string {
  const { data, body } = parseEntry(raw);
  return serialize(collection, data, body, keyOrder);
}

/** The shared identity fields every action-change carries. */
function base(collection: CollectionName, slug: string, raw: string) {
  const { data } = parseEntry(raw);
  return {
    collection,
    slug,
    path: entryContentPath(collection, slug),
    title: entryLabel(data, slug),
  };
}

/**
 * Archive: set `draft: true` so the entry drops off the published site while
 * staying editable. The change is a normal WRITE — its diff is the single added
 * `draft: true` line.
 */
export function buildArchiveChange(
  collection: CollectionName,
  slug: string,
  raw: string,
  keyOrder?: string[],
): PendingChange {
  const { data, body } = parseEntry(raw);
  return {
    ...base(collection, slug, raw),
    original: serialize(collection, data, body, keyOrder),
    updated: serialize(collection, { ...data, draft: true }, body, keyOrder),
    kind: 'archive',
  };
}

/**
 * Unarchive: clear the `draft` flag (set `undefined` so `serializeEntry` omits
 * the key entirely, matching how published entries are stored) to republish an
 * archived entry.
 */
export function buildUnarchiveChange(
  collection: CollectionName,
  slug: string,
  raw: string,
  keyOrder?: string[],
): PendingChange {
  const { data, body } = parseEntry(raw);
  return {
    ...base(collection, slug, raw),
    original: serialize(collection, data, body, keyOrder),
    updated: serialize(collection, { ...data, draft: undefined }, body, keyOrder),
    kind: 'unarchive',
  };
}

/**
 * Delete: remove the entry's file. `updated` equals the normalized `original`
 * (nothing is rewritten); the commit layer emits a blob removal for a `delete`.
 */
export function buildDeleteChange(
  collection: CollectionName,
  slug: string,
  raw: string,
  keyOrder?: string[],
): PendingChange {
  const original = normalizeEntry(collection, raw, keyOrder);
  return {
    ...base(collection, slug, raw),
    original,
    updated: original,
    kind: 'delete',
  };
}
