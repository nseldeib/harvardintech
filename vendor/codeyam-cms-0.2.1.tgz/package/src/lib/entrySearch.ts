// Pure, framework-free content search for the admin.
//
// The CMS is a static site — there is no server to run a query against — so the
// admin search runs in the browser over a small index the build hands each
// island. Every searchable entry carries a lowercased `haystack` (its title +
// body text) computed at build time, and matching is a case-insensitive
// substring test on the trimmed query. This is deliberately kept out of any
// `.astro`/`.tsx` file so it unit-tests under vitest with no DOM, and so both
// the dashboard-wide search island and the per-collection filter island share
// exactly one matcher.

import { parseEntry } from './frontmatter';
import { entryLabel } from './entryEditor';

/** One entry as the search islands see it: identity, label, and a match index. */
export interface SearchableEntry {
  /** Collection id — the content folder and the editor deep-link segment. */
  collection: string;
  /** Human label for the collection ("Blog Posts"), for grouped results. */
  collectionLabel: string;
  /** Entry slug — the editor deep-link segment. */
  slug: string;
  /** The entry's display label (its title / name). */
  label: string;
  /** True when the entry currently carries `draft: true`. */
  draft: boolean;
  /** Lowercased title + body text, precomputed at build time for matching. */
  haystack: string;
}

/**
 * Build the lowercased match index from an entry's label and markdown body.
 * Joining with a newline keeps a label word from fusing with a body word
 * (so "About" + "Us page" never matches the phantom substring "aboutus page").
 */
export function buildHaystack(label: string, body: string): string {
  return `${label}\n${body}`.toLowerCase();
}

/** The raw inputs the build has for one entry, before it becomes searchable. */
export interface RawEntry {
  collection: string;
  collectionLabel: string;
  /** The field that labels an entry (from `labelFieldName`); defaults handled
   * by `entryLabel` when omitted. */
  labelField?: string;
  slug: string;
  raw: string;
}

/**
 * Turn one raw entry file into a `SearchableEntry`: parse its frontmatter/body,
 * resolve its display label, and precompute the title+body match haystack. Both
 * admin pages build their search index by mapping their entries through this, so
 * the "entry → searchable" shape lives in exactly one tested place.
 */
export function entryToSearchable(entry: RawEntry): SearchableEntry {
  const { data, body } = parseEntry(entry.raw);
  const label = entryLabel(data, entry.slug, entry.labelField);
  return {
    collection: entry.collection,
    collectionLabel: entry.collectionLabel,
    slug: entry.slug,
    label,
    draft: data.draft === true,
    haystack: buildHaystack(label, body),
  };
}

/** Normalize a raw query for matching: trimmed and lowercased. */
export function normalizeQuery(query: string): string {
  return query.trim().toLowerCase();
}

/**
 * Filter entries to those matching the query, preserving input order. A blank
 * (or whitespace-only) query returns every entry unchanged — the callers decide
 * whether an empty search box shows all entries or nothing. Matching is a
 * case-insensitive substring test on the entry's precomputed title+body
 * haystack, so a term appearing only in an entry's body still surfaces it.
 */
export function searchEntries<T extends SearchableEntry>(entries: T[], query: string): T[] {
  const q = normalizeQuery(query);
  if (q === '') return entries;
  return entries.filter((e) => e.haystack.includes(q));
}

/** A run of matched entries that all belong to one collection. */
export interface CollectionGroup<T> {
  collection: string;
  collectionLabel: string;
  entries: T[];
}

/**
 * Group entries by collection for the dashboard's grouped results, preserving
 * both the first-seen collection order and each collection's input order. The
 * caller passes entries already filtered by `searchEntries`, so an empty group
 * never appears.
 */
export function groupByCollection<T extends SearchableEntry>(entries: T[]): CollectionGroup<T>[] {
  const groups: CollectionGroup<T>[] = [];
  const index = new Map<string, CollectionGroup<T>>();
  for (const entry of entries) {
    let group = index.get(entry.collection);
    if (!group) {
      group = { collection: entry.collection, collectionLabel: entry.collectionLabel, entries: [] };
      index.set(entry.collection, group);
      groups.push(group);
    }
    group.entries.push(entry);
  }
  return groups;
}
