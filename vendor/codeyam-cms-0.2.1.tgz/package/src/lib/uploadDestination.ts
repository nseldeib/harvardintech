// The upload destination folder: validating one, and remembering the last one.
//
// Uploading a batch of gallery photos should mean choosing `gallery` once, not
// once per file and not again on the next visit — so the chosen folder is
// remembered per browser, the same way `authSession.ts` remembers the signed-in
// profile: a `codeyam-cms:`-namespaced localStorage key behind a `hasStorage()`
// guard, with every read and write in a try/catch so private-mode or disabled
// storage degrades quietly instead of breaking an upload.
//
// The destination is NOT part of the asset record. It is the directory half of
// an asset's `filename` identity (`gallery/event-05.jpg`), which `assetDirname`
// derives on demand — a stored `folder` property would be a second source of
// truth that could disagree with the path. So this module owns the destination
// only as a browser preference and as a thing to validate, never as data that
// commits.
//
// Kept free of React so the preference unit-tests on its own.
import { sanitizeAssetPath } from './mediaLibrary';

/** The images root — no folder, and the default until someone picks one. */
export const ROOT_DESTINATION = '';

const KEY = 'codeyam-cms:upload-destination';

/**
 * A stand-in file name used to validate a folder. A folder has to be cleaned by
 * the DIRECTORY rules, not the filename ones — `v1.2` is a directory whose dot
 * is punctuation (`v1-2`), while as a filename it would be a stem plus an
 * extension (`v1.2`). Appending a probe name runs the folder through
 * `sanitizeAssetPath` in exactly the position `buildUploadedAsset` will put it,
 * so what validates here is what will be built there.
 */
const PROBE_FILENAME = 'image.png';

function hasStorage(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

/**
 * The sanitized form of a destination folder — `My Photos` → `my-photos`, a
 * nested `a/b` kept nested, empty for the root.
 *
 * Throws (via `sanitizeAssetPath`) on anything that could escape the media
 * directory or sanitize away to nothing: a leading `/`, a `.`/`..` step, a
 * segment of pure punctuation. Callers that must not throw use
 * `destinationError` first.
 */
export function destinationFolder(rawFolder: string): string {
  const trimmed = rawFolder.trim();
  if (!trimmed) return ROOT_DESTINATION;
  const path = sanitizeAssetPath(`${trimmed}/${PROBE_FILENAME}`);
  return path.slice(0, path.lastIndexOf('/'));
}

/**
 * A message describing why `rawFolder` can't be a destination, or `null` if it
 * can. The root (empty) is always valid — a site that legitimately keeps its
 * images flat must stay easy to use.
 *
 * This is what keeps `sanitizeAssetPath`'s throwing contract out of the upload
 * path: the UI validates as the editor types and blocks the drop zone, so a
 * mistyped folder shows an inline message instead of surfacing a raw exception
 * mid-upload.
 */
export function destinationError(rawFolder: string): string | null {
  try {
    destinationFolder(rawFolder);
    return null;
  } catch {
    return 'Use a simple folder name — no leading “/”, and no “.” or “..” steps.';
  }
}

/**
 * The folder to pre-select for the next upload: the one last used in this
 * browser, or the root.
 *
 * Validated on the way out, so a preference can never pre-fill a destination
 * that would fail. A stored value that no longer sanitizes cleanly falls back
 * to the root, and so does one naming a folder that is no longer in `available`
 * (a folder can be renamed or emptied out from under a remembered preference).
 * Passing no `available` list skips only that second check.
 */
export function loadUploadDestination(available?: string[]): string {
  if (!hasStorage()) return ROOT_DESTINATION;

  let raw: string | null = null;
  try {
    raw = window.localStorage.getItem(KEY);
  } catch {
    return ROOT_DESTINATION;
  }
  if (!raw) return ROOT_DESTINATION;

  let folder: string;
  try {
    folder = destinationFolder(raw);
  } catch {
    return ROOT_DESTINATION;
  }
  if (!folder) return ROOT_DESTINATION;
  if (available && !available.includes(folder)) return ROOT_DESTINATION;
  return folder;
}

/**
 * Remember the folder an upload just went to. The root is stored as "no
 * preference" (the key is removed) rather than as an explicit empty value, so a
 * browser that has never chosen and one that chose the root read back the same.
 * An invalid folder is never remembered.
 */
export function saveUploadDestination(rawFolder: string): void {
  if (!hasStorage()) return;
  try {
    const folder = destinationFolder(rawFolder);
    if (folder) window.localStorage.setItem(KEY, folder);
    else window.localStorage.removeItem(KEY);
  } catch {
    /* invalid folder, or private-mode / disabled storage — nothing to remember */
  }
}
