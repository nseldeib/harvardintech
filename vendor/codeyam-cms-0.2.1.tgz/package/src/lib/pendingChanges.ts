// Pure logic for the staging set — the accumulate-then-commit model.
//
// An edit in the entry editor does NOT write the file; it stages a PendingChange.
// Changes pile up across entries and collections until the editor reviews them
// and commits them all at once (one GitHub commit). This module is the
// framework-free heart of that: a PendingChange shape plus the set operations
// (upsert, remove, no-op detection, diff summary) that both the browser store
// (`pendingChangesStore.ts`) and the review UI build on. No DOM, no localStorage
// here — that lives in the store wrapper — so this all unit-tests directly.

import type { CollectionName } from './adminDashboard';

/**
 * The site-wide singletons the CMS edits as single files rather than as a
 * collection of entries. They stage through the same pipeline as entries, so a
 * `PendingChange` must be able to name one as its "area". `media` is the image
 * library manifest (`src/data/media.json`); an image upload also stages a
 * *binary* change under this area for the image file itself. `cms` is the deploy
 * connection singleton (`src/data/cms.json`) edited by the "Connect your repo"
 * section of the settings page.
 */
export type SingletonName = 'settings' | 'nav' | 'media' | 'collections' | 'cms';

/**
 * How a change's content is encoded for the commit. Text edits (markdown, JSON
 * singletons) are `utf-8`; an uploaded image file is `base64` — its `updated`
 * holds base64 bytes, not diffable text. Absent → `utf-8`.
 */
export type ChangeEncoding = 'utf-8' | 'base64';

/** Every area a staged change can belong to: a content collection or a singleton. */
export type ChangeArea = CollectionName | SingletonName;

/**
 * What a staged change does to the entry. `edit` rewrites its content; `archive`
 * / `unarchive` are edits that flip the `draft` publish flag; `delete` removes
 * the file. Every kind except `delete` commits as a file WRITE — only `delete`
 * removes a blob (see `githubCommit`). Absent → `edit`, so changes staged before
 * this field existed still round-trip.
 */
export type ChangeKind = 'edit' | 'archive' | 'unarchive' | 'delete';

export interface PendingChange {
  /** The area the change lives in — a content collection or a site singleton. */
  collection: ChangeArea;
  /** Entry slug (filename without extension). */
  slug: string;
  /** Repo-relative content path — the stable identity of a change. */
  path: string;
  /** Human label for the review list (the entry's edited title/name). */
  title: string;
  /** The entry's original markdown, captured when first staged. */
  original: string;
  /** The edited content to be committed. For a `delete` this equals `original`
   * (the file is removed, not rewritten) and is never committed. For a `base64`
   * change this holds the image's base64-encoded bytes rather than text. */
  updated: string;
  /** What the change does. Absent is treated as `edit`. */
  kind?: ChangeKind;
  /** Content encoding for the commit. Absent → `utf-8` (text). `base64` marks a
   * binary file (an uploaded image) that has no line diff. */
  encoding?: ChangeEncoding;
}

/** Whether a change removes the file rather than writing it. */
export function isDeletion(change: Pick<PendingChange, 'kind'>): boolean {
  return change.kind === 'delete';
}

/** Whether a change carries binary (base64) content — an uploaded image file
 * rather than diffable text. Used by the review UI to render a thumbnail instead
 * of a line diff, and by the committer to pick the blob encoding. */
export function isBinary(change: Pick<PendingChange, 'encoding'>): boolean {
  return change.encoding === 'base64';
}

/**
 * Stage a change, keyed by `path`. Re-editing the same entry replaces its
 * pending change rather than adding a duplicate. If a WRITE edit brings the
 * entry back to its original text (`updated === original`), the entry is
 * UNSTAGED instead — a no-op edit should never sit in the review list. A
 * `delete` is exempt: its `updated` equals `original` by construction, yet the
 * removal is a real intent that must stay staged.
 */
export function upsertChange(changes: PendingChange[], change: PendingChange): PendingChange[] {
  const without = changes.filter((c) => c.path !== change.path);
  if (!isDeletion(change) && change.updated === change.original) return without;
  return [...without, change];
}

/** Remove a staged change by path. Absent path → list returned unchanged. */
export function removeChange(changes: PendingChange[], path: string): PendingChange[] {
  return changes.filter((c) => c.path !== path);
}

/** Whether a specific entry currently has a staged change. */
export function isStaged(changes: PendingChange[], path: string): boolean {
  return changes.some((c) => c.path === path);
}

export interface PendingSummary {
  count: number;
  /** Distinct areas touched, sorted, for a "Blog, Events" byline. */
  collections: ChangeArea[];
}

/** Roll the staging set up for the staging-bar label. */
export function summarizePending(changes: PendingChange[]): PendingSummary {
  const collections = [...new Set(changes.map((c) => c.collection))].sort();
  return { count: changes.length, collections };
}

/**
 * The user-facing verb for what a staged change does, for the review summary
 * ("2 edited, 1 new"). A write edit whose captured `original` is empty is a
 * freshly-created entry (`new`); a normal write is `edited`. The flag/removal
 * kinds map to their intent — `unarchive` reads as `published` to match the
 * "Publish" badge the review UI already uses.
 */
export type ChangeVerb = 'new' | 'edited' | 'published' | 'archived' | 'deleted';

export function changeVerb(change: Pick<PendingChange, 'kind' | 'original'>): ChangeVerb {
  switch (change.kind) {
    case 'delete':
      return 'deleted';
    case 'archive':
      return 'archived';
    case 'unarchive':
      return 'published';
    default:
      return change.original.trim() === '' ? 'new' : 'edited';
  }
}

/** Human labels for the site singletons, so a group header reads "Site Settings"
 * rather than the raw `settings` key. Collections fall back to a passed-in label
 * (the registry's) or a title-cased id. */
const SINGLETON_LABEL: Record<SingletonName, string> = {
  settings: 'Site Settings',
  nav: 'Navigation',
  media: 'Media Library',
  collections: 'Collections',
  cms: 'Repo Connection',
};

/** Resolve an area's display label: an explicit override wins, then a known
 * singleton label, then a title-cased collection id. */
export function areaLabel(area: ChangeArea, labels?: Record<string, string>): string {
  if (labels && labels[area]) return labels[area];
  if (Object.prototype.hasOwnProperty.call(SINGLETON_LABEL, area)) {
    return SINGLETON_LABEL[area as SingletonName];
  }
  return area.charAt(0).toUpperCase() + area.slice(1);
}

/** One area's staged changes, rolled up with a per-verb breakdown and a summary
 * string, for the grouped review list. */
export interface ChangeGroup {
  area: ChangeArea;
  label: string;
  count: number;
  /** Non-zero verb counts in display order, e.g. `[{verb:'edited',n:2},{verb:'new',n:1}]`. */
  breakdown: Array<{ verb: ChangeVerb; n: number }>;
  /** Human summary like "2 edited, 1 new". */
  summary: string;
  changes: PendingChange[];
}

/** Verb display order in a group's summary (new content first, removals last). */
const VERB_ORDER: readonly ChangeVerb[] = ['new', 'edited', 'published', 'archived', 'deleted'];

/**
 * Group the flat staging set by area (collection or singleton), rolling each
 * group up into a per-verb breakdown ("2 edited, 1 new") for the Publish review
 * list. Groups are sorted by their display label so the list order is stable
 * regardless of staging order. Pure — the review UI renders these, and the
 * counting/summary logic unit-tests here without a DOM.
 */
export function groupPendingChanges(changes: PendingChange[], labels?: Record<string, string>): ChangeGroup[] {
  const byArea = new Map<ChangeArea, PendingChange[]>();
  for (const c of changes) {
    const arr = byArea.get(c.collection);
    if (arr) arr.push(c);
    else byArea.set(c.collection, [c]);
  }

  const groups: ChangeGroup[] = [];
  for (const [area, list] of byArea) {
    const counts = new Map<ChangeVerb, number>();
    for (const c of list) {
      const v = changeVerb(c);
      counts.set(v, (counts.get(v) ?? 0) + 1);
    }
    const breakdown = VERB_ORDER.filter((v) => counts.has(v)).map((v) => ({ verb: v, n: counts.get(v)! }));
    const summary = breakdown.map(({ verb, n }) => `${n} ${verb}`).join(', ');
    groups.push({ area, label: areaLabel(area, labels), count: list.length, breakdown, summary, changes: list });
  }

  groups.sort((a, b) => a.label.localeCompare(b.label));
  return groups;
}

export type DiffLine = { kind: 'context' | 'add' | 'remove'; text: string };

/**
 * A line-level diff for the review screen, computed from the longest common
 * subsequence of the two line lists so only genuinely changed lines are marked
 * — unchanged interior lines (e.g. a `date` that didn't move while the `title`
 * did) stay `context` instead of being duplicated as a remove+add. Lines only in
 * `original` are removals, lines only in `updated` are additions. The review UI
 * shows the add/remove lines and drops context; the full classification is here
 * so it stays unit-testable.
 */
export function diffLines(original: string, updated: string): DiffLine[] {
  const a = original.split('\n');
  const b = updated.split('\n');
  const n = a.length;
  const m = b.length;

  // lcs[i][j] = length of the LCS of a[i:] and b[j:].
  const lcs: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      lcs[i][j] = a[i] === b[j] ? lcs[i + 1][j + 1] + 1 : Math.max(lcs[i + 1][j], lcs[i][j + 1]);
    }
  }

  const out: DiffLine[] = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      out.push({ kind: 'context', text: a[i] });
      i++;
      j++;
    } else if (lcs[i + 1][j] >= lcs[i][j + 1]) {
      out.push({ kind: 'remove', text: a[i] });
      i++;
    } else {
      out.push({ kind: 'add', text: b[j] });
      j++;
    }
  }
  while (i < n) out.push({ kind: 'remove', text: a[i++] });
  while (j < m) out.push({ kind: 'add', text: b[j++] });
  return out;
}
