// Deploy target + auth relay config for the "Commit all" flow.
//
// Which GitHub repo/branch CodeYam CMS commits to, and where the auth popup lives,
// is deploy config — NOT per-scenario content — so it lives in its own
// `src/data/cms.json` singleton rather than in `settings.json` (which the seed
// adapter rewrites per scenario). Read at build/render time with `fs` through the
// same data-root resolution as `site.ts`, then passed to the browser staging bar
// as props, so the island never needs `fs` or a fetch of its own.
import * as fs from 'fs';
import * as path from 'path';
import { resolveDataRoot } from './contentRoot';
import type { RepoTarget } from './githubCommit';

/** Repo-relative path of the deploy-connection singleton — the identity of a
 * staged `cms.json` change (see `configEditor.buildCmsConfigChange`). */
export const CMS_CONFIG_PATH = 'src/data/cms.json';

/**
 * Which sign-in options the gate offers. A pure-static site enables only
 * `token` (paste a GitHub token — zero infrastructure); a site willing to run
 * the `cms-auth-worker` can also enable `worker` for a "Sign in with GitHub"
 * popup. Both can be on at once, and at least one must be, or nobody can sign in.
 */
export interface CmsAuthOptions {
  /** Offer the paste-a-token, server-free sign-in. */
  token: boolean;
  /** Offer the "Sign in with GitHub" worker/OAuth popup (uses `authEndpoint`). */
  worker: boolean;
  /** Offer the invite-only magic-link sign-in — the GitHub-invisible path for
   * non-technical editors. Backed by the same broker as `worker`, but the
   * editor only ever sees an email + a link, never GitHub. */
  magicLink: boolean;
}

export interface CmsConfig {
  repo: RepoTarget;
  /** Path (relative to the site) of the auth popup the cms-auth-worker serves. */
  authEndpoint: string;
  /** Which sign-in paths the gate presents. */
  auth: CmsAuthOptions;
}

// The fallback when NO cms.json is committed yet: a fresh, *unconfigured* target
// (blank owner/repo) rather than a hard-coded site. A freshly-installed CodeYam
// CMS reads as "not connected" until the editor points it at a repo through the
// "Connect your repo" UI — this is what makes first-run detection clean and is
// the correct default for a reusable package. A project that commits its own
// src/data/cms.json (this repo does) is unaffected: it reads that file, never
// this fallback. Server-free by default: paste a token, no worker.
const DEFAULT_CONFIG: CmsConfig = {
  repo: { owner: '', repo: '', branch: 'main' },
  authEndpoint: '/auth',
  auth: { token: true, worker: false, magicLink: false },
};

/**
 * The raw, possibly-partial shape read from cms.json before normalization —
 * every field optional, INCLUDING the individual `auth` flags, since a hand-
 * edited cms.json may set only one of them (or omit `auth` entirely).
 */
export type RawCmsConfig = Partial<Omit<CmsConfig, 'auth'>> & { auth?: Partial<CmsAuthOptions> };

/**
 * Fill in any missing pieces so callers always get a complete config — in
 * particular a cms.json written before `auth` existed (or with only one auth
 * flag set) still yields the server-free default (token on, worker off) rather
 * than an undefined `auth`.
 */
export function normalize(raw: RawCmsConfig): CmsConfig {
  const auth = raw.auth ?? {};
  return {
    repo: raw.repo ?? DEFAULT_CONFIG.repo,
    authEndpoint: raw.authEndpoint ?? DEFAULT_CONFIG.authEndpoint,
    auth: {
      token: auth.token ?? DEFAULT_CONFIG.auth.token,
      worker: auth.worker ?? DEFAULT_CONFIG.auth.worker,
      magicLink: auth.magicLink ?? DEFAULT_CONFIG.auth.magicLink,
    },
  };
}

/**
 * Serialize a config to the canonical JSON the commit writes — a fixed key order
 * (repo, then authEndpoint, then auth) with 2-space indent and a trailing
 * newline, matching a committed `cms.json` byte-for-byte. The editor normalizes
 * its baseline through this same serializer (as the settings editor does), so
 * re-ordering keys never reads as a spurious edit and reverting cleanly unstages.
 */
export function serializeCmsConfig(config: CmsConfig): string {
  const ordered = {
    repo: {
      owner: config.repo.owner ?? '',
      repo: config.repo.repo ?? '',
      branch: config.repo.branch ?? '',
    },
    authEndpoint: config.authEndpoint ?? '',
    auth: {
      token: config.auth.token,
      worker: config.auth.worker,
      magicLink: config.auth.magicLink,
    },
  };
  return `${JSON.stringify(ordered, null, 2)}\n`;
}

/** Read `cms.json`, falling back to sane defaults if the singleton is absent. */
export function loadCmsConfig(): CmsConfig {
  try {
    const raw = fs.readFileSync(path.join(resolveDataRoot(), 'cms.json'), 'utf-8');
    return normalize(JSON.parse(raw) as RawCmsConfig);
  } catch {
    return DEFAULT_CONFIG;
  }
}
