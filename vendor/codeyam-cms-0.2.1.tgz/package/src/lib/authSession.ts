// The admin sign-in session store.
//
// A static GitHub Pages site has no server session, so "who is signed in" lives
// entirely in the browser: the commit token in localStorage (owned by
// `githubAuth.ts`) plus the GitHub profile we look up once per sign-in and cache
// alongside it. Both are in localStorage, so a signed-in editor is remembered
// across visits until they sign out. Three admin islands share this state — the
// `AuthGate` overlay, the header `AccountMenu`, and the `StagingBar` that
// discovers an expired token at commit time — so, like `pendingChangesStore`,
// every mutation both writes localStorage AND dispatches a window event the
// islands subscribe to, keeping them in sync within the tab (and, because it is
// localStorage, across tabs via the native `storage` event).
//
// Staged edits are deliberately NOT touched here: pending changes live in their
// own localStorage keys (`pendingChangesStore`), independent of this token, so
// signing out or a session expiring never discards uncommitted work.
import { cachedToken, clearToken, ensureGithubToken, setToken } from './githubAuth';
import { fetchGithubUser, TokenExpiredError, type GithubUser } from './githubUser';

export type AuthStatus = 'signed-out' | 'authenticating' | 'signed-in' | 'expired';

export interface AuthSession {
  status: AuthStatus;
  /** The signed-in identity, present only when `status === 'signed-in'`. */
  user: GithubUser | null;
}

const USER_KEY = 'codeyam-cms:gh-user';
const CHANGE_EVENT = 'codeyam-cms:auth-changed';

function hasStorage(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

function loadCachedUser(): GithubUser | null {
  if (!hasStorage()) return null;
  try {
    const raw = window.localStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as GithubUser) : null;
  } catch {
    return null;
  }
}

function cacheUser(user: GithubUser | null): void {
  if (!hasStorage()) return;
  try {
    if (user) window.localStorage.setItem(USER_KEY, JSON.stringify(user));
    else window.localStorage.removeItem(USER_KEY);
  } catch {
    /* private-mode / disabled storage — proceed without caching */
  }
}

// The codeyam preview/capture serves this app from one of two hosts: `localhost`
// (the dev server / headless screenshot capture) OR the fleet editor's reverse
// proxy (`*.fleet.codeyam.com`, the interactive Live Preview tab). A deployed
// GitHub Pages site is served from neither. In that preview context we start from
// a demo signed-in session so the admin *content* scenarios (dashboard, entry
// list, editor, media, settings) render behind a satisfied gate instead of every
// one showing the sign-in screen — the same dev-convenience trade-off Decap CMS
// makes with its local backend. Covering the fleet host (not just localhost) is
// what keeps the interactive preview signed-in, matching the captures. The gate's
// OWN states are still demonstrated by the AuthGate isolated-component scenarios,
// which pass an explicit `initialSession` and never consult this. Production is
// untouched: on the real domain the per-browser GitHub token governs the gate.
const PREVIEW_USER: GithubUser = {
  login: 'preview-editor',
  name: 'Preview Editor',
  avatarUrl:
    "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64'><rect width='64' height='64' fill='%235b3cc4'/><text x='32' y='44' font-size='34' fill='white' text-anchor='middle' font-family='sans-serif'>P</text></svg>",
};

/**
 * True for the hostnames the codeyam preview/capture serves this app from:
 * `localhost`/`127.0.0.1`/`[::1]` (direct dev-server or headless capture) and the
 * fleet editor preview domain `*.fleet.codeyam.com` (the reverse-proxied Live
 * Preview tab). A production domain (e.g. `harvardintech.com`) matches neither, so
 * the gate still governs the real site. Pure + host-only so it unit-tests directly
 * without a jsdom URL override.
 */
export function isCodeyamPreviewHost(hostname: string): boolean {
  return (
    hostname === 'localhost' ||
    hostname === '127.0.0.1' ||
    hostname === '[::1]' ||
    hostname.endsWith('.fleet.codeyam.com')
  );
}

function isCodeyamPreview(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    // jsdom (unit tests) also reports a localhost URL — exclude it so the tests
    // exercise the real signed-out/​in logic rather than this local affordance.
    if (typeof navigator !== 'undefined' && /jsdom/i.test(navigator.userAgent)) return false;
    return isCodeyamPreviewHost(window.location.hostname);
  } catch {
    return false;
  }
}

// The session derived purely from what's in storage: signed-in only when BOTH
// the token and a cached profile survive (e.g. across a page reload in the same
// tab); otherwise the gate shows — except inside the codeyam preview, where a
// demo session stands in so content scenarios aren't hidden by the gate.
function sessionFromStorage(): AuthSession {
  const token = cachedToken();
  const user = loadCachedUser();
  if (token && user) return { status: 'signed-in', user };
  if (isCodeyamPreview()) return { status: 'signed-in', user: PREVIEW_USER };
  return { status: 'signed-out', user: null };
}

let current: AuthSession | null = null;

function emit(next: AuthSession): void {
  current = next;
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
  }
}

/** The current session, hydrating from storage on first read. */
export function getSession(): AuthSession {
  if (current === null) current = sessionFromStorage();
  return current;
}

/**
 * Subscribe to session changes (same-tab custom event + cross-tab `storage`).
 * Returns an unsubscribe function.
 */
export function subscribe(callback: () => void): () => void {
  if (typeof window === 'undefined') return () => {};
  const onStorage = (e: StorageEvent) => {
    if (e.key === USER_KEY || e.key === null) {
      current = sessionFromStorage();
      callback();
    }
  };
  window.addEventListener(CHANGE_EVENT, callback);
  window.addEventListener('storage', onStorage);
  return () => {
    window.removeEventListener(CHANGE_EVENT, callback);
    window.removeEventListener('storage', onStorage);
  };
}

/** Injection seams so `signIn` is unit-testable without the popup / network. */
export interface SignInDeps {
  ensureToken?: (authEndpoint: string) => Promise<string>;
  fetchUser?: (token: string) => Promise<GithubUser>;
}

/**
 * Drive a sign-in: obtain the token (popup handshake, or the cached one) then
 * resolve the GitHub identity. Moves through `authenticating` and lands on
 * `signed-in`; on any failure (popup blocked/cancelled, network) it reverts to
 * the gate it came from — `expired` stays `expired`, otherwise `signed-out` —
 * and re-throws so the caller can surface the message.
 */
export async function signIn(authEndpoint: string, deps: SignInDeps = {}): Promise<void> {
  const ensureToken = deps.ensureToken ?? ensureGithubToken;
  const fetchUser = deps.fetchUser ?? ((t: string) => fetchGithubUser(t));

  const gateBefore = getSession().status === 'expired' ? 'expired' : 'signed-out';
  emit({ status: 'authenticating', user: null });
  try {
    const token = await ensureToken(authEndpoint);
    const user = await fetchUser(token);
    cacheUser(user);
    emit({ status: 'signed-in', user });
  } catch (e) {
    clearToken();
    cacheUser(null);
    emit({ status: gateBefore, user: null });
    throw e;
  }
}

/**
 * Sign in with a token the editor pasted directly — the server-free path. No
 * popup, no relay: we VALIDATE the token by resolving its GitHub identity (a
 * 401/403 there means the token is invalid or lacks access), then persist token
 * + profile and land on `signed-in`. On failure we leave storage untouched (so an
 * existing session is never clobbered by a bad paste), revert to the gate we came
 * from, and re-throw a message the gate can show — mapping GitHub's rejection to
 * the concrete fix (a fine-grained token scoped to this repo's contents).
 */
export async function signInWithToken(token: string, deps: SignInDeps = {}): Promise<void> {
  const fetchUser = deps.fetchUser ?? ((t: string) => fetchGithubUser(t));
  const trimmed = token.trim();
  if (!trimmed) throw new Error('Paste a GitHub token to sign in.');

  const gateBefore = getSession().status === 'expired' ? 'expired' : 'signed-out';
  emit({ status: 'authenticating', user: null });
  try {
    const user = await fetchUser(trimmed);
    setToken(trimmed);
    cacheUser(user);
    emit({ status: 'signed-in', user });
  } catch (e) {
    emit({ status: gateBefore, user: null });
    // Match by name too, not just `instanceof` — the error can cross a module
    // boundary (a fetch dep from another bundle, or a reset module registry
    // under test) where the class identity differs but the name is stable.
    const rejected = e instanceof TokenExpiredError || (e instanceof Error && e.name === 'TokenExpiredError');
    if (rejected) {
      throw new Error(
        'GitHub rejected that token. Use a fine-grained token with Contents: Read & Write on this repo.',
      );
    }
    throw e;
  }
}

/** Sign out on request: forget the token + profile and show the gate. */
export function signOut(): void {
  clearToken();
  cacheUser(null);
  emit({ status: 'signed-out', user: null });
}

/**
 * Mark the session expired — the token was rejected mid-use (e.g. a 401 when
 * committing). Forgets the token + profile and re-shows the gate with the
 * "session expired" cue. Staged edits are untouched (they live in localStorage).
 */
export function markExpired(): void {
  clearToken();
  cacheUser(null);
  emit({ status: 'expired', user: null });
}
