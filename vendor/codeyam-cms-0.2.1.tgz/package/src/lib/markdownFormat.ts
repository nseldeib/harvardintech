// The formatting-toolbar engine: pure text transforms over the body textarea.
//
// Each toolbar button (and each ⌘-shortcut) is one `FormatAction`. Given the
// textarea's current value and selection, `applyFormat` returns the new value
// plus where the selection should land afterward — so the caller writes the text
// back and restores the caret. No DOM here (the caller reads the live selection
// off the element and hands it in), so all the fiddly cases — wrap vs. insert a
// placeholder, per-line prefixes, toggling, block insertion on their own lines —
// unit-test directly and run in the browser island. Mirrors how `renderMarkdown`
// and `markdownImage` keep their logic framework-free.

/** A textarea's editable state: the text and the current selection range. */
export interface SelectionState {
  text: string;
  selectionStart: number;
  selectionEnd: number;
}

/** Every action the toolbar can apply. */
export type FormatAction =
  // inline wraps
  | 'bold'
  | 'italic'
  | 'strike'
  | 'code'
  | 'link'
  // line prefixes
  | 'h1'
  | 'h2'
  | 'h3'
  | 'quote'
  | 'ul'
  | 'ol'
  // own-line blocks
  | 'codeblock'
  | 'hr';

/** The wrap marker + the placeholder shown when nothing is selected. */
const WRAPS: Record<'bold' | 'italic' | 'strike' | 'code', { marker: string; placeholder: string }> = {
  bold: { marker: '**', placeholder: 'bold text' },
  italic: { marker: '*', placeholder: 'italic text' },
  strike: { marker: '~~', placeholder: 'strikethrough' },
  code: { marker: '`', placeholder: 'code' },
};

const HEADING_LEVEL: Record<'h1' | 'h2' | 'h3', number> = { h1: 1, h2: 2, h3: 3 };

/** Result covers [start, end); collapsed (start === end) is a caret. */
function result(text: string, selectionStart: number, selectionEnd: number): SelectionState {
  return { text, selectionStart, selectionEnd };
}

/**
 * Expand a selection to the full lines it touches. A trailing newline that the
 * selection swept up (its end sits at the start of the next line) is excluded so
 * a line-prefix action doesn't spill onto an empty following line.
 */
function lineBlock(text: string, start: number, end: number): { lineStart: number; lineEnd: number } {
  const effEnd = end > start && text[end - 1] === '\n' ? end - 1 : end;
  const lineStart = text.lastIndexOf('\n', start - 1) + 1; // 0 when no preceding newline
  let lineEnd = text.indexOf('\n', effEnd);
  if (lineEnd === -1) lineEnd = text.length;
  return { lineStart, lineEnd };
}

/** Wrap the selection in `marker`, or toggle it off if it's already wrapped. */
function applyWrap(state: SelectionState, marker: string, placeholder: string): SelectionState {
  const { text, selectionStart: s, selectionEnd: e } = state;
  const selected = text.slice(s, e);

  // Toggle off: the selection itself is the marker-wrapped text.
  if (selected.length >= 2 * marker.length && selected.startsWith(marker) && selected.endsWith(marker)) {
    const inner = selected.slice(marker.length, selected.length - marker.length);
    return result(text.slice(0, s) + inner + text.slice(e), s, s + inner.length);
  }

  const body = selected || placeholder;
  const next = text.slice(0, s) + marker + body + marker + text.slice(e);
  const innerStart = s + marker.length;
  return result(next, innerStart, innerStart + body.length);
}

/** `[text](url)` — selection becomes the link text; the caret lands in the url. */
function applyLink(state: SelectionState): SelectionState {
  const { text, selectionStart: s, selectionEnd: e } = state;
  const label = text.slice(s, e) || 'link text';
  const url = 'https://';
  const next = `${text.slice(0, s)}[${label}](${url})${text.slice(e)}`;
  // Select the url placeholder so the editor can type the address immediately.
  const urlStart = s + 1 + label.length + 2; // '[' + label + ']('
  return result(next, urlStart, urlStart + url.length);
}

/**
 * Add (or toggle off) a per-line prefix across every line the selection touches.
 * `makePrefix` receives the zero-based line index (ordered lists number up);
 * `stripRe` removes any existing prefix of this family before a new one is added.
 * `activeRe` (defaults to `stripRe`) decides whether a line already IS this style
 * — the two differ for headings, where a wrong level must be replaced (strip any
 * `#`s) but only the exact level counts as active for toggling off. The whole
 * rewritten block is selected so the change is visible.
 */
function applyLinePrefix(
  state: SelectionState,
  makePrefix: (index: number) => string,
  stripRe: RegExp,
  activeRe: RegExp = stripRe,
): SelectionState {
  const { text, selectionStart: s, selectionEnd: e } = state;
  const { lineStart, lineEnd } = lineBlock(text, s, e);
  const lines = text.slice(lineStart, lineEnd).split('\n');
  const allActive = lines.every((l) => activeRe.test(l));

  const rewritten = lines
    .map((l, i) => (allActive ? l.replace(stripRe, '') : makePrefix(i) + l.replace(stripRe, '')))
    .join('\n');

  const next = text.slice(0, lineStart) + rewritten + text.slice(lineEnd);
  return result(next, lineStart, lineStart + rewritten.length);
}

/** Insert `block` on its own lines, padded with blank lines from its surroundings. */
function insertBlock(state: SelectionState, block: string, innerOffset: number, innerLen: number): SelectionState {
  const { text, selectionStart: s, selectionEnd: e } = state;
  const before = text.slice(0, s);
  const after = text.slice(e);
  const lead = before === '' || before.endsWith('\n\n') ? '' : before.endsWith('\n') ? '\n' : '\n\n';
  const trail = after === '' || after.startsWith('\n') ? '' : '\n';
  const next = before + lead + block + trail + after;
  const at = before.length + lead.length + innerOffset;
  return result(next, at, at + innerLen);
}

/**
 * Apply a formatting action to a textarea's state, returning the new text and the
 * selection to restore. Unknown actions return the state unchanged.
 */
export function applyFormat(state: SelectionState, action: FormatAction): SelectionState {
  switch (action) {
    case 'bold':
    case 'italic':
    case 'strike':
    case 'code': {
      const { marker, placeholder } = WRAPS[action];
      return applyWrap(state, marker, placeholder);
    }
    case 'link':
      return applyLink(state);

    case 'h1':
    case 'h2':
    case 'h3': {
      const hashes = '#'.repeat(HEADING_LEVEL[action]) + ' ';
      // Strip any heading level before adding ours (so a wrong level is replaced,
      // not stacked), but only THIS exact level counts as active for toggling off.
      return applyLinePrefix(state, () => hashes, /^#{1,6} /, new RegExp(`^#{${HEADING_LEVEL[action]}} `));
    }
    case 'quote':
      return applyLinePrefix(state, () => '> ', /^> /);
    case 'ul':
      return applyLinePrefix(state, () => '- ', /^[-*] /);
    case 'ol':
      return applyLinePrefix(state, (i) => `${i + 1}. `, /^\d+\.\s/);

    case 'codeblock': {
      const { text, selectionStart: s, selectionEnd: e } = state;
      const inner = text.slice(s, e) || 'code';
      return insertBlock(state, '```\n' + inner + '\n```', 4, inner.length); // 4 = '```\n'
    }
    case 'hr':
      return insertBlock(state, '---', 3, 0);

    default:
      return state;
  }
}
