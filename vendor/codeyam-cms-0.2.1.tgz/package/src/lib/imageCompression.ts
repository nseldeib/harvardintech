// Client-side image compression, run in the browser before an upload is staged.
//
// CodeYam CMS commits uploaded images straight into the repo at
// `public/images/<name>` (see `mediaLibrary.ts`). A raw phone photo would land
// multiple megabytes into git history, forever. So before an upload is staged
// we downscale it (longest edge capped) and re-encode it to WebP — a leaner file
// commits, git history stays small, and the served image is still crisp.
//
// The split mirrors the rest of the media code: the DECISIONS are pure and
// unit-tested here (target dimensions, output format/filename, keep-smaller,
// savings), while the one function that actually touches the DOM
// (`compressImageFile` — `createImageBitmap` + `<canvas>` + `toBlob`) is a thin
// wrapper, untested in jsdom exactly like `mediaStaging`'s `FileReader` glue,
// and exercised through the media scenarios instead.

/** Longest-edge cap (px) for a downscaled image. Never upscales below this. */
export const DEFAULT_MAX_EDGE = 2048;
/** WebP encode quality (0–1). A good size/fidelity balance for web imagery. */
export const DEFAULT_QUALITY = 0.82;
/** The format compressible images are re-encoded to. */
export const OUTPUT_MIME = 'image/webp';
/** The file extension a compressed image is renamed to. */
export const OUTPUT_EXT = 'webp';

/**
 * Whether an image MIME type is one we re-encode. Raster photos (PNG/JPEG/WebP)
 * compress well on a canvas; SVG is vector (rasterizing it would bloat and blur
 * it) and GIF may be animated (a canvas capture would drop every frame but the
 * first), so both pass through untouched.
 */
export function isCompressibleType(mime: string): boolean {
  return mime === 'image/png' || mime === 'image/jpeg' || mime === 'image/webp';
}

/**
 * Downscale `srcW`×`srcH` so its longest edge is at most `maxEdge`, preserving
 * aspect ratio. Already-small images (or a zero dimension) are returned
 * unchanged — this never upscales. Result dimensions are rounded to integers.
 */
export function scaledDimensions(
  srcW: number,
  srcH: number,
  maxEdge: number = DEFAULT_MAX_EDGE,
): { width: number; height: number } {
  const longest = Math.max(srcW, srcH);
  if (longest <= maxEdge || longest <= 0) return { width: srcW, height: srcH };
  const scale = maxEdge / longest;
  return { width: Math.round(srcW * scale), height: Math.round(srcH * scale) };
}

export interface CompressionOptions {
  maxEdge?: number;
  quality?: number;
}

export interface CompressionPlan {
  /** Whether to re-encode. `false` → pass the original bytes through untouched. */
  compress: boolean;
  /** Target dimensions for the canvas draw (equal to source when no downscale). */
  targetWidth: number;
  targetHeight: number;
  /** MIME the canvas encodes to (only meaningful when `compress`). */
  outputMime: string;
  /** Encode quality passed to `toBlob` (only meaningful when `compress`). */
  quality: number;
}

/**
 * Decide how to handle an image of `srcW`×`srcH` and `mime`: pass non-raster
 * types straight through, otherwise downscale to `maxEdge` and target WebP. Pure
 * so the policy is unit-tested without a canvas.
 */
export function planCompression(
  srcW: number,
  srcH: number,
  mime: string,
  opts: CompressionOptions = {},
): CompressionPlan {
  const maxEdge = opts.maxEdge ?? DEFAULT_MAX_EDGE;
  const quality = opts.quality ?? DEFAULT_QUALITY;
  if (!isCompressibleType(mime)) {
    return { compress: false, targetWidth: srcW, targetHeight: srcH, outputMime: mime, quality };
  }
  const { width, height } = scaledDimensions(srcW, srcH, maxEdge);
  return { compress: true, targetWidth: width, targetHeight: height, outputMime: OUTPUT_MIME, quality };
}

/** Rewrite a filename's extension to `.webp`, preserving the stem. */
export function webpFilename(name: string): string {
  const dot = name.lastIndexOf('.');
  const stem = dot > 0 ? name.slice(0, dot) : name;
  return `${stem}.${OUTPUT_EXT}`;
}

/**
 * The keep-smaller guard: only adopt the re-encoded bytes if they're actually
 * smaller than the original. A small or already-optimized image can grow when
 * re-encoded — in that case the original wins.
 */
export function useCompressed(originalBytes: number, compressedBytes: number): boolean {
  return compressedBytes < originalBytes;
}

/**
 * Percentage saved going from `originalBytes` to `finalBytes`, rounded and
 * floored at 0 (a non-shrinking result reports 0, never negative). Returns 0
 * when the original size is unknown.
 */
export function savingsPercent(originalBytes: number, finalBytes: number): number {
  if (!originalBytes || originalBytes <= 0) return 0;
  return Math.max(0, Math.round((1 - finalBytes / originalBytes) * 100));
}

/** The outcome of compressing (or passing through) one uploaded file. */
export interface CompressedImage {
  /** Base64 payload of the bytes to commit (no `data:` prefix). */
  base64: string;
  /** Byte length of the committed bytes. */
  bytes: number;
  /** Original file byte length, for the before→after display. */
  originalBytes: number;
  /** Pixel dimensions of the committed image. */
  width: number;
  height: number;
  /** MIME of the committed bytes. */
  mime: string;
  /** Filename to commit under (extension rewritten to `.webp` when re-encoded). */
  filename: string;
  /** Whether re-encoding was applied (false for pass-through or kept-original). */
  compressed: boolean;
}

/** Read a Blob/File into its base64 payload (no `data:` prefix). Browser-only. */
function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error ?? new Error('Failed to read image'));
    reader.onload = () => {
      const result = String(reader.result ?? '');
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.readAsDataURL(blob);
  });
}

/**
 * Compress an uploaded image File in the browser: decode it, downscale + encode
 * to WebP per `planCompression`, and keep whichever of {re-encoded, original} is
 * smaller. Non-raster types (SVG/GIF) and images that don't shrink pass through
 * with their original bytes, filename, and MIME.
 *
 * The DOM-bound encode lives in `encodeToWebp`; the two DECISIONS this composes —
 * whether to adopt the re-encode (`useCompressed`) and the output name
 * (`webpFilename`) — are pure and unit-tested, so this stays a thin boundary
 * orchestrator covered end-to-end by the media scenarios.
 */
export async function compressImageFile(
  file: File,
  opts: CompressionOptions = {},
): Promise<CompressedImage> {
  const originalBytes = file.size;
  const encoded = isCompressibleType(file.type) ? await encodeToWebp(file, opts) : null;

  if (encoded && useCompressed(originalBytes, encoded.bytes)) {
    return {
      ...encoded,
      originalBytes,
      mime: OUTPUT_MIME,
      filename: webpFilename(file.name),
      compressed: true,
    };
  }

  // Pass-through: SVG/GIF, an encode that didn't run, or one that didn't shrink —
  // keep the original bytes, name, and type verbatim.
  return {
    base64: await blobToBase64(file),
    bytes: originalBytes,
    originalBytes,
    width: 0,
    height: 0,
    mime: file.type,
    filename: file.name,
    compressed: false,
  };
}

/** The bytes/dimensions produced by re-encoding an image to WebP on a canvas. */
interface EncodedImage {
  base64: string;
  bytes: number;
  width: number;
  height: number;
}

/**
 * Decode `file`, downscale it per `planCompression`, and re-encode to WebP on a
 * `<canvas>`. Returns `null` if the browser can't provide a 2D context or the
 * encode yields no blob, so the caller falls back to the original. Browser-only.
 */
async function encodeToWebp(file: File, opts: CompressionOptions): Promise<EncodedImage | null> {
  const bitmap = await createImageBitmap(file);
  const plan = planCompression(bitmap.width, bitmap.height, file.type, opts);

  const canvas = document.createElement('canvas');
  canvas.width = plan.targetWidth;
  canvas.height = plan.targetHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  ctx.drawImage(bitmap, 0, 0, plan.targetWidth, plan.targetHeight);
  bitmap.close?.();

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, plan.outputMime, plan.quality),
  );
  if (!blob) return null;

  return {
    base64: await blobToBase64(blob),
    bytes: blob.size,
    width: plan.targetWidth,
    height: plan.targetHeight,
  };
}
