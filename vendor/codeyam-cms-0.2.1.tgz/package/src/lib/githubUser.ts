// Fetch the signed-in GitHub user's public identity for the admin header.
//
// The commit token (see `githubAuth.ts`) authorizes writes but carries no name
// or avatar, so the admin chrome looks the profile up from GitHub's REST API
// once per sign-in. The fetch is injectable so isolated-component scenarios and
// unit tests drive the identity deterministically without a network call. A 401
// (or 403) means the token is stale/insufficient — the caller treats that as an
// expired session and re-shows the sign-in gate.
import type { FetchFn } from './githubCommit';

export interface GithubUser {
  /** GitHub handle, e.g. `octocat`. Always present. */
  login: string;
  /** Display name, when the account set one. */
  name: string | null;
  /** Absolute avatar URL from the GitHub API. */
  avatarUrl: string;
}

/** Thrown when GitHub rejects the token — the session should be treated as expired. */
export class TokenExpiredError extends Error {
  constructor(message = 'Your GitHub session is no longer valid.') {
    super(message);
    this.name = 'TokenExpiredError';
  }
}

const defaultFetch = globalThis.fetch as unknown as FetchFn;

/**
 * GET `/user` with the bearer token and map the three fields the header needs.
 * Rejects with {@link TokenExpiredError} on 401/403 so the caller can re-gate.
 */
export async function fetchGithubUser(token: string, fetchFn: FetchFn = defaultFetch): Promise<GithubUser> {
  const res = await fetchFn('https://api.github.com/user', {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
    },
  });
  if (res.status === 401 || res.status === 403) {
    throw new TokenExpiredError();
  }
  if (!res.ok) {
    throw new Error(`GitHub sign-in check failed (${res.status}).`);
  }
  const data = await res.json();
  if (!data?.login) {
    throw new Error('GitHub did not return a user profile.');
  }
  return {
    login: data.login,
    name: data.name ?? null,
    avatarUrl: data.avatar_url,
  };
}
