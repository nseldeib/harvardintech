// Pure logic for the editor roster (the /admin/editors screen).
//
// `editors.json` is content, not code: the people who can sign in to the CMS are
// an editable singleton the CMS commits like settings.json / nav.json. In the
// real system this list is the source the auth broker checks when a magic link
// is redeemed; here it is seeded per-scenario and edited on /admin/editors,
// staging a change that rides the normal one-commit flow. Framework-free so it
// unit-tests with no DOM and runs unchanged inside the browser island.
import type { PendingChange } from './pendingChanges';

export type EditorRole = 'owner' | 'editor';
export type EditorStatus = 'active' | 'invited' | 'expired';

/** One person who can sign in to the CMS. `name`/`avatarUrl` fill in once they
 * accept; a pending invite carries only the email the owner typed. */
export interface EditorRecord {
  email: string;
  name?: string;
  role: EditorRole;
  status: EditorStatus;
  /** ISO timestamp the invite was sent (absent for the founding owner). */
  invitedAt?: string;
  /** Email of whoever sent the invite. */
  invitedBy?: string;
  avatarUrl?: string;
}

/** The editors singleton shape: `{ editors: [...] }`, mirroring collections.json. */
export interface EditorsRegistry {
  editors: EditorRecord[];
}

/** Repo-relative path of the editors singleton — the staged change's identity. */
export const EDITORS_PATH = 'src/data/editors.json';

/** The production default before anyone is invited: an empty roster. The owner
 * is added when the repo is first connected, so a bare file still reads. */
export const EMPTY_EDITORS: EditorsRegistry = { editors: [] };

/** Trim + lowercase an email so equality checks and de-duping are consistent. */
export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

/** A deliberately-permissive email check — enough to catch typos and empty
 * input without rejecting the long, plus-tagged, or unusual-TLD addresses real
 * teams use. Anything with a local part, an `@`, and a dotted domain passes. */
export function isValidEmail(email: string): boolean {
  const trimmed = email.trim();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed);
}

/** The name to show for an editor: their display name, or the local-part of
 * their email while an invite is still pending (no name yet). */
export function displayName(editor: EditorRecord): string {
  if (editor.name && editor.name.trim()) return editor.name.trim();
  return editor.email.split('@')[0] ?? editor.email;
}

/** Up-to-two-letter initials for the avatar fallback. */
export function initials(editor: EditorRecord): string {
  const source = displayName(editor);
  const parts = source.split(/[\s._-]+/).filter(Boolean);
  const letters =
    parts.length >= 2 ? `${parts[0][0]}${parts[1][0]}` : source.slice(0, 2);
  return letters.toUpperCase();
}

/** Human label for a role. */
export function roleLabel(role: EditorRole): string {
  return role === 'owner' ? 'Owner' : 'Editor';
}

/** Human label for an invite/account status. */
export function statusLabel(status: EditorStatus): string {
  switch (status) {
    case 'active':
      return 'Active';
    case 'invited':
      return 'Invited';
    case 'expired':
      return 'Expired';
  }
}

/** Coerce a raw record (hand-edited JSON, seed payload) to a well-formed
 * EditorRecord — unknown roles/statuses fall back to the safe defaults. */
export function normalizeEditor(raw: Partial<EditorRecord> & { email: string }): EditorRecord {
  const role: EditorRole = raw.role === 'owner' ? 'owner' : 'editor';
  const status: EditorStatus =
    raw.status === 'active' || raw.status === 'expired' ? raw.status : 'invited';
  const out: EditorRecord = { email: raw.email, role, status };
  if (raw.name != null && raw.name !== '') out.name = raw.name;
  if (raw.invitedAt) out.invitedAt = raw.invitedAt;
  if (raw.invitedBy) out.invitedBy = raw.invitedBy;
  if (raw.avatarUrl) out.avatarUrl = raw.avatarUrl;
  return out;
}

/** Read a possibly-partial singleton into a well-formed registry. A missing or
 * non-array `editors` field resolves to the empty roster rather than throwing. */
export function readEditorsRegistry(raw: unknown): EditorsRegistry {
  const editors = (raw as EditorsRegistry | undefined)?.editors;
  if (!Array.isArray(editors)) return EMPTY_EDITORS;
  return {
    editors: editors
      .filter((e): e is EditorRecord => !!e && typeof (e as EditorRecord).email === 'string')
      .map(normalizeEditor),
  };
}

/**
 * Why an email can't be invited right now, or `null` when it can. Returns a
 * message the form shows inline: blank, malformed, or already on the roster
 * (active or pending). Keeps the invite button's guard pure + testable.
 */
export function inviteError(editors: EditorRecord[], email: string): string | null {
  const trimmed = email.trim();
  if (!trimmed) return 'Enter an email address to invite.';
  if (!isValidEmail(trimmed)) return 'That doesn’t look like a valid email address.';
  const norm = normalizeEmail(trimmed);
  if (editors.some((e) => normalizeEmail(e.email) === norm)) {
    return 'That person is already on your team.';
  }
  return null;
}

/**
 * Append a pending invite for `email`. Assumes `inviteError` already passed
 * (the island guards first); a caller that skips the guard still gets a
 * normalized, de-duped-by-caller record. `nowIso` is injected so the timestamp
 * is deterministic under test.
 */
export function addInvite(
  editors: EditorRecord[],
  email: string,
  invitedBy: string,
  nowIso: string,
): EditorRecord[] {
  const record: EditorRecord = {
    email: email.trim(),
    role: 'editor',
    status: 'invited',
    invitedAt: nowIso,
  };
  if (invitedBy) record.invitedBy = invitedBy;
  return [...editors, record];
}

/** Remove an editor / revoke an invite by email (case-insensitive). */
export function removeEditor(editors: EditorRecord[], email: string): EditorRecord[] {
  const norm = normalizeEmail(email);
  return editors.filter((e) => normalizeEmail(e.email) !== norm);
}

/** Re-send: reset a pending/expired invite back to `invited` with a fresh
 * timestamp. The owner and already-active editors are returned untouched. */
export function resendInvite(
  editors: EditorRecord[],
  email: string,
  nowIso: string,
): EditorRecord[] {
  const norm = normalizeEmail(email);
  return editors.map((e) =>
    normalizeEmail(e.email) === norm && e.role !== 'owner' && e.status !== 'active'
      ? { ...e, status: 'invited', invitedAt: nowIso }
      : e,
  );
}

/** Sort for display: owner first, then active, then invited, then expired;
 * ties keep input order (a stable sort). Does not mutate the input. */
const STATUS_ORDER: Record<EditorStatus, number> = { active: 0, invited: 1, expired: 2 };
export function sortForDisplay(editors: EditorRecord[]): EditorRecord[] {
  return [...editors].sort((a, b) => {
    if (a.role === 'owner' && b.role !== 'owner') return -1;
    if (b.role === 'owner' && a.role !== 'owner') return 1;
    return STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
  });
}

/** A relative "invited N ago" phrase for `invitedAt`, measured against `nowIso`
 * (injected for deterministic tests). Empty string when there's no timestamp. */
export function formatInvitedAgo(invitedAt: string | undefined, nowIso: string): string {
  if (!invitedAt) return '';
  const then = Date.parse(invitedAt);
  const now = Date.parse(nowIso);
  if (Number.isNaN(then) || Number.isNaN(now)) return '';
  const secs = Math.max(0, Math.round((now - then) / 1000));
  const mins = Math.round(secs / 60);
  const hours = Math.round(mins / 60);
  const days = Math.round(hours / 24);
  if (secs < 60) return 'just now';
  if (mins < 60) return `${mins} minute${mins === 1 ? '' : 's'} ago`;
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  if (days < 30) return `${days} day${days === 1 ? '' : 's'} ago`;
  const months = Math.round(days / 30);
  return `${months} month${months === 1 ? '' : 's'} ago`;
}

/** One editor normalized to canonical key order, dropping empty optionals — so
 * two rosters that differ only in key order serialize identically. */
function canonicalEditor(editor: EditorRecord): EditorRecord {
  const out: EditorRecord = {
    email: editor.email,
    role: editor.role,
    status: editor.status,
  };
  if (editor.name) out.name = editor.name;
  if (editor.invitedAt) out.invitedAt = editor.invitedAt;
  if (editor.invitedBy) out.invitedBy = editor.invitedBy;
  if (editor.avatarUrl) out.avatarUrl = editor.avatarUrl;
  return out;
}

/** Serialize the roster to the canonical JSON the commit writes — array order
 * preserved (display sorting is a UI concern), 2-space indent, trailing newline,
 * matching a committed editors.json byte-for-byte. */
export function serializeEditors(registry: EditorsRegistry): string {
  return `${JSON.stringify(
    { editors: (registry.editors ?? []).map(canonicalEditor) },
    null,
    2,
  )}\n`;
}

/**
 * Build the `PendingChange` for an editors edit. Both baselines run through the
 * same serializer, so an edit that returns the roster to its original value
 * produces `updated === original` and `upsertChange` unstages it as a no-op.
 * Writes the whole editors.json file through the normal one-commit flow.
 */
export function buildEditorsChange(
  original: EditorsRegistry,
  current: EditorsRegistry,
): PendingChange {
  return {
    collection: 'editors',
    slug: 'editors',
    path: EDITORS_PATH,
    title: 'Editors',
    original: serializeEditors(original),
    updated: serializeEditors(current),
    kind: 'edit',
  };
}
