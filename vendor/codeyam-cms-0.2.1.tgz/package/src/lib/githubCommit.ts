// Commit the whole staging set to GitHub in ONE commit.
//
// CodeYam CMS is a static GitHub Pages site — there is no server of our own to
// write files. So "Commit all" runs entirely in the browser against the GitHub
// REST API, authed with a token the `cms-auth-worker` OAuth/password relay hands
// back (the same token model Decap/Sveltia use). To land N edited files as a
// single reviewable commit (not N separate ones) we use the Git Data API:
//   ref → base commit → base tree → one blob per file → new tree → new commit → move ref
// A Contents-API-per-file approach would produce N commits and N Pages rebuilds;
// this produces exactly one.
//
// The network layer is injected (`fetchFn`), so the pure plumbing unit-tests
// against a fake transport and the scenarios can drive success/error states
// without a live repo. `buildCommitMessage` is pure.

import { isBinary, isDeletion, type ChangeEncoding, type PendingChange } from './pendingChanges';
import { contentsEndpoint, decodeContentPayload } from './githubHistory';
import { detectDrift, type DriftedChange, type RemoteContents } from './staleCheck';

export interface RepoTarget {
  owner: string;
  repo: string;
  branch: string;
}

export interface FileWrite {
  /** Repo-relative path, e.g. `src/content/blog/welcome.md`. */
  path: string;
  /** Full new file contents — text, or base64 bytes when `encoding` is `base64`. */
  content: string;
  /** Blob encoding. Absent → `utf-8` (text). `base64` for an uploaded image. */
  encoding?: ChangeEncoding;
}

export interface CommitResult {
  commitSha: string;
  /** Human URL of the commit for the success screen. */
  commitUrl: string;
}

/** Minimal fetch signature so a fake transport satisfies it in tests. */
export type FetchFn = (
  url: string,
  init: { method: string; headers: Record<string, string>; body?: string },
) => Promise<{ ok: boolean; status: number; json: () => Promise<any>; text: () => Promise<string> }>;

/**
 * The commit subject. One change names its entry directly, with a verb matching
 * what it does ("Delete", "Archive", "Publish", else "Update"); several
 * summarize the count so the repo history stays legible ("Update 3 content
 * entries via CodeYam CMS").
 */
export function buildCommitMessage(changes: Pick<PendingChange, 'title' | 'kind'>[]): string {
  if (changes.length === 0) return 'Update content via CodeYam CMS';
  if (changes.length === 1) {
    const verb =
      changes[0].kind === 'delete'
        ? 'Delete'
        : changes[0].kind === 'archive'
          ? 'Archive'
          : changes[0].kind === 'unarchive'
            ? 'Publish'
            : 'Update';
    return `${verb} "${changes[0].title}" via CodeYam CMS`;
  }
  return `Update ${changes.length} content entries via CodeYam CMS`;
}

/** Reduce the WRITE changes (everything but deletions) to the file writes the
 * commit applies. Deletions carry no content and are handled separately. */
export function changesToWrites(changes: PendingChange[]): FileWrite[] {
  return changes
    .filter((c) => !isDeletion(c))
    .map((c) => ({ path: c.path, content: c.updated, ...(c.encoding ? { encoding: c.encoding } : {}) }));
}

/** The repo-relative paths the commit removes (the deletion changes). */
export function changesToDeletes(changes: PendingChange[]): string[] {
  return changes.filter(isDeletion).map((c) => c.path);
}

async function gh(
  fetchFn: FetchFn,
  token: string,
  target: RepoTarget,
  method: string,
  endpoint: string,
  body?: unknown,
): Promise<any> {
  const url = `https://api.github.com/repos/${target.owner}/${target.repo}/${endpoint}`;
  const res = await fetchFn(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json',
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    let detail = '';
    try {
      detail = (await res.json())?.message ?? '';
    } catch {
      detail = await res.text().catch(() => '');
    }
    throw new Error(`GitHub ${method} ${endpoint} failed (${res.status})${detail ? `: ${detail}` : ''}`);
  }
  return res.json();
}

/**
 * Read ONE path as it stands on the branch right now, for the freshness check.
 *
 * This is where the check's fail-closed policy lives, stated once: a 404 is
 * `null` (absent), because absence is a meaningful answer here rather than a
 * failure — but EVERY other non-OK status throws, so a broken or rate-limited
 * API can never be mistaken for "nothing changed". A check that fell through on
 * error would vanish exactly when the API is unhealthy.
 *
 * `binary` keeps the payload base64 instead of decoding it: a binary change's
 * `original` holds base64 bytes, not text, so decoding here would report drift
 * on every image. Whitespace is stripped to match how the change stores it
 * (GitHub wraps its base64 at 60 chars).
 */
export async function fetchPathContent(
  target: RepoTarget,
  token: string,
  path: string,
  binary: boolean,
  fetchFn: FetchFn,
): Promise<string | null> {
  const url = `https://api.github.com/repos/${target.owner}/${target.repo}/${contentsEndpoint(path, target.branch)}`;
  const res = await fetchFn(url, {
    method: 'GET',
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/vnd.github+json' },
  });
  if (res.status === 404) return null;
  if (!res.ok) {
    throw new Error(`Could not check whether "${path}" changed on ${target.branch} (${res.status})`);
  }
  const body = await res.json();
  if (typeof body?.content !== 'string') {
    throw new Error(`Could not read the current contents of "${path}" on ${target.branch}`);
  }
  return binary ? body.content.replace(/\s/g, '') : decodeContentPayload(body.content, body.encoding);
}

/**
 * Read what the branch currently holds for each staged path — the `path →
 * content | null` map the drift comparison consumes.
 *
 * Distinct paths are read concurrently; the per-path read policy (404 → null,
 * fail closed otherwise, binary stays base64) lives in `fetchPathContent`, so
 * this is only the fan-out. A path staged more than once is read once.
 */
export async function fetchCurrentContents(
  target: RepoTarget,
  token: string,
  changes: PendingChange[],
  fetchFn: FetchFn,
): Promise<RemoteContents> {
  const paths = [...new Set(changes.map((c) => c.path))];
  const binaryPaths = new Set(changes.filter(isBinary).map((c) => c.path));

  const entries = await Promise.all(
    paths.map(async (path): Promise<[string, string | null]> => [
      path,
      await fetchPathContent(target, token, path, binaryPaths.has(path), fetchFn),
    ]),
  );

  return new Map(entries);
}

/**
 * Thrown instead of committing when a staged change's captured baseline no
 * longer matches the branch. Typed so the review UI can render the per-entry
 * detail and offer the safe outs, rather than showing a raw message.
 */
export class StaleBaselineError extends Error {
  readonly drifted: DriftedChange[];

  constructor(drifted: DriftedChange[]) {
    super(
      drifted.length === 1
        ? 'One of your changes is out of date — someone else edited it since you started.'
        : `${drifted.length} of your changes are out of date — someone else edited them since you started.`,
    );
    this.name = 'StaleBaselineError';
    this.drifted = drifted;
  }
}

/** Whether an unknown thrown value is the typed drift refusal. */
export function isStaleBaselineError(e: unknown): e is StaleBaselineError {
  return e instanceof StaleBaselineError;
}

export interface CommitOptions {
  /**
   * The staged changes behind `writes` / `deletes`. Supplying them enables the
   * pre-commit freshness check: each path's current content is read from the
   * branch and compared against the change's captured baseline.
   */
  changes?: PendingChange[];
  /**
   * Deliberate override — commit despite detected drift, overwriting whatever
   * the co-editor wrote. The default is to refuse; this must be a conscious
   * argument, never the default path.
   */
  overwriteDrift?: boolean;
}

/**
 * Commit every file write AND deletion to `target` as a single commit and
 * fast-forward the branch. Deletions ride the same tree as writes: a tree entry
 * with `sha: null` removes that path (the Git Data API's delete form). Rejects
 * (leaving the branch untouched — the ref is only moved on the final step) if
 * any API call fails, so a partial tree never lands.
 *
 * When `options.changes` is supplied, a freshness check runs FIRST — before any
 * blob is created — and throws `StaleBaselineError` if any staged path moved
 * underneath the editor. Gating here rather than in each caller means both
 * commit paths (`StagingBar`, `PublishPage`) are protected by construction and
 * a future third caller cannot forget. The whole commit is refused rather than
 * partially applied: staged changes commit as one atomic commit and the review
 * UI presents them as one unit, so quietly committing the clean subset would
 * split a batch the editor reviewed as a whole.
 */
export async function commitAll(
  writes: FileWrite[],
  message: string,
  target: RepoTarget,
  token: string,
  fetchFn: FetchFn,
  deletes: string[] = [],
  options: CommitOptions = {},
): Promise<CommitResult> {
  if (writes.length === 0 && deletes.length === 0) throw new Error('Nothing to commit');

  // 0. Refuse to overwrite work that landed on the branch after these changes
  //    were staged. Runs before any blob is created, so a refusal mutates
  //    nothing. A failed freshness fetch propagates here rather than falling
  //    through — fail closed.
  if (options.changes && options.changes.length > 0 && !options.overwriteDrift) {
    const remote = await fetchCurrentContents(target, token, options.changes, fetchFn);
    const drifted = detectDrift(options.changes, remote);
    if (drifted.length > 0) throw new StaleBaselineError(drifted);
  }

  // 1. Where the branch currently points.
  const ref = await gh(fetchFn, token, target, 'GET', `git/ref/heads/${target.branch}`);
  const baseCommitSha: string = ref.object.sha;

  // 2. The tree that commit is built on.
  const baseCommit = await gh(fetchFn, token, target, 'GET', `git/commits/${baseCommitSha}`);
  const baseTreeSha: string = baseCommit.tree.sha;

  // 3. A blob per edited file, plus a null-sha entry per deleted file.
  const treeItems: Array<{ path: string; mode: string; type: string; sha: string | null }> = [];
  for (const write of writes) {
    const blob = await gh(fetchFn, token, target, 'POST', 'git/blobs', {
      content: write.content,
      encoding: write.encoding ?? 'utf-8',
    });
    treeItems.push({ path: write.path, mode: '100644', type: 'blob', sha: blob.sha });
  }
  for (const path of deletes) {
    treeItems.push({ path, mode: '100644', type: 'blob', sha: null });
  }

  // 4. A new tree layering those blobs over the base tree.
  const tree = await gh(fetchFn, token, target, 'POST', 'git/trees', {
    base_tree: baseTreeSha,
    tree: treeItems,
  });

  // 5. The commit itself, parented on the current tip.
  const commit = await gh(fetchFn, token, target, 'POST', 'git/commits', {
    message,
    tree: tree.sha,
    parents: [baseCommitSha],
  });

  // 6. Move the branch to the new commit (last, so failure leaves nothing dangling).
  await gh(fetchFn, token, target, 'PATCH', `git/refs/heads/${target.branch}`, {
    sha: commit.sha,
  });

  return {
    commitSha: commit.sha,
    commitUrl: `https://github.com/${target.owner}/${target.repo}/commit/${commit.sha}`,
  };
}
