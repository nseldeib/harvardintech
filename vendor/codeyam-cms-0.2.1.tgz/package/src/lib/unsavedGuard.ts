// Pure decision logic for the entry editor's unsaved-changes guard.
//
// The guard exists because the entry editor holds edits in React state and only
// persists them when the editor clicks "Stage change" — staging writes to the
// pending-changes store (localStorage), which survives a full page navigation.
// So DIRTY (unstaged) edits are the only thing a navigation actually loses;
// staged-but-clean entries are safe to leave. These predicates encode "does
// leaving lose work?" and "should this click be intercepted?" with no DOM access,
// so they can be unit-tested in isolation; the EntryEditor island owns all the
// event wiring.

/** Copy shown in the confirmation dialog and echoed by the browser prompt. */
export const UNSAVED_TITLE = 'Unsaved edits';
export const UNSAVED_MESSAGE =
  "You've made changes to this entry that aren't staged yet. If you leave now, those edits will be lost.";

/** Whether leaving the page right now would discard unsaved work. */
export function shouldGuardNavigation(dirty: boolean): boolean {
  return dirty;
}

/** The relevant facts about an anchor the editor just saw clicked. */
export interface NavIntent {
  /** The anchor's fully-resolved absolute URL (`a.href`). */
  href: string;
  /** The literal `href` attribute as authored (`a.getAttribute('href')`). */
  rawHref: string;
  /** The anchor's `target` attribute. */
  targetAttr: string;
  /** Whether the anchor points at this page's origin (`a.origin === location.origin`). */
  sameOrigin: boolean;
  /** A cmd/ctrl/shift/alt or non-left-button click — the browser opens it elsewhere. */
  modified: boolean;
}

/**
 * The destination to guard a click toward, or `null` when the click should pass
 * through untouched. We only intercept a plain left-click that would navigate
 * THIS tab away to another page:
 *   - a modified click (new tab/window, download) — let the browser handle it;
 *     nothing is lost from this tab.
 *   - `target="_blank"` (e.g. the "View on site" link) — opens elsewhere.
 *   - a cross-origin / non-http scheme (`mailto:`, external) — `beforeunload`
 *     still covers the real unload if it happens.
 *   - an in-page `#hash` anchor — scrolls, does not leave the page.
 */
export function guardedNavTarget(intent: NavIntent): string | null {
  if (intent.modified) return null;
  if (intent.targetAttr === '_blank') return null;
  if (!intent.sameOrigin) return null;
  if (intent.rawHref.startsWith('#')) return null;
  if (!intent.href) return null;
  return intent.href;
}
