// Read an entry's version history from GitHub.
//
// CodeYam CMS's content lives in git, not a database — every edit the CMS commits
// is a commit against `src/content/*`. That makes an entry's *past versions*
// already available for free: they are the commits that touched its file. This
// module surfaces them so the editor can offer a "History" tab and restore an
// older version.
//
// Two reads, both against the GitHub REST API, both with the network layer
// injected (`fetchFn`) — the same pattern `githubPages.ts` / `githubCommit.ts`
// use — so the pure mapping unit-tests against a fake transport and the
// scenarios drive every state without a live repo:
//   • list the commits that touched the file  → GET commits?path=…&sha=<branch>
//   • read the file AS OF one commit           → GET contents/<path>?ref=<sha>
// Restore never writes here: it hands the older raw markdown back to the editor,
// which stages it through the existing review → one-commit publish pipeline.

import type { FetchFn, RepoTarget } from './githubCommit';

/** One past version of an entry — a commit that touched its file. */
export interface EntryRevision {
  /** The commit SHA this version was captured at. */
  sha: string;
  /** Commit subject (first line of the message). */
  subject: string;
  /** Display name of whoever authored the commit. */
  authorName: string;
  /** ISO timestamp the commit was authored. */
  date: string;
  /** Human URL of the commit on GitHub. */
  commitUrl: string;
}

async function ghGet(
  fetchFn: FetchFn,
  token: string,
  target: RepoTarget,
  endpoint: string,
): Promise<{ ok: boolean; status: number; body: any }> {
  const url = `https://api.github.com/repos/${target.owner}/${target.repo}/${endpoint}`;
  const res = await fetchFn(url, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/vnd.github+json',
    },
  });
  if (!res.ok) return { ok: false, status: res.status, body: null };
  return { ok: true, status: res.status, body: await res.json() };
}

/** The commit subject is the first line of the message; the rest is the body. */
export function commitSubject(message: string | undefined): string {
  if (!message) return '(no message)';
  const firstLine = message.split('\n', 1)[0].trim();
  return firstLine === '' ? '(no message)' : firstLine;
}

/**
 * Reduce the GitHub commits-listing payload to the revision list the History tab
 * renders. Pure mapping — the network is the caller's concern — so it unit-tests
 * without a live repo. Commits GitHub can't attribute (name missing) fall back
 * to the login, then to "Unknown".
 */
export function revisionsFromCommits(commits: any[]): EntryRevision[] {
  if (!Array.isArray(commits)) return [];
  return commits.map((c) => ({
    sha: c?.sha ?? '',
    subject: commitSubject(c?.commit?.message),
    authorName: c?.commit?.author?.name ?? c?.author?.login ?? 'Unknown',
    date: c?.commit?.author?.date ?? '',
    commitUrl: c?.html_url ?? '',
  }));
}

/**
 * List the commits that touched `path` on the entry's branch, newest first —
 * the entry's version history. `limit` caps how many are fetched (GitHub's
 * `per_page`, default 20) so a long-lived file doesn't pull its entire history.
 */
export async function fetchEntryHistory(
  target: RepoTarget,
  token: string,
  path: string,
  fetchFn: FetchFn,
  limit = 20,
): Promise<EntryRevision[]> {
  const endpoint = `commits?path=${encodeURIComponent(path)}&sha=${encodeURIComponent(
    target.branch,
  )}&per_page=${limit}`;
  const res = await ghGet(fetchFn, token, target, endpoint);
  if (!res.ok) {
    // An untracked file (never committed) 404s or 409s here — treat "no history"
    // as an empty list, not an error, so a freshly-created entry reads cleanly.
    if (res.status === 404 || res.status === 409) return [];
    throw new Error(`GitHub GET commits failed (${res.status})`);
  }
  return revisionsFromCommits(res.body);
}

/**
 * Decode a GitHub Contents-API base64 payload to text. The API wraps the base64
 * at 60 chars (embedded newlines) and encodes the file's UTF-8 bytes, so we
 * strip whitespace, base64-decode to bytes, then UTF-8-decode — a plain `atob`
 * would mangle any multi-byte character.
 */
export function decodeContentPayload(content: string, encoding?: string): string {
  if (encoding && encoding !== 'base64') {
    // GitHub only returns base64 for the contents endpoint; anything else is
    // already text (defensive — keeps this total).
    return content;
  }
  const b64 = content.replace(/\s/g, '');
  const binary = atob(b64);
  const bytes = Uint8Array.from(binary, (ch) => ch.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

/**
 * The Contents-API endpoint for `path` as of `ref` (a commit SHA or a branch
 * name). Each path segment is encoded separately so the slashes survive.
 * Shared with the pre-commit freshness check in `githubCommit.ts`, which reads
 * the same endpoint at the branch tip — one spelling of this URL, not two.
 */
export function contentsEndpoint(path: string, ref: string): string {
  return `contents/${path.split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(ref)}`;
}

/**
 * Read `path` exactly as it stood at commit `sha` — the raw markdown of that
 * past version, ready to parse back into editable fields for a restore.
 */
export async function fetchEntryAtCommit(
  target: RepoTarget,
  token: string,
  path: string,
  sha: string,
  fetchFn: FetchFn,
): Promise<string> {
  const res = await ghGet(fetchFn, token, target, contentsEndpoint(path, sha));
  if (!res.ok) throw new Error(`GitHub GET contents failed (${res.status})`);
  const body = res.body;
  if (typeof body?.content !== 'string') {
    throw new Error('GitHub contents response had no file content');
  }
  return decodeContentPayload(body.content, body.encoding);
}

/**
 * Format a revision timestamp for the history list. Pinned to a fixed locale and
 * UTC so a server render and its client hydration agree — matching
 * `formatDeployTime` in `githubPages.ts`. Returns '' for a missing/unparseable
 * value so the caller can omit the clause.
 */
export function formatRevisionTime(iso: string | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'UTC' })} UTC`;
}
