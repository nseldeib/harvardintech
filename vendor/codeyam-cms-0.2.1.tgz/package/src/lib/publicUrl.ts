// The public ("View on site") URL for a CMS entry, plus the tri-state that drives
// the link's enabled/disabled rendering.
//
// "View on site" jumps to the entry's REAL published page on the deployed static
// site (a new tab), which is different from the in-editor live preview (that shows
// the current, possibly-unsaved edits). The deployed base URL is editor-configured
// content — the `siteUrl` field of `settings.json` — so a custom domain
// (harvardintech.com) works the same as a github.io project site. Framework-free
// and `fs`-free (the `siteConfig.ts` pattern) so it runs in the admin islands AND
// unit-tests with no DOM.

/**
 * Join the configured site base URL with an entry's public path
 * (`<collection>/<slug>`, the convention the existing `blog/[slug]` route already
 * follows). Tolerates a trailing slash and/or a base path on `siteUrl`, always
 * emitting exactly one slash between segments. Returns `''` when `siteUrl` is
 * blank so callers can treat "no URL configured" as a distinct state.
 */
export function entryPublicUrl(siteUrl: string, collection: string, slug: string): string {
  const base = siteUrl.trim().replace(/\/+$/, '');
  if (base === '') return '';
  const path = `${collection}/${slug}`.replace(/^\/+/, '');
  return `${base}/${path}`;
}

/** The three states a "View on site" affordance can be in. */
export type ViewOnSiteState =
  | { kind: 'enabled'; href: string }
  | { kind: 'disabled'; reason: 'unpublished' | 'no-site-url'; hint: string };

export interface ViewOnSiteInput {
  /** Whether a committed/published page exists for this entry (false for a
   * brand-new entry that has never been committed). */
  published: boolean;
  /** The configured public base URL (`settings.siteUrl`); may be blank. */
  siteUrl: string;
  collection: string;
  slug: string;
}

/**
 * Derive the link state from two facts: is the entry published, and is a site URL
 * configured. Unpublished wins over a missing URL — a brand-new entry has no live
 * page to point at regardless of the URL, so it always reads "Publish to view
 * live". A published entry with no configured URL points the editor at Settings.
 */
export function viewOnSiteState({ published, siteUrl, collection, slug }: ViewOnSiteInput): ViewOnSiteState {
  if (!published) {
    return { kind: 'disabled', reason: 'unpublished', hint: 'Publish to view live' };
  }
  const href = entryPublicUrl(siteUrl, collection, slug);
  if (href === '') {
    return { kind: 'disabled', reason: 'no-site-url', hint: 'Set your site URL in Settings' };
  }
  return { kind: 'enabled', href };
}
