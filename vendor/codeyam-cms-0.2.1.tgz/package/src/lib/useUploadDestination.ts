// The upload zone's destination state: which folder the next upload lands in,
// and whether it is usable yet.
//
// The control has two modes behind one value — pick an existing folder, or type
// a new one — and a mode that CANNOT be expressed as a folder name, because
// "New folder…" is a UI state rather than a destination. That is what
// `NEW_FOLDER` is: a sentinel select value no sanitized folder can collide with
// (folders are lowercase alphanumerics and dashes), so the two modes share one
// `<select>` without a second piece of state to keep in step.
//
// Extracted from the component so the rule that actually matters — WHEN an
// upload is blocked — is testable without rendering. The subtle case is the
// half-finished one: "New folder…" chosen with an empty box is not the root, it
// is an unfinished choice, and treating it as the root would quietly file the
// upload somewhere the editor did not ask for.
import { useMemo, useState } from 'react';
import { destinationError, loadUploadDestination } from './uploadDestination';

/** Select value standing for "type a new folder name". Not a legal folder. */
export const NEW_FOLDER = ':new';

export interface UploadDestination {
  /** Current `<select>` value: a folder, '' for the root, or `NEW_FOLDER`. */
  choice: string;
  /** The typed folder name, meaningful only while `typing`. */
  newFolder: string;
  /** True when the free-text input should be shown. */
  typing: boolean;
  /** The folder an upload should go to — '' for the root. */
  destination: string;
  /** Why the upload is blocked, or null when the destination is usable. */
  invalid: string | null;
  setChoice: (value: string) => void;
  setNewFolder: (value: string) => void;
}

/**
 * Seeded once, from `initialDestination` when a scenario supplies one and
 * otherwise from the folder last used in this browser (already validated
 * against `folders`). A seed naming a folder that is not in `folders` starts in
 * the new-folder state with the name filled in — which is also how a scenario
 * demonstrates an invalid destination.
 */
export function useUploadDestination(
  folders: string[],
  initialDestination?: string,
): UploadDestination {
  const [choice, setChoice] = useState(() => {
    const seed = initialDestination ?? loadUploadDestination(folders);
    return seed && !folders.includes(seed) ? NEW_FOLDER : seed;
  });
  const [newFolder, setNewFolder] = useState(() => {
    const seed = initialDestination ?? '';
    return seed && !folders.includes(seed) ? seed : '';
  });

  const typing = choice === NEW_FOLDER;
  const destination = typing ? newFolder : choice;

  const invalid = useMemo(() => {
    if (!typing) return null;
    // An empty box under "New folder…" blocks too — it is an unfinished choice,
    // not a request to use the root.
    if (!newFolder.trim()) return 'Name the new folder.';
    return destinationError(newFolder);
  }, [typing, newFolder]);

  return { choice, newFolder, typing, destination, invalid, setChoice, setNewFolder };
}
