// Drag-to-reorder AND drag-to-re-nest for the one-level nav tree.
//
// Like `useListDrag`, but a nav node lives at a two-part address (`NavAddr`) and
// there are two kinds of drop target: a ROW (drop lands the node at that row's
// slot — reorder within a list, promote a child to top level, or move a child
// between dropdowns) and a NEST ZONE (a dropdown's indented children area — drop
// appends the node as that dropdown's last child). All the tree math is the pure
// `moveNavNode`; this hook only tracks which node is armed/lifted and which
// target the pointer is over, then fires `onMove(from, to)` on a valid drop.
//
// A dropdown (a node WITH children) can't be nested — the nav is one level deep —
// so nest zones only highlight while a LEAF is in flight (`dragIsLeaf`).
import { useState } from 'react';
import type { DragEvent, HTMLAttributes } from 'react';
import type { NavAddr } from './navEditor';

const key = (a: NavAddr) => `${a.parent}:${a.index}`;
const sameAddr = (a: NavAddr, b: NavAddr) => a.parent === b.parent && a.index === b.index;

export interface NavDrag {
  handleProps: (addr: NavAddr) => HTMLAttributes<HTMLSpanElement>;
  rowProps: (addr: NavAddr, isLeaf: boolean) => HTMLAttributes<HTMLElement>;
  nestZoneProps: (parentIndex: number, childCount: number) => HTMLAttributes<HTMLElement>;
  isDragging: (addr: NavAddr) => boolean;
  isOverRow: (addr: NavAddr) => boolean;
  isOverNest: (parentIndex: number) => boolean;
}

/** An inert NavDrag for rendering a nav row in isolation (component scenarios,
 * standalone previews) where there is no live drag session to wire into. The
 * grip handle still shows — it's part of the row's look now — but does nothing. */
export const noNavDrag: NavDrag = {
  handleProps: () => ({}),
  rowProps: () => ({}),
  nestZoneProps: () => ({}),
  isDragging: () => false,
  isOverRow: () => false,
  isOverNest: () => false,
};

export function useNavDrag(onMove: (from: NavAddr, to: NavAddr) => void): NavDrag {
  const [armed, setArmed] = useState<string | null>(null);
  const [drag, setDrag] = useState<NavAddr | null>(null);
  const [dragIsLeaf, setDragIsLeaf] = useState(false);
  const [over, setOver] = useState<string | null>(null);

  const reset = () => {
    setArmed(null);
    setDrag(null);
    setDragIsLeaf(false);
    setOver(null);
  };

  const handleProps = (addr: NavAddr): HTMLAttributes<HTMLSpanElement> => ({
    onPointerDown: () => setArmed(key(addr)),
    onPointerUp: () => setArmed((a) => (a === key(addr) ? null : a)),
  });

  const rowProps = (addr: NavAddr, isLeaf: boolean): HTMLAttributes<HTMLElement> => ({
    draggable: armed === key(addr),
    onDragStart: (e: DragEvent) => {
      e.stopPropagation();
      setDrag(addr);
      setDragIsLeaf(isLeaf);
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', key(addr));
    },
    onDragEnter: (e: DragEvent) => {
      if (!drag) return;
      e.stopPropagation();
      setOver(`row:${key(addr)}`);
    },
    onDragOver: (e: DragEvent) => {
      if (!drag) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'move';
    },
    onDrop: (e: DragEvent) => {
      if (!drag) return;
      e.preventDefault();
      e.stopPropagation();
      if (!sameAddr(drag, addr)) onMove(drag, addr);
      reset();
    },
    onDragEnd: reset,
  });

  const nestZoneProps = (parentIndex: number, childCount: number): HTMLAttributes<HTMLElement> => ({
    onDragEnter: (e: DragEvent) => {
      if (!drag || !dragIsLeaf) return;
      e.stopPropagation();
      setOver(`nest:${parentIndex}`);
    },
    onDragOver: (e: DragEvent) => {
      if (!drag || !dragIsLeaf) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'move';
    },
    onDrop: (e: DragEvent) => {
      if (!drag) return;
      e.preventDefault();
      e.stopPropagation();
      if (dragIsLeaf) onMove(drag, { parent: parentIndex, index: childCount });
      reset();
    },
  });

  return {
    handleProps,
    rowProps,
    nestZoneProps,
    isDragging: (addr) => drag !== null && sameAddr(drag, addr),
    isOverRow: (addr) => over === `row:${key(addr)}`,
    isOverNest: (parentIndex) => over === `nest:${parentIndex}`,
  };
}
