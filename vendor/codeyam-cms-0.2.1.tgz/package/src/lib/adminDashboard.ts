// Pure, framework-free helpers for the CodeYam CMS content dashboard. Kept out of
// any `.astro` component so they can be unit-tested under vitest with no DOM and
// no `astro:content` import: the page loads each collection via getCollection,
// reduces every entry to its `draft` flag, and hands the resulting arrays here.
// Data in, data out.

/** The four collections defined in code (`src/content/config.ts`). */
export type BuiltinCollectionName = 'pages' | 'blog' | 'events' | 'team';

/**
 * A content collection id that maps 1:1 to a `src/content/<id>/` folder — a
 * built-in name OR a custom collection defined at runtime in the
 * `collections.json` registry. Widened from the old built-in-only union so the
 * same pipeline (list, editor, staging) handles editor-created collections.
 */
export type CollectionName = string;

export interface CollectionDef {
  /** Collection id — also the editor deep-link segment and content folder. */
  collection: CollectionName;
  /** Human label shown on the dashboard card. */
  label: string;
  /** Singular noun for a single entry, used by the create flow ("New blog post"). */
  singular: string;
}

export interface StatusCounts {
  /** Total entries in the collection. */
  total: number;
  /** Entries that are live on the public site (draft absent or false). */
  published: number;
  /** Entries still in draft. */
  draft: number;
}

// A dashboard card is a collection identified by name + label with its counts —
// it deliberately does NOT carry the create-flow `singular` label, so hand-built
// card fixtures stay minimal. The real dashboard spreads a full CollectionDef in,
// which is assignable here (the extra `singular` key is harmless).
export interface CollectionCard extends StatusCounts {
  collection: CollectionName;
  label: string;
}

/**
 * The editable collections shown on the dashboard, in display order. Mirrors the
 * folder collections in `src/content/config.ts` (the `settings`/`nav` singletons
 * are edited elsewhere as single files, not counted here).
 */
export const ADMIN_COLLECTIONS: readonly CollectionDef[] = [
  { collection: 'pages', label: 'Pages', singular: 'page' },
  { collection: 'blog', label: 'Blog Posts', singular: 'blog post' },
  { collection: 'events', label: 'Events', singular: 'event' },
  { collection: 'team', label: 'Team', singular: 'team member' },
];

/**
 * Split a collection's entries into published vs draft. Input is one boolean per
 * entry — its `draft` frontmatter flag, where an absent/false flag means
 * published. `undefined`/`null` (missing flag) counts as published.
 */
export function countStatuses(drafts: Array<boolean | undefined | null>): StatusCounts {
  const draft = drafts.filter((d) => d === true).length;
  return { total: drafts.length, published: drafts.length - draft, draft };
}

/**
 * Roll the per-collection cards up into site-wide totals for the dashboard's
 * summary line and stat row.
 */
export function dashboardTotals(cards: CollectionCard[]): StatusCounts & { collectionCount: number } {
  return {
    total: cards.reduce((sum, c) => sum + c.total, 0),
    published: cards.reduce((sum, c) => sum + c.published, 0),
    draft: cards.reduce((sum, c) => sum + c.draft, 0),
    collectionCount: cards.length,
  };
}

/**
 * The dashboard summary sentence. With zero total entries it nudges the editor
 * to create the first one; otherwise it reports the count with correct singular
 * / plural grammar and appends a draft clause only when drafts exist.
 */
export function dashboardSummaryText(total: number, draft: number, collectionCount: number): string {
  if (total <= 0) {
    return 'No content yet — create your first entry to see it here.';
  }
  const entryWord = total === 1 ? 'entry' : 'entries';
  const draftClause = draft > 0 ? ` · ${draft} in draft` : '';
  return `Managing ${total} ${entryWord} across ${collectionCount} collections${draftClause}.`;
}

/**
 * The per-card status line beneath a collection's count. Empty collections get a
 * "No entries yet" nudge; otherwise it reports how many entries are published
 * (live on the site). The draft count is surfaced separately as a pill on the
 * card, so it is deliberately not repeated here.
 */
export function cardStatusText(counts: StatusCounts): string {
  if (counts.total <= 0) return 'No entries yet';
  return `${counts.published} published`;
}
