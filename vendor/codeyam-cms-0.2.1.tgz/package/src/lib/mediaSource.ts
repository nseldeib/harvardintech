// Build-time reader for the media library.
//
// The Media admin page and the in-editor picker need the current list of images.
// That list is a MERGE of two sources: a scan of `public/images` (which files
// exist) and the `media.json` manifest (what is known about them). Both are read
// fresh with `fs` from their resolved roots — so they reflect the per-scenario
// seeded sandbox during a codeyam session and the committed `public/images` +
// `src/data/media.json` in a production build.
//
// Scanning is what makes adoption free: a site that already has an images tree
// gets a full library the moment it installs the CMS, with no import command to
// run and no commit to make. The manifest is still the only thing the CMS
// WRITES — it records metadata about assets, never their existence.
//
// Node-only (runs at build/render time in `.astro` frontmatter), never shipped
// to the browser; the browser picker receives the merged library as props. The
// pure merge lives in `mediaLibrary.ts` so it unit-tests with no filesystem.
import * as fs from 'fs';
import * as path from 'path';
import { resolveDataRoot, resolvePublicRoot } from './contentRoot';
import {
  EMPTY_MANIFEST,
  MEDIA_URL_PREFIX,
  mergeLibrary,
  type MediaManifest,
  type MediaAsset,
  type ScannedImage,
} from './mediaLibrary';

/**
 * Extensions the gallery can render. Anything else under `public/images` (a
 * `.psd` source file, a stray `README.md`, a `.DS_Store`) is not an asset the
 * library can show, so the scan skips it rather than producing a card with a
 * broken thumbnail.
 */
const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.avif']);

/**
 * How deep the scan will recurse below `public/images`. A consumer who keeps a
 * deep asset tree there shouldn't make every page render walk it without bound;
 * the cap is generous enough that no realistic media layout hits it, and hitting
 * it is logged rather than silently truncating the library.
 */
const MAX_SCAN_DEPTH = 6;

/**
 * Read the raw committed manifest from `<dataRoot>/media.json`. A missing file
 * (the production default — nothing has been uploaded yet) or a malformed one
 * yields the empty manifest, so the gallery renders rather than throwing.
 *
 * This is the DIFF BASELINE: `buildManifestChange` stages an edit against it, so
 * it must stay the literal file contents. Feeding it the merged library instead
 * would make a single upload stage a manifest change that adds every scanned
 * image — see `readMediaLibrary` for the display counterpart.
 */
export function readCommittedManifest(): MediaManifest {
  try {
    const raw = fs.readFileSync(path.join(resolveDataRoot(), 'media.json'), 'utf-8');
    const parsed = JSON.parse(raw);
    const assets = Array.isArray(parsed?.assets) ? (parsed.assets as MediaAsset[]) : [];
    return { assets };
  } catch {
    return EMPTY_MANIFEST;
  }
}

/**
 * Every renderable image under `<publicRoot>/images`, as paths relative to that
 * directory (the asset identity) plus their size on disk.
 *
 * A missing directory yields an empty list — the same tolerant behavior the
 * manifest read has, so a project with no images renders the empty state rather
 * than failing the build. Dotfiles and non-files are skipped, and recursion
 * stops at `MAX_SCAN_DEPTH`.
 */
export function scanMediaDirectory(): ScannedImage[] {
  const root = path.join(resolvePublicRoot(), 'images');
  const found: ScannedImage[] = [];
  let truncated = false;

  const walk = (dir: string, relative: string, depth: number): void => {
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      // Missing or unreadable directory — nothing to adopt from it.
      return;
    }
    for (const entry of entries) {
      // Skip dotfiles at every level: `.DS_Store`, `.git`, editor swap files.
      if (entry.name.startsWith('.')) continue;
      const absolute = path.join(dir, entry.name);
      // Use posix separators: `filename` is an asset identity and a URL suffix,
      // so it must be `gallery/event-05.png` on Windows too.
      const rel = relative ? `${relative}/${entry.name}` : entry.name;

      if (entry.isDirectory()) {
        if (depth >= MAX_SCAN_DEPTH) {
          truncated = true;
          continue;
        }
        walk(absolute, rel, depth + 1);
        continue;
      }
      if (!entry.isFile()) continue;
      if (!IMAGE_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) continue;

      let sizeBytes: number | undefined;
      try {
        sizeBytes = fs.statSync(absolute).size;
      } catch {
        // Raced with a delete — the file still counts as absent, so skip it.
        continue;
      }
      found.push({ filename: rel, ...(sizeBytes != null ? { sizeBytes } : {}) });
    }
  };

  walk(root, '', 0);

  if (truncated) {
    console.warn(
      `[media] stopped scanning below ${MAX_SCAN_DEPTH} levels under ${MEDIA_URL_PREFIX}; ` +
        'images deeper than that are not in the library.',
    );
  }
  return found;
}

/**
 * The library the UI renders: the `public/images` scan merged with the committed
 * manifest. This is the DISPLAY list — pass it wherever a gallery or picker
 * shows what exists, and pass `readCommittedManifest()` alongside it wherever a
 * staged change needs a diff baseline.
 */
export function readMediaLibrary(): MediaManifest {
  return mergeLibrary(scanMediaDirectory(), readCommittedManifest());
}
