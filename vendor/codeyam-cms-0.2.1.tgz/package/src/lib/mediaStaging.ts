// Browser glue between an uploaded File and the staging set.
//
// The pure naming/manifest/change rules live in `mediaLibrary.ts` and the
// browser canvas compression in `imageCompression.ts`; this thin wrapper glues
// an upload to the staging store. An upload stages TWO changes together — the
// (compressed) image bytes (→ `public/images/<name>`, base64) and the manifest edit
// (→ `src/data/media.json`) — so both land in the same one-commit publish. The
// "current" library is the committed manifest with this session's staged uploads
// layered on, reconstructed from the staged manifest change in localStorage so
// the gallery shows uploads that haven't been committed yet.
import {
  MEDIA_MANIFEST_PATH,
  addAsset,
  removeAsset,
  sameAssets,
  manifestFilenames,
  assetRepoPath,
  buildImageChange,
  buildManifestChange,
  buildUploadedAsset,
  mergeLibrary,
  serializeManifest,
  type MediaAsset,
  type MediaManifest,
  type ScannedImage,
} from './mediaLibrary';
import { reorderInArray } from './siteConfig';
import { loadChanges, stageChange, discardChange } from './pendingChangesStore';
import { compressImageFile } from './imageCompression';

/**
 * The staged (uncommitted) manifest if there is one, else the committed file.
 *
 * This is the RAW manifest — the thing that will be written to `media.json` —
 * not the library the gallery shows. Every staging operation reads and writes
 * this, so a manifest change always describes a delta on the real file.
 */
function stagedManifest(committed: MediaManifest): MediaManifest {
  const staged = loadChanges().find((c) => c.path === MEDIA_MANIFEST_PATH);
  if (!staged) return committed;
  try {
    const parsed = JSON.parse(staged.updated);
    if (Array.isArray(parsed?.assets)) return { assets: parsed.assets as MediaAsset[] };
  } catch {
    // Corrupt staged manifest — fall back to the committed list.
  }
  return committed;
}

/** A merged library entry, viewed as the on-disk file it stands for. */
function toScanned(asset: MediaAsset): ScannedImage {
  return { filename: asset.filename, ...(asset.sizeBytes != null ? { sizeBytes: asset.sizeBytes } : {}) };
}

/**
 * The identities this session staged that the server's scan cannot have seen —
 * records in the staged manifest but not in the committed one. Exactly the
 * uploads whose bytes live in localStorage, and the only records allowed to
 * appear in the library without a file behind them.
 */
function stagedAdditions(committed: MediaManifest, staged: MediaManifest): string[] {
  const known = new Set(committed.assets.map((a) => a.filename.toLowerCase()));
  return staged.assets.map((a) => a.filename).filter((name) => !known.has(name.toLowerCase()));
}

/**
 * The library as it currently stands in this browser: the server-merged library
 * (disk scan + committed manifest) with this session's staged manifest change
 * layered on top.
 *
 * The layering is a re-merge rather than "use the staged list wholesale",
 * because post-adoption those two are no longer the same thing. The staged
 * manifest holds only RECORDED assets — after one upload into an adopted
 * library that is a single entry — while the gallery must keep showing every
 * scanned image. Re-merging with `library` standing in for the disk scan
 * applies the staged metadata and order to what exists, and exempting this
 * session's staged additions appends the upload whose bytes are still in
 * localStorage.
 *
 * The exemption is deliberately narrow. A committed record whose file was
 * deleted must still drop out here, exactly as it did on the server — blanket-
 * keeping every scan-less record would resurrect the broken thumbnails the
 * merge exists to remove.
 */
export function currentLibrary(library: MediaManifest, committed: MediaManifest): MediaManifest {
  const staged = stagedManifest(committed);
  return mergeLibrary(library.assets.map(toScanned), staged, {
    keepUnscanned: stagedAdditions(committed, staged),
  });
}

/**
 * Upload a file: read its bytes, name it uniquely against the current library,
 * and stage both the image blob and the updated manifest.
 *
 * The two baselines are deliberately different. `library` is the DISPLAY list
 * (scan-merged) — the upload is de-duped against it, so a new `og-default.png`
 * doesn't silently overwrite an adopted one it can already see. `committed` is
 * the raw `media.json` and the DIFF baseline: the staged manifest change adds
 * exactly this one asset to it. Building the change from the merged library
 * instead would stage a diff that writes every scanned image into the manifest
 * on the first upload.
 *
 * `destination` is the folder within `public/images` to file the upload under;
 * empty (the default) lands it in the root, exactly as before. It only has to
 * reach `buildUploadedAsset`: once the asset's identity carries the folder,
 * `buildImageChange` derives its commit path from that identity, so the blob
 * stages to `public/images/<folder>/<name>` with no further plumbing.
 *
 * Returns the new asset so the caller can select it immediately.
 */
export async function stageUpload(
  file: File,
  library: MediaManifest,
  committed: MediaManifest,
  meta: { alt?: string; width?: number; height?: number; uploadedAt?: string } = {},
  destination = '',
): Promise<MediaAsset> {
  const current = currentLibrary(library, committed);
  // Downscale + re-encode to WebP in the browser before staging, so the bytes
  // that commit to public/images (and live in git history) are lean. SVG/GIF and
  // images that don't shrink pass through untouched (see compressImageFile).
  const result = await compressImageFile(file);
  const asset = buildUploadedAsset(result.filename, manifestFilenames(current), {
    sizeBytes: result.bytes,
    // Record the pre-compression size only when compression actually shrank the
    // file, so the card's before→after detail reflects a real saving.
    ...(result.compressed && result.originalBytes > result.bytes
      ? { originalSizeBytes: result.originalBytes }
      : {}),
    ...(result.width > 0 ? { width: result.width } : {}),
    ...(result.height > 0 ? { height: result.height } : {}),
    ...meta,
  }, destination);
  // The manifest change is built on the raw manifest, NOT on `current` — one
  // added record, whatever else the scan turned up.
  const next = addAsset(stagedManifest(committed), asset);

  stageChange(buildImageChange(asset, result.base64));
  stageChange(buildManifestChange(committed, next));
  return asset;
}

/**
 * Discard a staged (uncommitted) upload: unstage its image blob and remove its
 * record from the staged manifest. If that returns the manifest to the committed
 * file, the manifest change is discarded entirely (a no-op edit shouldn't sit in
 * review); otherwise the trimmed manifest is re-staged.
 *
 * Operates on the raw manifest throughout: only recorded assets can be staged,
 * and an adopted image that was never recorded has nothing to discard.
 */
export function discardUpload(committed: MediaManifest, filename: string): void {
  discardChange(assetRepoPath(filename));
  const next = removeAsset(stagedManifest(committed), filename);
  if (sameAssets(next, committed)) discardChange(MEDIA_MANIFEST_PATH);
  else stageChange(buildManifestChange(committed, next));
}

/**
 * Drag-reorder the library: pull the asset at `from` and drop it at `to`,
 * staging the reordered manifest so the new gallery order rides the same
 * one-commit publish as an upload.
 *
 * Unlike an upload, this DOES write the whole visible library into the manifest,
 * including images the scan adopted that had no record. That is the honest
 * reading of the gesture: order is metadata, the manifest is where metadata
 * lives, and an adopted image has no recorded position until someone gives it
 * one. If the drag lands the library back where it started, the manifest change
 * is discarded rather than left as a no-op edit — mirroring `discardUpload`.
 * Reorders only shuffle records, so no image bytes are touched.
 */
export function reorderMedia(library: MediaManifest, committed: MediaManifest, from: number, to: number): void {
  const current = currentLibrary(library, committed);
  const next: MediaManifest = { assets: reorderInArray(current.assets, from, to) };
  // The no-op comparison is against the UNSTAGED library view, not the raw
  // manifest — post-adoption those differ, and comparing to the raw manifest
  // would never match once the scan contributes entries.
  if (sameAssets(next, mergeLibrary(library.assets.map(toScanned), committed))) {
    discardChange(MEDIA_MANIFEST_PATH);
  } else {
    stageChange(buildManifestChange(committed, next));
  }
}

/** Serialize helper re-export so callers don't reach past this module. */
export { serializeManifest };
