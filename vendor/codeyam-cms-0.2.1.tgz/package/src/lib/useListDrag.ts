// A tiny, dependency-free drag-to-reorder hook for a single flat list of rows.
//
// Native HTML5 drag-and-drop, no library. The wrinkle it solves: a row that is
// always `draggable` swallows text selection and makes its inputs awkward to
// use. So a row is armed as draggable ONLY while its grip handle is held —
// pointer-down on the handle arms that row, the drag begins, and any drop / end
// disarms it. The rest is bookkeeping: which row is lifted (`dragIndex`) and
// which row the pointer is currently over (`overIndex`), both surfaced so the
// caller can dim the lifted row and ring the drop target (see `dragRowStyle`).
//
// `onReorder(from, to)` fires once on a successful drop with the drag source and
// destination indices in the list's ORIGINAL indexing — feed it straight into
// `reorderInArray`. Framework glue only; the array math is pure and unit-tested
// in `siteConfig`.
import { useState } from 'react';
import type { DragEvent, HTMLAttributes } from 'react';

export interface ListDrag {
  /** Index of the row currently lifted, or null when nothing is dragging. */
  dragIndex: number | null;
  /** Index of the row the pointer is over mid-drag, or null. */
  overIndex: number | null;
  /** Props to spread on the grip handle of row `index`. */
  handleProps: (index: number) => HTMLAttributes<HTMLSpanElement>;
  /** Props to spread on the outer container of row `index`. */
  rowProps: (index: number) => HTMLAttributes<HTMLElement>;
}

export function useListDrag(onReorder: (from: number, to: number) => void): ListDrag {
  const [armedIndex, setArmedIndex] = useState<number | null>(null);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [overIndex, setOverIndex] = useState<number | null>(null);

  const reset = () => {
    setArmedIndex(null);
    setDragIndex(null);
    setOverIndex(null);
  };

  const handleProps = (index: number): HTMLAttributes<HTMLSpanElement> => ({
    onPointerDown: () => setArmedIndex(index),
    onPointerUp: () => setArmedIndex((a) => (a === index ? null : a)),
  });

  const rowProps = (index: number): HTMLAttributes<HTMLElement> => ({
    draggable: armedIndex === index,
    onDragStart: (e: DragEvent) => {
      setDragIndex(index);
      e.dataTransfer.effectAllowed = 'move';
      // Firefox refuses to start a drag unless some data is set.
      e.dataTransfer.setData('text/plain', String(index));
    },
    onDragEnter: () => {
      if (dragIndex !== null) setOverIndex(index);
    },
    onDragOver: (e: DragEvent) => {
      if (dragIndex === null) return;
      e.preventDefault(); // required to make this a valid drop target
      e.dataTransfer.dropEffect = 'move';
    },
    onDrop: (e: DragEvent) => {
      e.preventDefault();
      if (dragIndex !== null && dragIndex !== index) onReorder(dragIndex, index);
      reset();
    },
    onDragEnd: reset,
  });

  return { dragIndex, overIndex, handleProps, rowProps };
}
