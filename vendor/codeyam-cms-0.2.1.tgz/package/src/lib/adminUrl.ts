// Base-aware URL construction for the admin dashboard.
//
// Astro applies the configured `base` to injected ROUTES automatically — the
// dashboard builds to `dist/admin/…` and is served at `<base>/admin/…` without
// the integration doing anything. What Astro does NOT do is rewrite link
// strings written in markup. A bare `href="/admin"` therefore points at the
// origin root, so on any deploy that is not served from the domain root (a
// GitHub Pages project site like `owner.github.io/repo`, a site mounted under a
// path prefix) every link in the dashboard's own chrome 404s while the pages
// themselves exist. Joining each admin href with the base by hand is the fix.
//
// `import.meta.env.BASE_URL` is the one source both halves of the dashboard can
// read: Astro exposes it in `.astro` frontmatter, and Vite inlines it into
// client islands at build time, so the server-rendered chrome and the React
// islands agree without threading a prop through every component.

/**
 * Join the configured site base with a root-absolute app path.
 *
 * `path` is always written root-absolute at the call site (`/admin/media`), so
 * the dashboard's links read the same whether or not a base is configured. The
 * base defaults to the build's `BASE_URL` and is injectable for tests.
 *
 * Both halves are normalized so the result never contains a doubled slash:
 * `BASE_URL` carries a trailing slash (`/repo/`), and the path carries a
 * leading one.
 */
export function withBase(path: string, base?: string): string {
  // Anything not a site-absolute path is left exactly as written. This helper
  // is applied to user data as well as to literal links — an entry's hero image
  // may be an external URL, and a staged diff preview is a `data:` URI — and
  // prefixing either would corrupt it. Protocol-relative `//host/x` starts with
  // a slash but is external too, so it is excluded explicitly.
  if (!path.startsWith('/') || path.startsWith('//')) return path;
  const configured = base ?? (import.meta.env?.BASE_URL as string | undefined) ?? '/';
  // Strip trailing slashes so `/repo/` and `/repo` behave identically; the root
  // base `/` collapses to '' and every path passes through untouched.
  const prefix = configured.replace(/\/+$/, '');
  // The site root is the one path that must keep its slash: `/repo` + `/` is
  // `/repo/`, not the bare `/repo` a naive concatenation of '' would leave.
  if (path === '/') return prefix ? `${prefix}/` : '/';
  return `${prefix}${path}`;
}
