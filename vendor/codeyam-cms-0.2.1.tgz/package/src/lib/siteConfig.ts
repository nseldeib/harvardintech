// The shape + canonical serialization of the two editable site singletons.
//
// `settings.json` and `nav.json` are content, not code: the CMS edits them the
// same way it edits a markdown entry — stage a change, review it, commit it in
// one GitHub commit. This module is the framework-free, `fs`-free heart of that
// so it runs in the browser islands (the editors) AND unit-tests with no DOM.
// The actual disk read lives in `site.ts` (server-only, needs `fs`); the types
// live HERE so the islands can import them without pulling `fs` into the bundle.
//
// Serialization is CANONICAL: keys are emitted in a fixed order with 2-space
// indent and a trailing newline, matching the committed files byte-for-byte. The
// editor normalizes its baseline through the same serializer (as `EntryEditor`
// does for markdown), so re-ordering or re-quoting never reads as a spurious
// edit and reverting every field cleanly unstages the singleton.

/** A labelled external link shown in the site footer/header. */
export interface SocialLink {
  label: string;
  url: string;
  icon?: string;
}

/** Site-wide settings edited on the /admin/settings page. */
export interface SiteSettings {
  siteTitle: string;
  /** The deployed site's public base URL (e.g. https://harvardintech.com or a
   * https://user.github.io/repo project site). Used to build the "View on site"
   * link to an entry's real published page; blank until the editor sets it. */
  siteUrl: string;
  description: string;
  contactEmail: string;
  footerText: string;
  socials: SocialLink[];
}

/** One navigation entry: a direct link (`url`) OR a dropdown (`children`). */
export interface NavItem {
  label: string;
  url?: string;
  children?: NavItem[];
}

/** The navigation menu singleton. */
export interface SiteNav {
  items: NavItem[];
}

/** Repo-relative path of the settings singleton — the staged change's identity. */
export const SETTINGS_PATH = 'src/data/settings.json';
/** Repo-relative path of the nav singleton. */
export const NAV_PATH = 'src/data/nav.json';

/** Pretty-print a value the way the committed singletons are stored. */
function toJson(value: unknown): string {
  return `${JSON.stringify(value, null, 2)}\n`;
}

/**
 * The entries of `value` whose keys are not in `known`, in source order — the
 * one place "a key the CMS does not model" is computed. Every singleton
 * serializer preserves consumer-authored keys by appending this after its known
 * keys, so settings, the nav root, and a nav item all derive their passthrough
 * the same way instead of each re-listing what to keep.
 */
function extrasNotIn(value: object, known: readonly string[]): Record<string, unknown> {
  const set = new Set<string>(known);
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>).filter(([key]) => !set.has(key)),
  );
}

/** A social link normalized to canonical key order, dropping a blank `icon`. */
function normalizeSocial(social: SocialLink): SocialLink {
  const out: SocialLink = { label: social.label ?? '', url: social.url ?? '' };
  if (social.icon != null && social.icon !== '') out.icon = social.icon;
  return out;
}

/**
 * The settings keys the CMS models and renders inputs for. Everything else on a
 * consumer's `settings.json` is passthrough — see `serializeSettings`. Declared
 * once so "unknown" is derived here rather than re-listed by hand, the way
 * `extractExtras` derives an entry's passthrough set from its field list.
 */
export const SETTINGS_KNOWN_KEYS = [
  'siteTitle',
  'siteUrl',
  'description',
  'contactEmail',
  'footerText',
  'socials',
] as const;

/**
 * Settings as they actually exist on a consumer's disk: the shape the CMS models
 * plus any keys it does not. `readSettings` casts the parsed JSON to
 * `SiteSettings`, which hides these extras from the type checker without
 * removing them — this type names them so the serializer can be explicit that it
 * round-trips them.
 */
export type SiteSettingsWithExtras = SiteSettings & Record<string, unknown>;

/**
 * The consumer-authored keys on a settings object — everything the CMS does not
 * model, in the order they appeared in the source file. This is the settings
 * counterpart to `extractExtras`: both derive a passthrough set by subtracting a
 * known-key list rather than maintaining a second list of what to preserve.
 *
 * `serializeSettings` appends the result verbatim so a consumer's own
 * configuration survives a save. Kept separate from the serializer so the
 * passthrough is testable on its own, and reusable if `nav.json` ever needs the
 * same treatment.
 */
export function extractSettingsExtras(
  settings: SiteSettings | SiteSettingsWithExtras,
): Record<string, unknown> {
  return extrasNotIn(settings, SETTINGS_KNOWN_KEYS);
}

/**
 * Serialize settings to the canonical JSON the commit writes. The known scalars
 * first in a fixed order, then the socials list, then any keys the CMS does not
 * model — in the order they appeared in the source file — so two settings
 * objects that differ only in key order serialize identically and don't stage a
 * no-op change.
 *
 * The trailing passthrough is what keeps a consumer's own configuration alive: a
 * site may carry keys its templates read at render time (analytics IDs, custom
 * head/body HTML) that this CMS has no input for. Rebuilding the object from the
 * known keys alone would silently delete them on the first save of any unrelated
 * field. Appending them AFTER `socials` — rather than restoring their original
 * interleaved position — keeps the output byte-identical for a file that has no
 * extras, so existing consumers see no diff at all.
 */
export function serializeSettings(settings: SiteSettings | SiteSettingsWithExtras): string {
  return toJson({
    siteTitle: settings.siteTitle ?? '',
    siteUrl: settings.siteUrl ?? '',
    description: settings.description ?? '',
    contactEmail: settings.contactEmail ?? '',
    footerText: settings.footerText ?? '',
    socials: (settings.socials ?? []).map(normalizeSocial),
    ...extractSettingsExtras(settings),
  });
}

/**
 * The nav ROOT keys the CMS models. A consumer may keep its own keys beside
 * `items` (a schema version, a menu label); everything not listed here is
 * passthrough — see `serializeNav`.
 */
export const NAV_KNOWN_KEYS = ['items'] as const;

/**
 * The nav ITEM keys the CMS models and renders inputs for. Anything else on an
 * item — an `icon`, a `target`, a `badge` a consumer's layout reads at render
 * time — is passthrough, preserved by `normalizeNavItem` at every depth.
 *
 * `url` and `children` stay on this list even though the leaf/dropdown rules
 * sometimes omit them from the output: that omission is deliberate
 * normalization, and excluding by key IDENTITY is what keeps the passthrough
 * from resurrecting a dropdown's dropped `url` as an "unknown" key.
 */
export const NAV_ITEM_KNOWN_KEYS = ['label', 'url', 'children'] as const;

/**
 * A nav item / nav menu as they actually exist on a consumer's disk: the shape
 * the CMS models plus any keys it does not. `readNav` casts the parsed JSON to
 * `SiteNav`, which hides these extras from the type checker without removing
 * them. Widening HERE rather than putting an index signature on `NavItem`
 * itself keeps checking strict everywhere the nav is consumed (`NavEditor`,
 * `NavItemRow`, `NavChildRow`, and every consumer layout that reads the menu).
 */
export type NavItemWithExtras = {
  label: string;
  url?: string;
  children?: NavItemWithExtras[];
} & Record<string, unknown>;
export type SiteNavWithExtras = { items: NavItemWithExtras[] } & Record<string, unknown>;

/**
 * A nav item normalized to canonical form: a dropdown (with `children`) drops
 * its own `url`; a leaf keeps `url` and drops an empty `children`. Any key the
 * CMS does not model is appended AFTER the known keys, in source order, and the
 * recursion carries the same treatment into `children` — a nested item's extras
 * survive a parent-level edit exactly as a top-level item's do.
 *
 * Appending rather than restoring the original interleaved position keeps the
 * output byte-identical for an item that has no extras, so existing consumers
 * see no diff and a save never stages a no-op change.
 */
function normalizeNavItem(item: NavItem | NavItemWithExtras): NavItemWithExtras {
  const children: (NavItem | NavItemWithExtras)[] = item.children ?? [];
  const extras = extrasNotIn(item, NAV_ITEM_KNOWN_KEYS);
  if (children.length > 0) {
    return { label: item.label ?? '', children: children.map(normalizeNavItem), ...extras };
  }
  return { label: item.label ?? '', url: item.url ?? '', ...extras };
}

/**
 * Serialize the nav menu to the canonical JSON the commit writes: `items`
 * first, then any root-level key the CMS does not model.
 *
 * Preservation runs at BOTH levels — the root here and each item (at every
 * depth) in `normalizeNavItem`. The item level is the one that matters in
 * practice, since per-item presentation data like an `icon` is where a
 * consumer's own keys naturally live, and rebuilding items from the known keys
 * alone would silently delete them the first time an editor reordered a menu.
 */
export function serializeNav(nav: SiteNav | SiteNavWithExtras): string {
  return toJson({
    items: (nav.items ?? []).map(normalizeNavItem),
    ...extrasNotIn(nav, NAV_KNOWN_KEYS),
  });
}

/**
 * Return a copy of `list` with the item at `index` shifted by `delta` (−1 up,
 * +1 down). An out-of-range move (first-up / last-down / bad index) returns the
 * list unchanged, so the caller can wire up/down buttons without guarding the
 * ends themselves. Shared by the socials and nav reorder controls.
 */
export function moveInArray<T>(list: T[], index: number, delta: number): T[] {
  const target = index + delta;
  if (index < 0 || index >= list.length || target < 0 || target >= list.length) return list;
  const next = [...list];
  [next[index], next[target]] = [next[target], next[index]];
  return next;
}

/**
 * Return a copy of `list` with the item at `from` removed and re-inserted so it
 * lands at position `to` (in the ORIGINAL indexing — the same semantics as a
 * drag from row `from` dropped onto row `to`). A no-op move (`from === to`) or an
 * out-of-range index returns the list unchanged. This is the drag-and-drop
 * counterpart to `moveInArray`'s single-step button moves — both back the same
 * reorder controls, one for the grip-drag, one for the ↑/↓ buttons.
 */
export function reorderInArray<T>(list: T[], from: number, to: number): T[] {
  if (from < 0 || from >= list.length || to < 0 || to >= list.length || from === to) return list;
  const next = [...list];
  const [moved] = next.splice(from, 1);
  next.splice(to, 0, moved);
  return next;
}
