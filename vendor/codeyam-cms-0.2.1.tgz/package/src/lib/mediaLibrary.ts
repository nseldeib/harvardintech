// The image/media library — pure, browser-safe logic and the manifest shape.
//
// CodeYam CMS is a static GitHub Pages site: uploaded images are committed to the
// repo at `public/images/<filename>` (Astro serves `public/` verbatim, so the
// file is live at `/images/<filename>` with no build step) and the LIBRARY of
// what's been uploaded is a JSON singleton, `src/data/media.json`, shaped
// `{ assets: [...] }`. That mirrors the `nav.json` / `settings.json` singletons,
// so the same seed adapter seeds it per scenario and the same staging pipeline
// commits it.
//
// This module owns the asset shape plus the pure operations the gallery, the
// in-editor picker, and the upload flow build on: path/url conventions, filename
// sanitize + de-dupe, add/remove, and the Markdown reference an inserted image
// becomes. No `fs`, no DOM — `mediaSource.ts` does the disk read, the components
// do the File/base64 read. Kept framework-free so it unit-tests directly.

import type { PendingChange } from './pendingChanges';

/** Repo directory uploaded images are committed to (served verbatim by Astro). */
export const MEDIA_DIR = 'public/images';
/** Public URL prefix the site references an image by. */
export const MEDIA_URL_PREFIX = '/images';
/** Repo-relative path of the library manifest singleton. */
export const MEDIA_MANIFEST_PATH = 'src/data/media.json';
/** The `ChangeArea` singleton name the manifest stages under. */
export const MEDIA_AREA = 'media';

/** One image in the library. `filename` is its identity within `public/images`. */
export interface MediaAsset {
  /**
   * The asset's path *within* `public/images` — its identity, and unique.
   * May contain `/` when the image lives in a subdirectory, e.g.
   * `gallery/event-05.jpg`; a bare `summer-hackathon.jpg` is the degenerate
   * (and still default) flat case. Never has a leading slash, and never
   * contains a `.` or `..` segment — see `sanitizeAssetPath`.
   */
  filename: string;
  /** Site-relative URL the asset is referenced by, e.g. `/images/foo.jpg`. */
  url: string;
  /** Optional alt text, carried into `![alt](url)` and cover-image usage. */
  alt?: string;
  /** File size in bytes, for the gallery's detail line. */
  sizeBytes?: number;
  /** The pre-compression size in bytes, when the upload was compressed — drives
   * the "1.8 MB → 240 KB" before→after detail. Absent for uncompressed uploads. */
  originalSizeBytes?: number;
  /** Pixel dimensions when known. */
  width?: number;
  height?: number;
  /** ISO timestamp the image was uploaded. */
  uploadedAt?: string;
}

/** The library manifest singleton (`src/data/media.json`). */
export interface MediaManifest {
  assets: MediaAsset[];
}

/** An empty library — the production default until the first upload. */
export const EMPTY_MANIFEST: MediaManifest = { assets: [] };

/**
 * One image file found on disk by the `public/images` scan. The scan knows only
 * what the filesystem can tell it — the path (which is the asset identity) and
 * the byte size. Everything else about an asset is metadata and lives in the
 * manifest.
 */
export interface ScannedImage {
  /** Path within `public/images` — the same identity shape as `MediaAsset`. */
  filename: string;
  /** Size on disk, from `fs.stat`. */
  sizeBytes?: number;
}

/**
 * Merge a directory scan with the manifest into the library the UI renders.
 *
 * Disk decides which assets EXIST; the manifest decides what is KNOWN about
 * them. So a file with no manifest record is a real, selectable asset carrying
 * only what its path and size reveal, and a record whose file is gone is
 * dropped rather than rendered as a broken thumbnail. That ordering is what
 * makes adoption need no import step: a site that has never run the CMS has a
 * full library the moment it installs the package.
 *
 * Identity matching is case-insensitive across the whole path, the same rule
 * `dedupeFilename` uses — `Gallery/Photo.JPG` and `gallery/photo.jpg` are one
 * asset, so a manifest written on a case-insensitive filesystem still matches
 * the scan on a case-sensitive one.
 *
 * Order is stable and meaningful: recorded assets first, in manifest order (a
 * drag-reorder writes that order, so it must survive the merge), then
 * unrecorded scanned files sorted by path so the gallery doesn't churn between
 * builds as the filesystem's readdir order shifts.
 *
 * `keepUnscanned` exempts specific identities from the drop rule: the browser
 * passes its staged uploads, whose bytes are still in localStorage and
 * legitimately not on disk yet. It is a list rather than a flag because the two
 * kinds of scan-less record must NOT be treated alike — a staged upload has to
 * survive, while a committed record whose file was deleted is exactly what the
 * drop rule exists to remove. Server reads pass nothing; see `currentLibrary`.
 */
export function mergeLibrary(
  scanned: ScannedImage[],
  manifest: MediaManifest,
  { keepUnscanned = [] }: { keepUnscanned?: string[] } = {},
): MediaManifest {
  const exempt = new Set(keepUnscanned.map((name) => name.toLowerCase()));
  const scannedByKey = new Map<string, ScannedImage>();
  for (const file of scanned) scannedByKey.set(file.filename.toLowerCase(), file);

  const assets: MediaAsset[] = [];
  const claimed = new Set<string>();

  // Recorded assets first, in manifest order.
  for (const record of manifest.assets) {
    const key = record.filename.toLowerCase();
    const file = scannedByKey.get(key);
    if (!file) {
      // The record's file is gone. Dropping it is the point — a stale record
      // would otherwise render as a broken thumbnail the editor can't fix.
      // Unless it is an exempt identity: a staged upload holding its own bytes.
      if (exempt.has(key)) assets.push(record);
      continue;
    }
    claimed.add(key);
    assets.push(enrich(file, record));
  }

  // Then everything on disk the manifest has never heard of — the adopted set.
  const unrecorded = scanned
    .filter((file) => !claimed.has(file.filename.toLowerCase()))
    .sort((a, b) => a.filename.localeCompare(b.filename));
  for (const file of unrecorded) assets.push(enrich(file, undefined));

  return { assets };
}

/**
 * One merged asset: identity and URL derived from the path, metadata from the
 * manifest record when there is one. The record's `sizeBytes` wins over the
 * stat when present — it pairs with `originalSizeBytes` to make the card's
 * "3.2 MB → 402 KB" line, and the on-disk size IS the post-compression figure
 * that pair already describes. A file with no record falls back to its stat.
 */
function enrich(file: ScannedImage, record: MediaAsset | undefined): MediaAsset {
  const sizeBytes = record?.sizeBytes ?? file.sizeBytes;
  return {
    filename: file.filename,
    url: assetUrl(file.filename),
    ...(record?.alt ? { alt: record.alt } : {}),
    ...(sizeBytes != null ? { sizeBytes } : {}),
    ...(record?.originalSizeBytes != null ? { originalSizeBytes: record.originalSizeBytes } : {}),
    ...(record?.width != null ? { width: record.width } : {}),
    ...(record?.height != null ? { height: record.height } : {}),
    ...(record?.uploadedAt ? { uploadedAt: record.uploadedAt } : {}),
  };
}

/**
 * Repo-relative commit path for an image file: `public/images/<filename>`.
 * `filename` is a subpath, so a nested asset lands nested:
 * `gallery/event-05.jpg` → `public/images/gallery/event-05.jpg`.
 */
export function assetRepoPath(filename: string): string {
  return `${MEDIA_DIR}/${filename}`;
}

/**
 * Site URL for an image file: `/images/<filename>`. Nested the same way as
 * `assetRepoPath`: `gallery/event-05.jpg` → `/images/gallery/event-05.jpg`.
 */
export function assetUrl(filename: string): string {
  return `${MEDIA_URL_PREFIX}/${filename}`;
}

/**
 * The file-name portion of an asset path, for a human-facing label:
 * `gallery/event-05.jpg` → `event-05.jpg`. A flat name is returned unchanged.
 */
export function assetBasename(filename: string): string {
  const lastSlash = filename.lastIndexOf('/');
  return lastSlash >= 0 ? filename.slice(lastSlash + 1) : filename;
}

/**
 * The containing directory of an asset path, for a secondary label:
 * `gallery/event-05.jpg` → `gallery`. Empty string for a root-level asset,
 * which is how a caller tells "no folder" from a folder named something.
 */
export function assetDirname(filename: string): string {
  const lastSlash = filename.lastIndexOf('/');
  return lastSlash > 0 ? filename.slice(0, lastSlash) : '';
}

/**
 * Normalize an uploaded file name into a safe, URL-clean stem+extension:
 * lowercased, spaces/underscores/runs of punctuation collapsed to single
 * dashes, leading/trailing dashes trimmed, extension preserved. A name that
 * sanitizes to nothing falls back to `image`.
 */
export function sanitizeFilename(name: string): string {
  const lastDot = name.lastIndexOf('.');
  const hasExt = lastDot > 0 && lastDot < name.length - 1;
  const rawStem = hasExt ? name.slice(0, lastDot) : name;
  const rawExt = hasExt ? name.slice(lastDot + 1) : '';

  const stem = cleanSegment(rawStem) || 'image';
  const ext = cleanSegment(rawExt);
  return ext ? `${stem}.${ext}` : stem;
}

/** Lowercase, collapse runs of non-alphanumerics to `-`, trim stray dashes. */
function cleanSegment(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Normalize a *path* within `public/images` into a safe asset identity —
 * `sanitizeFilename`'s rules applied per segment, never across separators.
 * `Summer Photos/Event 05.JPG` → `summer-photos/event-05.jpg`.
 *
 * Sanitizing the whole string at once would collapse the `/` itself and
 * silently relocate the file (`gallery/event-05.jpg` → `gallery-event-05.jpg`),
 * so the split is the point of this wrapper.
 *
 * Throws on anything that could escape the media directory: a leading `/`, a
 * `.` or `..` segment, or a path that sanitizes away to nothing. Once
 * separators are legal in an identity, traversal is a real concern — an entry
 * of `../../src/pages/index.astro` would make `assetRepoPath` produce a commit
 * path outside `public/images` — and this guard is impossible to retrofit
 * safely later.
 */
export function sanitizeAssetPath(rawPath: string): string {
  const trimmed = rawPath.trim();
  if (trimmed.startsWith('/')) {
    throw new Error(`Image path must be relative to ${MEDIA_DIR}, not absolute: ${rawPath}`);
  }

  const rawSegments = trimmed.split('/').filter((s) => s !== '');
  if (rawSegments.length === 0) {
    throw new Error(`Image path is empty: ${rawPath}`);
  }
  for (const segment of rawSegments) {
    if (segment === '.' || segment === '..') {
      throw new Error(`Image path may not contain "${segment}" segments: ${rawPath}`);
    }
  }

  const last = rawSegments.length - 1;
  const segments = rawSegments.map((segment, i) =>
    // Only the final segment carries an extension; a directory's dots are just
    // punctuation, so `v1.2/` cleans to `v1-2/` rather than being split.
    i === last ? sanitizeFilename(segment) : cleanSegment(segment),
  );
  if (segments.some((s) => s === '')) {
    throw new Error(`Image path has a segment that sanitizes to nothing: ${rawPath}`);
  }
  return segments.join('/');
}

/**
 * Ensure `filename` doesn't collide with `existing`, appending `-2`, `-3`, …
 * before the extension until it's unique (case-insensitively). The comparison
 * is case-insensitive across the WHOLE path, so `Gallery/Photo.JPG` and
 * `gallery/photo.jpg` are one identity — the same reasoning that keeps
 * `Photo.JPG` and `photo.jpg` from both landing.
 *
 * Two identical basenames in different directories are distinct identities and
 * do not collide: `team/ben.jpg` and `board/ben.jpg` both stand.
 */
export function dedupeFilename(filename: string, existing: string[]): string {
  const taken = new Set(existing.map((n) => n.toLowerCase()));
  if (!taken.has(filename.toLowerCase())) return filename;

  // The extension lives in the basename, so only look for the dot after the
  // last `/` — otherwise `v1.2/photo` would split at the directory's dot and
  // produce `v1-2.2/photo`.
  const basenameStart = filename.lastIndexOf('/') + 1;
  const lastDot = filename.lastIndexOf('.');
  const hasExt = lastDot > basenameStart;
  const stem = hasExt ? filename.slice(0, lastDot) : filename;
  const ext = hasExt ? filename.slice(lastDot) : '';

  let n = 2;
  let candidate = `${stem}-${n}${ext}`;
  while (taken.has(candidate.toLowerCase())) {
    n += 1;
    candidate = `${stem}-${n}${ext}`;
  }
  return candidate;
}

/**
 * Add (or replace, by filename) an asset in a manifest, returning a new
 * manifest. Re-adding the same filename replaces its record rather than
 * duplicating it — the upload flow already de-dupes filenames, so a same-name
 * add is an intentional overwrite.
 */
export function addAsset(manifest: MediaManifest, asset: MediaAsset): MediaManifest {
  const without = manifest.assets.filter((a) => a.filename !== asset.filename);
  return { assets: [...without, asset] };
}

/** Remove an asset by filename, returning a new manifest. */
export function removeAsset(manifest: MediaManifest, filename: string): MediaManifest {
  return { assets: manifest.assets.filter((a) => a.filename !== filename) };
}

/** The filenames currently in a manifest — the de-dupe set for a new upload. */
export function manifestFilenames(manifest: MediaManifest): string[] {
  return manifest.assets.map((a) => a.filename);
}

/** Look up an asset by its site URL (how an entry references it). */
export function findAssetByUrl(manifest: MediaManifest, url: string): MediaAsset | undefined {
  return manifest.assets.find((a) => a.url === url);
}

/**
 * Whether two manifests hold the same assets in the same order, compared by
 * filename. Used when discarding a staged upload: if removing it returns the
 * library to the committed set, the manifest change should be discarded (not
 * re-staged as a no-op). Filename identity is enough — an asset's other fields
 * don't change once uploaded.
 */
export function sameAssets(a: MediaManifest, b: MediaManifest): boolean {
  if (a.assets.length !== b.assets.length) return false;
  return a.assets.every((asset, i) => asset.filename === b.assets[i]?.filename);
}

/**
 * The Markdown reference an inserted image becomes: `![alt](url)`. Alt defaults
 * to the asset's filename stem so an image dropped into the body is never left
 * with empty alt text.
 */
export function markdownImage(asset: Pick<MediaAsset, 'filename' | 'url' | 'alt'>): string {
  const alt = asset.alt?.trim() || filenameStem(asset.filename);
  return `![${alt}](${asset.url})`;
}

/**
 * The base file name without its extension, for a default label / alt text.
 * Takes the basename first, so a nested asset's default alt text reads
 * `event-05` rather than the path `gallery/event-05`.
 */
export function filenameStem(filename: string): string {
  const base = assetBasename(filename);
  const lastDot = base.lastIndexOf('.');
  return lastDot > 0 ? base.slice(0, lastDot) : base;
}

/**
 * A `data:` URL previewing a base64 image blob, with the MIME type inferred from
 * the file path's extension (`svg` → `image/svg+xml`, `jpg` → `image/jpeg`, else
 * `image/<ext>`, defaulting to png). Used by the review drawer to show a staged
 * binary change as a thumbnail without a committed file to fetch.
 */
export function imageDataUrl(path: string, base64: string): string {
  const dot = path.lastIndexOf('.');
  const ext = dot >= 0 ? path.slice(dot + 1).toLowerCase() : '';
  const mime = ext === 'svg' ? 'image/svg+xml' : ext === 'jpg' ? 'image/jpeg' : `image/${ext || 'png'}`;
  return `data:${mime};base64,${base64}`;
}

/**
 * The size portion of a card's detail line. When the asset was compressed from a
 * larger original, it reads `1.8 MB → 240 KB`; otherwise just the final size.
 */
export function sizeDetail(asset: Pick<MediaAsset, 'sizeBytes' | 'originalSizeBytes'>): string {
  const final = formatSize(asset.sizeBytes);
  if (asset.originalSizeBytes != null && asset.sizeBytes != null && asset.originalSizeBytes > asset.sizeBytes) {
    return `${formatSize(asset.originalSizeBytes)} → ${final}`;
  }
  return final;
}

/**
 * A card's full detail line: pixel dimensions and size joined by `·`, e.g.
 * `1600×900 · 1.8 MB → 262 KB`. Either half may be missing (dimensions aren't
 * always known; size isn't always recorded), and when both are the line falls
 * back to `image` so a card is never labelled with an empty row.
 */
export function assetMetaLine(
  asset: Pick<MediaAsset, 'width' | 'height' | 'sizeBytes' | 'originalSizeBytes'>,
): string {
  const dimensions = asset.width && asset.height ? `${asset.width}×${asset.height}` : '';
  return [dimensions, sizeDetail(asset)].filter(Boolean).join(' · ') || 'image';
}

/** Human-readable file size for the gallery detail line (e.g. `242 KB`). */
export function formatSize(bytes: number | undefined): string {
  if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb < 10 ? kb.toFixed(1) : Math.round(kb)} KB`;
  const mb = kb / 1024;
  return `${mb < 10 ? mb.toFixed(1) : Math.round(mb)} MB`;
}

/** Serialize a manifest to the exact JSON text committed to `media.json`. */
export function serializeManifest(manifest: MediaManifest): string {
  return `${JSON.stringify(manifest, null, 2)}\n`;
}

/**
 * Stage the image file itself as a binary write. The image's base64 bytes ride
 * in `updated` with `encoding: 'base64'`; it commits to `public/images/<name>`
 * alongside every other staged change in the one publish.
 */
export function buildImageChange(asset: MediaAsset, base64: string): PendingChange {
  return {
    collection: MEDIA_AREA,
    slug: asset.filename,
    path: assetRepoPath(asset.filename),
    title: asset.filename,
    original: '',
    updated: base64,
    kind: 'edit',
    encoding: 'base64',
  };
}

/**
 * Stage the manifest edit that records the library's assets. Keyed by the
 * manifest path, so re-staging after each upload replaces the prior manifest
 * change rather than piling up. `committed` is the on-disk manifest (the diff
 * baseline); `next` is the manifest including this session's staged uploads.
 */
export function buildManifestChange(committed: MediaManifest, next: MediaManifest): PendingChange {
  return {
    collection: MEDIA_AREA,
    slug: 'media',
    path: MEDIA_MANIFEST_PATH,
    title: 'Media library',
    original: serializeManifest(committed),
    updated: serializeManifest(next),
    kind: 'edit',
  };
}

/**
 * The distinct folders images currently live in, for offering an upload
 * destination. Derived from the asset paths themselves — the library IS the
 * source of truth for which folders exist, including ones the CMS never created
 * — so no config or manifest field has to be kept in step with the tree.
 *
 * The root is always first and always present (it is a legitimate destination
 * even on a site that files everything into folders, and it is the only option
 * an empty library can offer); the rest are sorted for a stable list.
 */
export function libraryFolders(manifest: MediaManifest): string[] {
  const folders = new Set<string>();
  for (const asset of manifest.assets) {
    const dir = assetDirname(asset.filename);
    if (dir) folders.add(dir);
  }
  return ['', ...[...folders].sort((a, b) => a.localeCompare(b))];
}

/**
 * Build the asset record for a freshly uploaded file. Pure given the already-read
 * upload facts (bytes read + base64 encoding happen in the browser component),
 * so the naming/de-dupe rules stay unit-testable. `filename` is sanitized and
 * de-duped against `existing`.
 *
 * `destination` is the folder within `public/images` the upload should land in.
 * Empty (the default) keeps the historical flat behavior exactly. Otherwise the
 * folder is joined to the sanitized name and the whole thing goes through
 * `sanitizeAssetPath`, so each segment is cleaned by its own rules and the
 * separator survives rather than collapsing the destination into the filename.
 * That also means the traversal guards apply: an escaping destination THROWS
 * here rather than producing a path outside the media directory, which is why
 * the UI validates the folder before it ever reaches an upload.
 *
 * De-duping then happens against the full path, so `ben.jpg` uploaded into
 * `team/` does not collide with an existing `board/ben.jpg`.
 */
export function buildUploadedAsset(
  rawName: string,
  existing: string[],
  meta: {
    sizeBytes?: number;
    originalSizeBytes?: number;
    width?: number;
    height?: number;
    uploadedAt?: string;
    alt?: string;
  } = {},
  destination = '',
): MediaAsset {
  const folder = destination.trim();
  const named = folder
    ? sanitizeAssetPath(`${folder}/${sanitizeFilename(rawName)}`)
    : sanitizeFilename(rawName);
  const filename = dedupeFilename(named, existing);
  return {
    filename,
    url: assetUrl(filename),
    ...(meta.alt ? { alt: meta.alt } : {}),
    ...(meta.sizeBytes != null ? { sizeBytes: meta.sizeBytes } : {}),
    ...(meta.originalSizeBytes != null ? { originalSizeBytes: meta.originalSizeBytes } : {}),
    ...(meta.width != null ? { width: meta.width } : {}),
    ...(meta.height != null ? { height: meta.height } : {}),
    ...(meta.uploadedAt ? { uploadedAt: meta.uploadedAt } : {}),
  };
}
