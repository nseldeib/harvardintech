// Pure logic for the "Repository connection" section of /admin/settings — the
// "Connect your repo" editor.
//
// The `ConnectionEditor` island is a thin shell over these helpers: they declare
// which repo-target fields the form renders, apply immutable edits to the config,
// validate it (required owner/repo + the at-least-one-sign-in guardrail), decide
// whether a site is still unconfigured (first-run), and turn the edited config
// into a `PendingChange` the existing staging/commit pipeline understands.
// Framework-free (no React, no `fs`) so it unit-tests with no DOM and runs
// unchanged in the browser island — the `settingsEditor.ts` pattern applied to
// the `cms.json` singleton instead of `settings.json`.

import type { CmsConfig, CmsAuthOptions } from './cmsConfig';
import { CMS_CONFIG_PATH, serializeCmsConfig } from './cmsConfig';
import type { RepoTarget } from './githubCommit';
import type { PendingChange } from './pendingChanges';

/** A repo-target scalar the form renders as one labelled text input. */
export interface RepoFieldDef {
  /** Key on `RepoTarget` — also the form input name. */
  name: keyof RepoTarget;
  label: string;
  placeholder: string;
  /** Blank is allowed (falls back to a default on save) vs. must be filled. */
  required: boolean;
}

/** The repo-target fields, in display order. `branch` is optional — it defaults
 * to `main` on save — while owner and repo must be filled to connect. */
export const REPO_FIELDS: readonly RepoFieldDef[] = [
  { name: 'owner', label: 'GitHub owner', placeholder: 'e.g. jaredcosulich', required: true },
  { name: 'repo', label: 'Repository', placeholder: 'e.g. harvardintech', required: true },
  { name: 'branch', label: 'Branch', placeholder: 'main', required: false },
];

/** The branch used when the editor leaves the branch field blank. */
export const DEFAULT_BRANCH = 'main';

/** Patch one repo-target field, leaving the rest of the config untouched. */
export function setRepoField(config: CmsConfig, name: keyof RepoTarget, value: string): CmsConfig {
  return { ...config, repo: { ...config.repo, [name]: value } };
}

/** Flip one sign-in option (token / worker), leaving the rest untouched. */
export function setAuthFlag(config: CmsConfig, name: keyof CmsAuthOptions, on: boolean): CmsConfig {
  return { ...config, auth: { ...config.auth, [name]: on } };
}

/** Set the worker auth endpoint (only meaningful while `auth.worker` is on). */
export function setAuthEndpoint(config: CmsConfig, endpoint: string): CmsConfig {
  return { ...config, authEndpoint: endpoint };
}

/**
 * A site is "unconfigured" (first-run) when it has no repo to commit to yet —
 * owner or repo is still blank. This drives the first-run "Connect your repo"
 * copy vs. the "connected, editable" copy, and matches the blank-owner/repo
 * fallback `cmsConfig.DEFAULT_CONFIG` returns when no `cms.json` is committed.
 */
export function isUnconfigured(config: CmsConfig): boolean {
  return config.repo.owner.trim() === '' || config.repo.repo.trim() === '';
}

/** A per-field/guardrail validation error keyed by what it blocks. */
export interface CmsConfigErrors {
  owner?: string;
  repo?: string;
  /** The at-least-one-sign-in-option guardrail. */
  auth?: string;
}

/**
 * Validate a config for saving. Owner and repo are required (a commit target
 * needs both); at least one sign-in option must stay enabled or nobody could
 * ever sign in to commit. Branch is not validated — it defaults to `main`.
 * Returns an empty object when the config is savable.
 */
export function validateCmsConfig(config: CmsConfig): CmsConfigErrors {
  const errors: CmsConfigErrors = {};
  if (config.repo.owner.trim() === '') errors.owner = 'Enter the GitHub owner or org.';
  if (config.repo.repo.trim() === '') errors.repo = 'Enter the repository name.';
  if (!config.auth.token && !config.auth.worker && !config.auth.magicLink) {
    errors.auth = 'Enable at least one sign-in option, or no one could sign in.';
  }
  return errors;
}

/** True when the config has no validation errors and can be staged. */
export function isValidCmsConfig(config: CmsConfig): boolean {
  return Object.keys(validateCmsConfig(config)).length === 0;
}

/**
 * Normalize a config for saving: trim the repo fields and fall back to the
 * default branch when it is left blank, so a staged `cms.json` is always clean.
 */
export function normalizeForSave(config: CmsConfig): CmsConfig {
  return {
    ...config,
    repo: {
      owner: config.repo.owner.trim(),
      repo: config.repo.repo.trim(),
      branch: config.repo.branch.trim() || DEFAULT_BRANCH,
    },
    authEndpoint: config.authEndpoint.trim() || '/auth',
  };
}

/**
 * Build the `PendingChange` for a connection edit, targeting `cms.json`. Both
 * baselines run through the same canonical serializer, so an edit that returns
 * the config to its committed value produces `updated === original` and
 * `upsertChange` unstages it as a no-op — exactly like `buildSettingsChange`.
 */
export function buildCmsConfigChange(original: CmsConfig, current: CmsConfig): PendingChange {
  return {
    collection: 'cms',
    slug: 'cms',
    path: CMS_CONFIG_PATH,
    title: 'Repository connection',
    original: serializeCmsConfig(original),
    updated: serializeCmsConfig(normalizeForSave(current)),
    kind: 'edit',
  };
}
