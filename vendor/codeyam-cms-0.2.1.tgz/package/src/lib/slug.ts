// Turn a human title into a URL/file slug — the filename an entry's markdown is
// written under (`src/content/<collection>/<slug>.md`). The new-entry editor
// derives the slug from the title as you type, so this is the single source of
// truth for that transform. Framework-free so it unit-tests and runs in the
// browser island.

/**
 * Strict slug: lowercase, diacritics stripped, every run of non-alphanumeric
 * characters collapsed to a single hyphen, and leading/trailing hyphens
 * trimmed. `slugify('Café Renovation!') === 'cafe-renovation'`. This is the
 * value used for the file path and the collision check.
 */
export function slugify(text: string): string {
  return text
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '') // drop combining diacritical marks
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-') // any non-alphanumeric run → one hyphen
    .replace(/^-+|-+$/g, ''); // no leading/trailing hyphens
}
