// The single place the package asks "am I running in a production build?".
//
// Split into its own module for one concrete reason: `import.meta.env.PROD` is
// injected by Vite and is NOT stubbable from a test (`vi.stubEnv` refuses the
// reserved `PROD`/`DEV`/`MODE` keys). Isolating the read behind one exported
// function gives callers — `publishFilter` today — a seam a test can mock, so
// their production and dev behavior are both directly exercised rather than
// asserted only through an explicit override.

/**
 * True during `astro build`, false under `astro dev`.
 *
 * Read defensively rather than through `vite/client` types: the package has no
 * `env.d.ts`, and this also keeps importers loadable from bare Node, where
 * `import.meta.env` is simply absent — which reads as "not production", the
 * safe default for a dev or test context.
 */
export function isProductionBuild(): boolean {
  const env = (import.meta as ImportMeta & { env?: { PROD?: boolean } }).env;
  return env?.PROD === true;
}

/** The build-identifying variables the marker is stamped from. */
export interface BuildStampEnv {
  GITHUB_SHA?: string | undefined;
  GITHUB_RUN_ID?: string | undefined;
}

/** The marker payload a deployed site serves at `<site>/deploy-status.json`. */
export interface DeployMarkerPayload {
  commit: string;
  runId: string;
  builtAt: string;
}

/**
 * Build the deploy marker's payload from the build environment.
 *
 * Takes `env` and `now` as parameters rather than reading them itself so the
 * whole contract — which variables are read, what an unset one becomes — is
 * exercisable without an Actions runner. That is the same injection seam
 * `PollOptions` uses for `sleep`/`now`.
 *
 * The `'local'` fallback matters: off-CI it is a CONSTANT, so a local build can
 * never look like a new deployment to the change-detection check. Returning the
 * build's own SHA is what makes the served marker change exactly when — and only
 * when — new bytes are published.
 */
export function buildDeployMarker(env: BuildStampEnv, now: Date): DeployMarkerPayload {
  return {
    commit: env.GITHUB_SHA || 'local',
    runId: env.GITHUB_RUN_ID || 'local',
    builtAt: now.toISOString(),
  };
}

/**
 * Read the build environment defensively. `process` is absent in a browser or an
 * edge runtime, where an unguarded `process.env` would throw at module scope.
 */
export function readBuildStampEnv(): BuildStampEnv {
  return (globalThis as { process?: { env?: BuildStampEnv } }).process?.env ?? {};
}
