// Pure helpers for the SEO & Social feature: resolving an entry's *effective*
// share metadata (the override-or-fallback chain the rendered <head> emits) and
// the display shaping the social-card preview needs. Framework-free (no React,
// no DOM, no astro:content) so the resolution + truncation rules unit-test
// directly and run in the browser island. The EntryEditor's card preview and the
// public page's SEO tags both resolve through here, so what an editor sees in the
// preview is exactly what a crawler gets.
import { asStr } from './entryPreview';
import type { RawFieldValue } from './entryEditor';

/** The four SEO override fields, read off an entry's frontmatter / form values. */
export interface SeoOverrides {
  seoTitle?: string;
  seoDescription?: string;
  socialImage?: string;
  canonicalUrl?: string;
}

/** The fallbacks the entry itself and the site provide when an override is blank. */
export interface SeoFallbacks {
  /** The entry's own title/name, already resolved to a display string. */
  entryTitle?: string;
  /** The entry's summary/description prose. */
  entryDescription?: string;
  /** The entry's cover image / photo URL. */
  entryImage?: string;
  /** Site-wide title, appended after a page title as "Page · Site". */
  siteTitle?: string;
  /** Site-wide description, the last-resort meta description. */
  siteDescription?: string;
  /** The page's own URL — the canonical fallback. */
  pageUrl?: string;
}

/** Resolved share metadata + provenance flags (true = the value came from an override). */
export interface EffectiveSeo {
  /** The document/OG title: "Page · Site", or the bare site title if no page title. */
  title: string;
  description: string;
  /** '' when neither an override nor a cover image is set (the imageless card). */
  image: string;
  /** The override, else the page's own URL (blank only when neither is known). */
  canonicalUrl: string;
  fromOverride: {
    title: boolean;
    description: boolean;
    image: boolean;
    canonicalUrl: boolean;
  };
}

/** Display limits mirroring how X / Facebook / LinkedIn truncate a share card. */
export const CARD_TITLE_MAX = 70;
export const CARD_DESCRIPTION_MAX = 200;

function clean(v: string | undefined): string {
  return typeof v === 'string' ? v.trim() : '';
}

/**
 * Resolve an entry's effective share metadata from its overrides, the entry's own
 * fallbacks, and the site defaults. Mirrors what `SEO.astro` emits so the preview
 * and the live tags never diverge: the page title becomes "Page · Site" (or the
 * bare site title), the description falls back summary → site, the image falls
 * back to the cover image (else imageless), and the canonical falls back to the
 * page's own URL.
 */
export function effectiveSeo(overrides: SeoOverrides, fallbacks: SeoFallbacks): EffectiveSeo {
  const seoTitle = clean(overrides.seoTitle);
  const seoDescription = clean(overrides.seoDescription);
  const socialImage = clean(overrides.socialImage);
  const canonical = clean(overrides.canonicalUrl);

  const siteTitle = clean(fallbacks.siteTitle);
  const pageTitle = seoTitle || clean(fallbacks.entryTitle);
  const title = pageTitle ? (siteTitle ? `${pageTitle} · ${siteTitle}` : pageTitle) : siteTitle;

  const description =
    seoDescription || clean(fallbacks.entryDescription) || clean(fallbacks.siteDescription);
  const image = socialImage || clean(fallbacks.entryImage);
  const canonicalUrl = canonical || clean(fallbacks.pageUrl);

  return {
    title,
    description,
    image,
    canonicalUrl,
    fromOverride: {
      title: seoTitle !== '',
      description: seoDescription !== '',
      image: socialImage !== '',
      canonicalUrl: canonical !== '',
    },
  };
}

/** Read the four SEO overrides off the editor's raw form values. */
export function overridesFromValues(values: Record<string, RawFieldValue>): SeoOverrides {
  return {
    seoTitle: asStr(values.seoTitle),
    seoDescription: asStr(values.seoDescription),
    socialImage: asStr(values.socialImage),
    canonicalUrl: asStr(values.canonicalUrl),
  };
}

/**
 * Truncate to `max` characters for the card, breaking on a word boundary when one
 * falls reasonably near the limit, and appending an ellipsis. A string already
 * within the limit is returned trimmed and unchanged.
 */
export function truncate(text: string, max: number): string {
  const t = text.trim();
  if (t.length <= max) return t;
  const slice = t.slice(0, max - 1);
  const lastSpace = slice.lastIndexOf(' ');
  const cut = lastSpace > max * 0.6 ? slice.slice(0, lastSpace) : slice;
  return `${cut.trimEnd()}…`;
}

/**
 * The domain shown on the social card, derived from a URL: scheme, `www.`, and
 * any path stripped, leaving a bare host like `example.com`. Falls back to a
 * best-effort strip of the raw input when it isn't a parseable absolute URL.
 */
export function cardDomain(url: string): string {
  const raw = url.trim();
  if (!raw) return '';
  try {
    return new URL(raw).hostname.replace(/^www\./, '');
  } catch {
    return raw.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
  }
}
