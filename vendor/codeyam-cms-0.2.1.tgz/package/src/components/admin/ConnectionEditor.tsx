// The "Repository connection" editor island — the "Connect your repo" section of
// /admin/settings. It is the state-owning root over the pure `configEditor`
// helpers: it owns the config state, validates on every edit (required
// owner/repo + the at-least-one-sign-in guardrail), and stages a `cms.json`
// change into the shared pending-changes store. It composes the presentational
// ConnectionIntro + ConnectionRepoFields + ConnectionAuthOptions + StageFooter
// (the SettingsEditor shape). Like SettingsEditor, "Stage change" does NOT write
// cms.json — it serializes the edited config to canonical JSON and adds a
// PendingChange the global StagingBar commits later, batched with other changes.
import { useEffect, useMemo, useState } from 'react';
import type { CmsConfig, CmsAuthOptions } from '../../lib/cmsConfig';
import { serializeCmsConfig, CMS_CONFIG_PATH } from '../../lib/cmsConfig';
import type { RepoTarget } from '../../lib/githubCommit';
import {
  buildCmsConfigChange,
  validateCmsConfig,
  isUnconfigured,
  setRepoField,
  setAuthFlag,
  setAuthEndpoint,
} from '../../lib/configEditor';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import ConnectionIntro from './ConnectionIntro';
import ConnectionRepoFields from './ConnectionRepoFields';
import ConnectionAuthOptions from './ConnectionAuthOptions';
import StageFooter from './StageFooter';

interface Props {
  initialConfig: CmsConfig;
}

export default function ConnectionEditor({ initialConfig }: Props) {
  const [config, setConfig] = useState<CmsConfig>(initialConfig);
  const [staged, setStaged] = useState(false);

  const original = useMemo(() => serializeCmsConfig(initialConfig), [initialConfig]);
  const current = serializeCmsConfig(config);
  const dirty = current !== original;
  const errors = validateCmsConfig(config);
  const valid = Object.keys(errors).length === 0;
  // First-run copy keys off the *committed* baseline, not the in-progress edit,
  // so the heading stays stable while the editor is filling the form in.
  const firstRun = isUnconfigured(initialConfig);

  useEffect(() => {
    const sync = () => setStaged(loadChanges().some((c) => c.path === CMS_CONFIG_PATH));
    sync();
    return subscribe(sync);
  }, []);

  const onRepoChange = (name: keyof RepoTarget, value: string) =>
    setConfig((prev) => setRepoField(prev, name, value));
  const onToggle = (name: keyof CmsAuthOptions, on: boolean) =>
    setConfig((prev) => setAuthFlag(prev, name, on));
  const onEndpointChange = (value: string) => setConfig((prev) => setAuthEndpoint(prev, value));

  const onStage = () => stageChange(buildCmsConfigChange(initialConfig, config));
  const onRevert = () => {
    setConfig(initialConfig);
    discardChange(CMS_CONFIG_PATH);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <ConnectionIntro firstRun={firstRun} />
      <ConnectionRepoFields repo={config.repo} errors={errors} onChange={onRepoChange} />
      <ConnectionAuthOptions
        auth={config.auth}
        authEndpoint={config.authEndpoint}
        error={errors.auth}
        onToggle={onToggle}
        onEndpointChange={onEndpointChange}
      />
      <StageFooter dirty={dirty && valid} staged={staged} onStage={onStage} onRevert={onRevert} />
    </div>
  );
}
