// The global staging bar. Mounted once in AdminLayout, so it rides along on
// every admin page. It watches the browser staging set and, whenever there are
// pending changes, shows a floating pill with the count and a "Review & commit".
// Review opens the ReviewDrawer; "Commit all" batches every staged file into ONE
// GitHub commit (via the injected committer), clears the staging set, and then —
// without leaving the drawer — transforms it into a DeployStatus that watches the
// GitHub Pages build the commit kicked off go from queued → building → live.
//
// Both transports (`commit`, `deploy`) are props so isolated-component scenarios
// and unit tests drive the committing / deploying / success / error states
// deterministically without a live repo; in production they default to the real
// GitHub-token-then-(commit|poll) paths.
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  buildCommitMessage,
  changesToWrites,
  changesToDeletes,
  commitAll,
  isStaleBaselineError,
  type CommitOptions,
  type CommitResult,
  type FetchFn,
  type FileWrite,
  type RepoTarget,
} from '../../lib/githubCommit';
import { pollDeploy, readDeployBaseline, type DeployBaseline, type DeployState } from '../../lib/githubPages';
import { ensureGithubToken } from '../../lib/githubAuth';
import { markExpired } from '../../lib/authSession';
import { summarizePending, type PendingChange } from '../../lib/pendingChanges';
import type { DriftedChange } from '../../lib/staleCheck';
import {
  loadChanges,
  discardChange,
  clearChanges,
  reloadChangeBaseline,
  subscribe,
} from '../../lib/pendingChangesStore';
import ReviewDrawer from './ReviewDrawer';
import DeployStatus from './DeployStatus';
import { barStyle, primaryBtn } from './stagingStyles';

export type CommitFn = (
  writes: FileWrite[],
  message: string,
  deletes?: string[],
  options?: CommitOptions,
) => Promise<CommitResult>;
/** Watch the Pages build a commit kicked off, reporting each stage via `onUpdate`. */
export type DeployFn = (commit: CommitResult, onUpdate: (state: DeployState) => void) => Promise<DeployState>;

interface Props {
  repo: RepoTarget;
  authEndpoint: string;
  /** Override the commit transport (scenarios / tests). Defaults to real GitHub. */
  commit?: CommitFn;
  /** Override the deploy-watch transport (scenarios / tests). Defaults to polling Pages. */
  deploy?: DeployFn;
  /** Seed the staging set for isolated-component scenarios / tests. In the real
   * app this is omitted and the set loads from the browser store. */
  initialChanges?: PendingChange[];
  /** Open directly into a given phase (e.g. `reviewing`) for scenario capture. */
  initialPhase?: Phase;
  /** Seed the drift warning for isolated-component scenarios / tests, without
   * needing a live co-editor to race against. */
  initialDrifted?: DriftedChange[];
}

type Phase = 'idle' | 'reviewing' | 'committing' | 'error' | 'deploying';

export default function StagingBar({
  repo,
  authEndpoint,
  commit,
  deploy,
  initialChanges,
  initialPhase = 'idle',
  initialDrifted,
}: Props) {
  const [changes, setChanges] = useState<PendingChange[]>(initialChanges ?? []);
  const [phase, setPhase] = useState<Phase>(initialPhase);
  const [result, setResult] = useState<CommitResult | null>(null);
  const [error, setError] = useState<string>('');
  const [drifted, setDrifted] = useState<DriftedChange[]>(initialDrifted ?? []);
  const [deployState, setDeployState] = useState<DeployState>({ stage: 'committed' });
  const [deployNonce, setDeployNonce] = useState(0);
  // The site's deploy marker as it read BEFORE this commit. A ref, not state,
  // because the deploy effect only ever reads the value that was sampled during
  // the commit it is watching — re-rendering on it would be noise.
  const deployBaseline = useRef<DeployBaseline | null>(null);

  useEffect(() => {
    // When seeded for a scenario, stay on the injected set; otherwise track the
    // browser store.
    if (initialChanges) return;
    const sync = () => setChanges(loadChanges());
    sync();
    return subscribe(sync);
  }, [initialChanges]);

  const committer: CommitFn = useMemo(() => {
    if (commit) return commit;
    return async (writes, message, deletes = [], options) => {
      const token = await ensureGithubToken(authEndpoint);
      try {
        return await commitAll(writes, message, repo, token, globalThis.fetch as unknown as FetchFn, deletes, options);
      } catch (e) {
        // A drift refusal is the check working, not a bad token — leave the
        // session alone so the editor can resolve and retry in place.
        if (isStaleBaselineError(e)) throw e;
        // A stale/insufficient token shouldn't be reused: expire the session so
        // the sign-in gate re-shows. Staged edits survive (localStorage), so the
        // editor re-authenticates and commits without losing this work.
        markExpired();
        throw e;
      }
    };
  }, [commit, authEndpoint, repo]);

  const deployer: DeployFn = useMemo(() => {
    if (deploy) return deploy;
    return async (_commit, onUpdate) => {
      const token = await ensureGithubToken(authEndpoint);
      return pollDeploy(repo, token, globalThis.fetch as unknown as FetchFn, onUpdate, {
        ...(deployBaseline.current ?? {}),
      });
    };
  }, [deploy, authEndpoint, repo]);

  // Drive the deploy watch whenever we (re-)enter the deploying phase. Failures
  // here don't lose work — the commit already landed — so a poll error just
  // surfaces as a failed build the editor can retry.
  useEffect(() => {
    if (phase !== 'deploying' || !result) return;
    let live = true;
    setDeployState({ stage: 'committed' });
    deployer(result, (state) => {
      if (live) setDeployState(state);
    }).catch(() => {
      if (live) setDeployState({ stage: 'failed', error: 'Could not reach GitHub Pages to check the build.' });
    });
    return () => {
      live = false;
    };
  }, [phase, result, deployNonce, deployer]);

  const summary = summarizePending(changes);

  // `overwriteDrift` is the deliberate override behind "Publish anyway" — the
  // ordinary path always passes the staged changes so `commitAll` checks them.
  const onCommit = async (overwriteDrift = false) => {
    setPhase('committing');
    setError('');
    // Sample what the site serves now, BEFORE the commit — afterwards there is
    // no "before" left to compare against. A failed read is not an error: it
    // just means this deploy reports live without the propagation check.
    deployBaseline.current = await readDeployBaseline(repo, globalThis.fetch as unknown as FetchFn);
    try {
      const res = await committer(changesToWrites(changes), buildCommitMessage(changes), changesToDeletes(changes), {
        changes,
        overwriteDrift,
      });
      clearChanges();
      setDrifted([]);
      setResult(res);
      setPhase('deploying');
    } catch (e) {
      if (isStaleBaselineError(e)) {
        setDrifted(e.drifted);
        setError('');
        setPhase('reviewing');
        return;
      }
      setDrifted([]);
      setError(e instanceof Error ? e.message : String(e));
      setPhase('error');
    }
  };

  // Resolving an entry clears it from the warning: whatever is left is what
  // still needs attention, and an empty list means the commit can be retried.
  const resolveDrift = (path: string) => setDrifted((d) => d.filter((x) => x.path !== path));

  const onDiscardDrift = (path: string) => {
    discardChange(path);
    resolveDrift(path);
  };

  const onReloadDrift = (drift: DriftedChange) => {
    reloadChangeBaseline(drift);
    resolveDrift(drift.path);
  };

  // Nothing to show: no pending changes and not mid-deploy.
  if (changes.length === 0 && phase !== 'deploying') return null;

  return (
    <>
      {changes.length > 0 && (
        <div style={barStyle}>
          <span style={{ fontWeight: 600 }}>
            {summary.count} pending {summary.count === 1 ? 'change' : 'changes'}
          </span>
          {summary.collections.length > 0 && (
            <span style={{ opacity: 0.85, fontSize: '0.85rem' }}>across {summary.collections.join(', ')}</span>
          )}
          <button type="button" onClick={() => setPhase('reviewing')} style={primaryBtn}>
            Review &amp; commit
          </button>
        </div>
      )}

      {(phase === 'reviewing' || phase === 'committing' || phase === 'error') && (
        <ReviewDrawer
          repo={repo}
          changes={changes}
          phase={phase}
          error={error}
          drifted={drifted}
          onClose={() => setPhase('idle')}
          onDiscard={discardChange}
          onCommit={() => onCommit()}
          onDiscardDrift={onDiscardDrift}
          onReloadDrift={onReloadDrift}
          onOverwriteDrift={() => onCommit(true)}
        />
      )}

      {phase === 'deploying' && result && (
        <DeployStatus
          repo={repo}
          commitUrl={result.commitUrl}
          state={deployState}
          onRetry={() => setDeployNonce((n) => n + 1)}
          onClose={() => setPhase('idle')}
        />
      )}
    </>
  );
}
