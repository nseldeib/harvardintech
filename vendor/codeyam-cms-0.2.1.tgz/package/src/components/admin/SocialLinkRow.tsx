// One editable social-link row: a grip handle, the label + URL inputs, and the
// up/down/remove controls. Presentational — the parent SocialLinksEditor owns the
// list and forwards patch/move/remove intents keyed by this row's index, plus the
// drag props from `useListDrag` so the row can be reordered by drag or by button.
import type { HTMLAttributes } from 'react';
import type { SocialLink } from '../../lib/siteConfig';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';
import { rowCardStyle, dragRowStyle } from './configEditorStyles';
import RowControls from './RowControls';
import DragHandle from './DragHandle';

interface Props {
  social: SocialLink;
  index: number;
  /** True on the first / last row so the move buttons disable at the ends. */
  isFirst: boolean;
  isLast: boolean;
  onChange: (patch: Partial<SocialLink>) => void;
  onMove: (delta: number) => void;
  onRemove: () => void;
  /** Drag-reorder wiring from `useListDrag` (absent = no drag, buttons only). */
  rowDragProps?: HTMLAttributes<HTMLElement>;
  handleProps?: HTMLAttributes<HTMLSpanElement>;
  isDragging?: boolean;
  isDropTarget?: boolean;
}

export default function SocialLinkRow({
  social,
  index,
  isFirst,
  isLast,
  onChange,
  onMove,
  onRemove,
  rowDragProps,
  handleProps,
  isDragging = false,
  isDropTarget = false,
}: Props) {
  return (
    <div style={{ ...rowCardStyle, ...dragRowStyle(isDragging, isDropTarget) }} {...rowDragProps}>
      <div style={{ display: 'flex', gap: 'var(--space-sm)', alignItems: 'flex-end', flexWrap: 'wrap' }}>
        {handleProps && <DragHandle label="Drag to reorder social link" {...handleProps} />}
        <div style={{ flex: '1 1 8rem' }}>
          <label style={fieldLabelStyle} htmlFor={`social-label-${index}`}>
            Label
          </label>
          <input
            id={`social-label-${index}`}
            type="text"
            value={social.label}
            placeholder="LinkedIn"
            onChange={(e) => onChange({ label: e.target.value })}
            style={fieldInputStyle}
          />
        </div>
        <div style={{ flex: '2 1 14rem' }}>
          <label style={fieldLabelStyle} htmlFor={`social-url-${index}`}>
            URL
          </label>
          <input
            id={`social-url-${index}`}
            type="text"
            value={social.url}
            placeholder="https://linkedin.com/company/…"
            onChange={(e) => onChange({ url: e.target.value })}
            style={fieldInputStyle}
          />
        </div>
        <RowControls
          canUp={!isFirst}
          canDown={!isLast}
          onUp={() => onMove(-1)}
          onDown={() => onMove(1)}
          onRemove={onRemove}
          removeLabel="Remove social link"
        />
      </div>
    </div>
  );
}
