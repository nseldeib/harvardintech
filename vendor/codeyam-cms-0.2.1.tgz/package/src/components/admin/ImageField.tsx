// An image-typed entry field (cover image / team photo). Presentational: shows a
// thumbnail of the current image when one is set, plus buttons to open the media
// picker (Choose / Change) or clear the field. It owns no picker state — the
// parent EntryEditor hosts the shared MediaPickerModal and passes the chosen
// url back down as `value`.
import type { CSSProperties } from 'react';
import type { FieldDef } from '../../lib/entryEditor';
import { fieldLabelStyle } from './EntryField';
import FieldError from './FieldError';
import { withBase } from '../../lib/adminUrl';

interface Props {
  field: FieldDef;
  value: string;
  onPick: () => void;
  onClear: () => void;
  /** Why this field is blocking — same treatment as a text field's error. */
  error?: string;
}

const btnStyle: CSSProperties = {
  padding: '0.35rem 0.75rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  cursor: 'pointer',
  fontSize: '0.85rem',
};

export default function ImageField({ field, value, onPick, onClear, error }: Props) {
  const hasValue = value.trim() !== '';
  return (
    <div>
      <label style={fieldLabelStyle}>
        {field.label}
        {field.optional && <span style={{ fontWeight: 400 }}> · optional</span>}
      </label>

      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-md)' }}>
        <div
          style={{
            width: '96px',
            height: '72px',
            flexShrink: 0,
            borderRadius: 'var(--radius)',
            border: '1px solid var(--color-border)',
            background: 'var(--color-surface, #f1f1f6)',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--color-muted)',
            fontSize: '1.4rem',
          }}
        >
          {hasValue ? (
            <img src={withBase(value)} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            <span aria-hidden>🖼️</span>
          )}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', alignItems: 'flex-start' }}>
          <button type="button" onClick={onPick} style={btnStyle}>
            {hasValue ? 'Change image' : 'Choose image'}
          </button>
          {hasValue && (
            <>
              <span style={{ fontSize: '0.75rem', color: 'var(--color-muted)', wordBreak: 'break-all' }}>{value}</span>
              <button
                type="button"
                onClick={onClear}
                style={{ ...btnStyle, border: 'none', background: 'transparent', color: 'var(--color-muted)', padding: '0.1rem 0' }}
              >
                Remove
              </button>
            </>
          )}
        </div>
      </div>

      <FieldError error={error} />
    </div>
  );
}
