// One area's staged changes on the Publish page: a header row that reads the
// group at a glance — the area label, a per-verb summary ("2 edited, 1 new"),
// and the count — which expands to reveal each change as a ChangeDiffCard (the
// same line-level diff the review drawer shows). Friendly summary first, raw
// detail on demand. Self-contained expand state; the parent PublishPage owns the
// staging set and the discard handler.
import { useState } from 'react';
import type { ChangeGroup as ChangeGroupData, ChangeVerb } from '../../lib/pendingChanges';
import ChangeDiffCard from './ChangeDiffCard';

interface Props {
  group: ChangeGroupData;
  /** Disable the per-entry discard while a commit is in flight. */
  disabled: boolean;
  onDiscard: (path: string) => void;
  /** Whether the group starts expanded (a single-group list opens by default). */
  defaultExpanded?: boolean;
}

/** Pill colors per verb, echoing the diff/badge palette used across staging. */
const VERB_PILL: Record<ChangeVerb, { fg: string; bg: string }> = {
  new: { fg: '#166534', bg: '#dcfce7' },
  edited: { fg: '#1e40af', bg: '#dbeafe' },
  published: { fg: '#166534', bg: '#dcfce7' },
  archived: { fg: '#92400e', bg: '#fde68a' },
  deleted: { fg: '#991b1b', bg: '#fee2e2' },
};

export default function ChangeGroup({ group, disabled, onDiscard, defaultExpanded = false }: Props) {
  const [expanded, setExpanded] = useState(defaultExpanded);

  return (
    <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
      <button
        type="button"
        onClick={() => setExpanded((e) => !e)}
        aria-expanded={expanded}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--space-md)',
          padding: 'var(--space-md)',
          background: 'var(--color-surface, #f7f7fb)',
          border: 'none',
          cursor: 'pointer',
          textAlign: 'left',
          font: 'inherit',
          color: 'var(--color-fg)',
        }}
      >
        <span
          aria-hidden="true"
          style={{
            transition: 'transform 0.15s',
            transform: expanded ? 'rotate(90deg)' : 'none',
            color: 'var(--color-muted)',
            flex: '0 0 auto',
          }}
        >
          ▶
        </span>
        <span style={{ fontWeight: 700 }}>{group.label}</span>
        <span style={{ display: 'inline-flex', gap: '0.35rem', flexWrap: 'wrap' }}>
          {group.breakdown.map(({ verb, n }) => {
            const pill = VERB_PILL[verb];
            return (
              <span
                key={verb}
                style={{
                  background: pill.bg,
                  color: pill.fg,
                  borderRadius: '999px',
                  padding: '0.05rem 0.5rem',
                  fontSize: '0.7rem',
                  fontWeight: 700,
                }}
              >
                {n} {verb}
              </span>
            );
          })}
        </span>
        <span style={{ marginLeft: 'auto', color: 'var(--color-muted)', fontSize: '0.8rem' }}>
          {group.count} {group.count === 1 ? 'change' : 'changes'}
        </span>
      </button>

      {expanded && (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 'var(--space-md)',
            padding: 'var(--space-md)',
          }}
        >
          {group.changes.map((change) => (
            <ChangeDiffCard key={change.path} change={change} disabled={disabled} onDiscard={onDiscard} />
          ))}
        </div>
      )}
    </div>
  );
}
