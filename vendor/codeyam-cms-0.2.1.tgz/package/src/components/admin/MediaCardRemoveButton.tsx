// The "Remove" action on a staged-but-uncommitted upload's card.
//
// Only staged uploads carry it: an image that is merely IN the library — either
// committed to the manifest or adopted from `public/images` — is not something
// the gallery can drop, because removing it would mean deleting a file from the
// repo rather than unstaging a pending change.
interface Props {
  onClick: () => void;
}

export default function MediaCardRemoveButton({ onClick }: Props) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        marginTop: '0.35rem',
        alignSelf: 'flex-start',
        background: 'transparent',
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius)',
        padding: '0.2rem 0.5rem',
        fontSize: '0.72rem',
        color: 'var(--color-muted)',
        cursor: 'pointer',
      }}
    >
      Remove
    </button>
  );
}
