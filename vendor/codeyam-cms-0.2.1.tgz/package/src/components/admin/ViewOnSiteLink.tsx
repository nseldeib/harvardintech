// The "View on site" affordance shown in the entry editor's action row.
//
// It jumps to the entry's REAL published page on the deployed static site (a new
// tab) — distinct from the in-editor live preview, which shows the current,
// unsaved edits. All the branching (enabled vs the two disabled reasons) is pure
// logic in `../../lib/publicUrl`; this component only renders the resulting state,
// so it drops cleanly into both `EntryEditor` (published) and `NewEntryEditor`
// (unpublished) and is captured in isolation across all three states.
import { viewOnSiteState } from '../../lib/publicUrl';

interface Props {
  /** Whether a committed/published page exists for this entry. */
  published: boolean;
  /** The configured public base URL (`settings.siteUrl`); may be blank. */
  siteUrl: string;
  collection: string;
  slug: string;
}

const wrap: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 'var(--space-sm)',
};

const linkBase: React.CSSProperties = {
  padding: '0.5rem 1.1rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  fontWeight: 600,
  fontSize: '0.9rem',
  textDecoration: 'none',
  whiteSpace: 'nowrap',
};

export default function ViewOnSiteLink({ published, siteUrl, collection, slug }: Props) {
  const state = viewOnSiteState({ published, siteUrl, collection, slug });

  if (state.kind === 'enabled') {
    return (
      <span style={wrap}>
        <a
          href={state.href}
          target="_blank"
          rel="noopener noreferrer"
          style={{ ...linkBase, background: 'transparent', color: 'var(--color-fg)', cursor: 'pointer' }}
        >
          View on site ↗
        </a>
      </span>
    );
  }

  // Disabled: a greyed, non-interactive chip plus the reason as a hint.
  return (
    <span style={wrap}>
      <span
        aria-disabled="true"
        style={{
          ...linkBase,
          background: 'var(--color-border)',
          color: 'var(--color-muted)',
          cursor: 'not-allowed',
        }}
      >
        View on site ↗
      </span>
      <span style={{ fontSize: '0.85rem', color: 'var(--color-muted)' }}>{state.hint}</span>
    </span>
  );
}
