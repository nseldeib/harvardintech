// The site-settings editor island: the state-owning root for the "Site details"
// and "Social links" sections. It composes the presentational SiteDetailsFields
// + SocialLinksEditor + StageFooter and owns the settings state. "Stage change"
// does NOT write settings.json — it serializes the edited settings to canonical
// JSON and adds a PendingChange to the browser staging set; the global StagingBar
// picks it up and the real commit happens later, batched with any other pending
// changes. The dirty/diff baseline is the settings NORMALIZED through the
// serializer, so re-ordering keys never reads as a spurious edit and reverting
// cleanly unstages.
import { useEffect, useMemo, useState } from 'react';
import type { SiteSettings, SocialLink } from '../../lib/siteConfig';
import { SETTINGS_PATH, serializeSettings } from '../../lib/siteConfig';
import { buildSettingsChange, type SettingsFieldDef } from '../../lib/settingsEditor';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import SiteDetailsFields from './SiteDetailsFields';
import SocialLinksEditor from './SocialLinksEditor';
import StageFooter from './StageFooter';

interface Props {
  initialSettings: SiteSettings;
}

export default function SettingsEditor({ initialSettings }: Props) {
  const [settings, setSettings] = useState<SiteSettings>(initialSettings);
  const [staged, setStaged] = useState(false);

  const original = useMemo(() => serializeSettings(initialSettings), [initialSettings]);
  const current = serializeSettings(settings);
  const dirty = current !== original;

  useEffect(() => {
    const sync = () => setStaged(loadChanges().some((c) => c.path === SETTINGS_PATH));
    sync();
    return subscribe(sync);
  }, []);

  const setScalar = (name: SettingsFieldDef['name'], value: string) =>
    setSettings((prev) => ({ ...prev, [name]: value }));
  const setSocials = (socials: SocialLink[]) => setSettings((prev) => ({ ...prev, socials }));

  const onStage = () => stageChange(buildSettingsChange(initialSettings, settings));
  const onRevert = () => {
    setSettings(initialSettings);
    discardChange(SETTINGS_PATH);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <SiteDetailsFields settings={settings} onChange={setScalar} />
      <SocialLinksEditor socials={settings.socials ?? []} onChange={setSocials} />
      <StageFooter dirty={dirty} staged={staged} onStage={onStage} onRevert={onRevert} />
    </div>
  );
}
