// A round status dot for one Publish-checklist check: a green ✓ when the check
// passed, an amber ! when it has findings. Mirrors the deploy-stepper dot
// vocabulary so the two status surfaces read as one system. Purely presentational.

const OK_FG = '#166534';
const OK_BG = '#dcfce7';
const WARN_FG = '#92400e';
const WARN_BG = '#fef3c7';

interface Props {
  /** True → the passing (green ✓) dot; false → the attention (amber !) dot. */
  ok: boolean;
}

export default function ChecklistStatusDot({ ok }: Props) {
  return (
    <span
      aria-hidden="true"
      style={{
        flex: '0 0 auto',
        width: '1.5rem',
        height: '1.5rem',
        borderRadius: '999px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '0.85rem',
        fontWeight: 700,
        lineHeight: 1,
        background: ok ? OK_BG : WARN_BG,
        color: ok ? OK_FG : WARN_FG,
      }}
    >
      {ok ? '✓' : '!'}
    </span>
  );
}
