// The Editor / Preview toggle for the entry editors' split layout. Shown only on
// narrow screens (the `.cy-split-tabs` container is hidden on wide via
// `entryPreviewStyles`), it flips which pane is visible. Presentational — the
// parent owns the `view` state. Shared by EntryEditor and NewEntryEditor so the
// toggle stays identical.
import { splitTabBtn } from './entryPreviewStyles';

interface Props {
  view: 'edit' | 'preview';
  onChange: (view: 'edit' | 'preview') => void;
}

export default function SplitTabs({ view, onChange }: Props) {
  return (
    <div className="cy-split-tabs">
      <button type="button" onClick={() => onChange('edit')} style={splitTabBtn(view === 'edit')}>
        Editor
      </button>
      <button type="button" onClick={() => onChange('preview')} style={splitTabBtn(view === 'preview')}>
        Preview
      </button>
    </div>
  );
}
