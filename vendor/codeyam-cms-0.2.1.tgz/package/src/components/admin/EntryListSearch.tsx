// The interactive entry list for one collection: a filter box over the
// collection's entries, rendered above the same Drafts-first / Published
// grouping the page used to render server-side. Typing filters the rows live via
// the shared `searchEntries` matcher (title + body); an empty box shows every
// entry. This island replaces the page's static sections so the whole list —
// filtering, grouping, and the row islands — lives under one hydration root.
import { useState } from 'react';
import SearchBox from './SearchBox';
import SearchEmpty from './SearchEmpty';
import EntryListSection from './EntryListSection';
import EntryListEmpty from './EntryListEmpty';
import { groupByDraft } from '../../lib/entryList';
import { searchEntries, type SearchableEntry } from '../../lib/entrySearch';
import type { CollectionName } from '../../lib/adminDashboard';

/** A collection entry as this island renders it: the search index plus the raw
 * markdown each EntryRow needs to stage an archive / delete change. */
export type EntryListSearchItem = SearchableEntry & { raw: string };

interface Props {
  collection: CollectionName;
  /** The collection's human label, for the empty-collection nudge. */
  label: string;
  items: EntryListSearchItem[];
  /** Pre-fills the search box — used by the isolation scenarios to capture a
   * filtered / no-results state deterministically. */
  initialQuery?: string;
  /** The collection's resolved frontmatter key order, forwarded to each row's
   * archive / delete change so consumer-declared fields keep their position. */
  keyOrder?: string[];
}

export default function EntryListSearch({ collection, label, items, initialQuery = '', keyOrder }: Props) {
  const [query, setQuery] = useState(initialQuery);
  const matches = searchEntries(items, query);
  const { drafts, published } = groupByDraft(matches);

  return (
    <div>
      <SearchBox
        value={query}
        onChange={setQuery}
        placeholder={`Search ${label.toLowerCase()}…`}
        ariaLabel={`Search ${label}`}
      />

      {items.length === 0 && <EntryListEmpty label={label} />}

      {items.length > 0 && matches.length === 0 && (
        <SearchEmpty query={query.trim()} onClear={() => setQuery('')} />
      )}

      {drafts.length > 0 && (
        <EntryListSection heading="Drafts" collection={collection} entries={drafts} keyOrder={keyOrder} />
      )}
      {published.length > 0 && (
        <EntryListSection heading="Published" collection={collection} entries={published} keyOrder={keyOrder} />
      )}
    </div>
  );
}
