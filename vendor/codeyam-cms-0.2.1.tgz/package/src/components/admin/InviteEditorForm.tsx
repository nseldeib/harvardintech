// The "invite an editor" form on /admin/editors: an email field + "Send invite"
// button, with the inline guardrail error (blank / malformed / already on the
// team). Presentational — the parent EditorsManager owns the roster and decides
// whether an email is invitable (via `inviteError`) and what happens on submit.
import { useState } from 'react';
import { inviteBtn, inviteError as inviteErrorStyle, inviteForm, inviteHint, inviteInput } from './editorsStyles';

interface Props {
  /** Return an error string to reject the email, or null to accept + invite it. */
  validate: (email: string) => string | null;
  /** Called with the accepted email; the parent adds the invite + stages it. */
  onInvite: (email: string) => void;
}

export default function InviteEditorForm({ validate, onInvite }: Props) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate(email);
    if (err) {
      setError(err);
      return;
    }
    onInvite(email.trim());
    setEmail('');
    setError('');
  };

  return (
    <form style={inviteForm} onSubmit={submit} noValidate>
      <input
        type="email"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value);
          if (error) setError('');
        }}
        placeholder="teammate@example.com"
        aria-label="Editor email address"
        style={inviteInput}
      />
      <button type="submit" style={inviteBtn}>
        Send invite
      </button>
      {error ? (
        <p style={inviteErrorStyle}>{error}</p>
      ) : (
        <p style={inviteHint}>
          They’ll get an email with a secure sign-in link — no GitHub account needed.
        </p>
      )}
    </form>
  );
}
