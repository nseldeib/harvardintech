// A labeled group of entry rows — the "Drafts (2)" / "Published (3)" sections of
// a collection's list. Renders its heading with the group count and maps each
// entry to an interactive EntryRow (link into the editor + archive / delete
// actions). The React counterpart of the old server-rendered section, so it can
// live inside the client-side search island that filters the list.
import type { CSSProperties } from 'react';
import EntryRow from './EntryRow';
import type { CollectionName } from '../../lib/adminDashboard';
import type { EntryListSearchItem } from './EntryListSearch';
import { withBase } from '../../lib/adminUrl';

const headingStyle: CSSProperties = {
  fontSize: '0.78rem',
  textTransform: 'uppercase',
  letterSpacing: '0.06em',
  color: 'var(--color-muted)',
  margin: '0 0 var(--space-sm)',
};

const listStyle: CSSProperties = {
  listStyle: 'none',
  margin: 0,
  padding: 0,
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-sm)',
};

interface Props {
  heading: string;
  collection: CollectionName;
  entries: EntryListSearchItem[];
  /** The collection's resolved frontmatter key order, forwarded to each row so a
   * staged archive / delete keeps consumer-declared fields in place. */
  keyOrder?: string[];
}

export default function EntryListSection({ heading, collection, entries, keyOrder }: Props) {
  return (
    <section style={{ marginBottom: 'var(--space-lg)' }}>
      <h2 style={headingStyle}>
        {heading} ({entries.length})
      </h2>
      <ul style={listStyle}>
        {entries.map((entry) => (
          <li key={entry.slug}>
            <EntryRow
              collection={collection}
              slug={entry.slug}
              href={withBase(`/admin/${collection}/${entry.slug}`)}
              label={entry.label}
              draft={entry.draft}
              raw={entry.raw}
              keyOrder={keyOrder}
            />
          </li>
        ))}
      </ul>
    </section>
  );
}
