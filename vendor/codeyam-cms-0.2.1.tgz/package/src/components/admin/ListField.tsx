// A repeatable-group entry field: a `list` field renders as add/remove/reorder
// rows, each row a small form of its declared scalar sub-fields. It is the
// EntryEditor counterpart to the site-config list editors (NavEditor /
// SocialLinksEditor) and reuses their exact vocabulary — `useListDrag` for the
// grip-drag, `moveInArray`/`reorderInArray` for the reorder math, and
// RowControls/DragHandle for the per-row controls. Presentational: it owns no
// state; the parent EntryEditor holds the rows array in `values[field.name]` and
// receives every mutation through `onChange`, so staging/dirty-detection flows
// through the existing `toMarkdown` path unchanged.
import {
  emptyRowValues,
  type FieldDef,
  type RawRowValue,
  type RawScalarValue,
} from '../../lib/entryEditor';
import { moveInArray, reorderInArray } from '../../lib/siteConfig';
import { useListDrag } from '../../lib/useListDrag';
import { fieldLabelStyle } from './EntryField';
import EntryField from './EntryField';
import ImageField from './ImageField';
import RowControls from './RowControls';
import DragHandle from './DragHandle';
import { rowCardStyle, dragRowStyle, addBtnStyle } from './configEditorStyles';

interface Props {
  /** The list field — its `label`, `hint`, and `fields` sub-schema. */
  field: FieldDef;
  /** The current rows (`values[field.name]`), one map of scalar values per row. */
  rows: RawRowValue[];
  /** Emit the next rows array — the parent stores it and re-serializes. */
  onChange: (rows: RawRowValue[]) => void;
  /** Open the shared media picker for an image sub-field in row `row`, key `sub`. */
  onPickImage: (row: number, sub: string) => void;
  /** Blank-required-sub-field messages for this list, keyed `[rowIndex][sub]`
   * (`RequiredFieldStatus.rowErrors[field.name]`), so a bad row shows the problem
   * in place instead of only at the footer. */
  errors?: Record<number, Record<string, string>>;
}

/** A rough singular of a list's label for the add button, preserving case
 * ("Leads" → "Lead"). Exported for unit testing. */
export function singularize(label: string): string {
  const l = label.trim();
  return l.toLowerCase().endsWith('s') && l.length > 1 ? l.slice(0, -1) : l;
}

export default function ListField({ field, rows, onChange, onPickImage, errors }: Props) {
  const subFields = field.fields ?? [];
  const drag = useListDrag((from, to) => onChange(reorderInArray(rows, from, to)));

  const patchRow = (index: number, sub: string, value: RawScalarValue) =>
    onChange(rows.map((r, i) => (i === index ? { ...r, [sub]: value } : r)));

  const addRow = () => onChange([...rows, emptyRowValues(subFields)]);
  const removeRow = (index: number) => onChange(rows.filter((_, i) => i !== index));
  const moveRow = (index: number, delta: number) => onChange(moveInArray(rows, index, delta));

  const addLabel = `+ Add ${singularize(field.label) || 'item'}`;

  return (
    <div>
      <label style={fieldLabelStyle}>
        {field.label}
        {field.optional && <span style={{ fontWeight: 400 }}> · optional</span>}
      </label>
      {field.hint && (
        <p style={{ margin: '0 0 var(--space-sm)', fontSize: '0.78rem', color: 'var(--color-muted)' }}>
          {field.hint}
        </p>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
        {rows.length === 0 && (
          <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--color-muted)' }}>
            No {field.label.toLowerCase()} yet.
          </p>
        )}

        {rows.map((row, i) => (
          <div
            key={i}
            style={{ ...rowCardStyle, ...dragRowStyle(drag.dragIndex === i, drag.overIndex === i && drag.dragIndex !== i) }}
            {...drag.rowProps(i)}
          >
            <div style={{ display: 'flex', gap: 'var(--space-sm)', alignItems: 'flex-start' }}>
              <DragHandle label={`Drag to reorder ${singularize(field.label)}`} {...drag.handleProps(i)} />
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
                {subFields.map((sub) =>
                  sub.type === 'image' ? (
                    <ImageField
                      key={sub.name}
                      field={sub}
                      value={String(row[sub.name] ?? '')}
                      onPick={() => onPickImage(i, sub.name)}
                      onClear={() => patchRow(i, sub.name, '')}
                      error={errors?.[i]?.[sub.name]}
                    />
                  ) : (
                    <EntryField
                      key={sub.name}
                      field={sub}
                      value={row[sub.name] ?? (sub.type === 'boolean' ? false : '')}
                      onChange={(v) => patchRow(i, sub.name, v as RawScalarValue)}
                      error={errors?.[i]?.[sub.name]}
                    />
                  ),
                )}
              </div>
              <RowControls
                canUp={i > 0}
                canDown={i < rows.length - 1}
                onUp={() => moveRow(i, -1)}
                onDown={() => moveRow(i, 1)}
                onRemove={() => removeRow(i)}
                removeLabel={`Remove ${singularize(field.label)}`}
              />
            </div>
          </div>
        ))}

        <button type="button" onClick={addRow} style={addBtnStyle}>
          {addLabel}
        </button>
      </div>
    </div>
  );
}
