// Shared inline styles for the "Repository connection" editor's presentational
// sections (ConnectionRepoFields, ConnectionAuthOptions). Kept beside the
// components — the same co-location convention as authStyles / stagingStyles /
// configEditorStyles — so both sections render an identical error + toggle
// vocabulary.
import type { CSSProperties } from 'react';

/** A validation error line shown under a field or the sign-in options. */
export const errorTextStyle: CSSProperties = {
  margin: '0.35rem 0 0',
  fontSize: '0.82rem',
  color: '#991b1b',
};

/** One checkbox-plus-label row in the sign-in options list. */
export const toggleRowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'flex-start',
  gap: 'var(--space-sm)',
};
