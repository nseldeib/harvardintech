// The confirmation dialog shown when the editor tries to leave an entry that has
// unstaged edits. A thin presentational island: it renders the overlay + panel
// and three actions and calls back — the EntryEditor owns the decision of when to
// show it and what each action does (stay put, discard and go, or stage first).
// Reuses the staging system's overlay so it reads as part of the same admin
// chrome. Rendered directly in an isolation page for capture.
import { overlayStyle, accentBtn, ghostBtnDark } from './stagingStyles';
import { UNSAVED_TITLE, UNSAVED_MESSAGE } from '../../lib/unsavedGuard';

interface Props {
  /** Cancel — dismiss the dialog and keep editing. */
  onStay?: () => void;
  /** Discard the unstaged edits and navigate away anyway. */
  onLeave?: () => void;
  /** Stage the change (so nothing is lost), then navigate away. */
  onStageAndLeave?: () => void;
}

const panelStyle: React.CSSProperties = {
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-lg)',
  width: 'min(460px, 94vw)',
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-md)',
  boxShadow: '0 12px 40px rgba(0,0,0,0.25)',
  // The shared overlay bottom-aligns its child (it hosts the review drawer);
  // center this smaller dialog instead so it reads as a modal, not a sheet.
  margin: 'auto',
};

export default function UnsavedChangesDialog({
  onStay = () => {},
  onLeave = () => {},
  onStageAndLeave = () => {},
}: Props) {
  return (
    <div style={{ ...overlayStyle, alignItems: 'center' }} onClick={onStay} role="presentation">
      <div
        style={panelStyle}
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="cy-unsaved-title"
      >
        <h2 id="cy-unsaved-title" style={{ margin: 0, fontSize: '1.1rem' }}>
          {UNSAVED_TITLE}
        </h2>
        <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--color-muted)', lineHeight: 1.5 }}>
          {UNSAVED_MESSAGE}
        </p>
        <div
          style={{
            display: 'flex',
            gap: 'var(--space-md)',
            justifyContent: 'flex-end',
            flexWrap: 'wrap',
            marginTop: 'var(--space-sm)',
          }}
        >
          <button type="button" onClick={onStay} style={ghostBtnDark}>
            Stay
          </button>
          <button
            type="button"
            onClick={onLeave}
            style={{ ...ghostBtnDark, color: '#991b1b', borderColor: '#f0c2c2' }}
          >
            Leave anyway
          </button>
          <button type="button" onClick={onStageAndLeave} style={accentBtn}>
            Stage &amp; leave
          </button>
        </div>
      </div>
    </div>
  );
}
