// The identity block of the collection builder: the collection's name, its
// derived id (folder + url segment), and an optional singular noun. Presentational
// — the parent CollectionBuilder owns the draft state and validation; this renders
// the inputs and forwards edits. Mirrors SiteDetailsFields in the settings editor.
import type { CollectionDraft } from '../../lib/collectionRegistry';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';

interface Props {
  draft: CollectionDraft;
  /** The strict id the collection will be created under (for the folder hint). */
  finalId: string;
  /** An id validation message, or undefined when the id is valid. */
  idError?: string;
  /** Patch the draft's scalar identity fields (label / singular). */
  onPatch: (patch: Partial<CollectionDraft>) => void;
  /** The editor typed in the id field directly (stops it auto-following the name). */
  onIdEdit: (value: string) => void;
}

export default function CollectionMetaFields({ draft, finalId, idError, onPatch, onIdEdit }: Props) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      <div>
        <label style={fieldLabelStyle} htmlFor="c-label">
          Collection name
        </label>
        <input
          id="c-label"
          value={draft.label}
          placeholder="e.g. Sponsors"
          onChange={(e) => onPatch({ label: e.target.value })}
          style={fieldInputStyle}
        />
      </div>

      <div style={{ display: 'flex', gap: 'var(--space-md)', flexWrap: 'wrap' }}>
        <div style={{ flex: '1 1 200px' }}>
          <label style={fieldLabelStyle} htmlFor="c-id">
            Id <span style={{ fontWeight: 400 }}>· folder &amp; url</span>
          </label>
          <input
            id="c-id"
            value={draft.id}
            onChange={(e) => onIdEdit(e.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, '-'))}
            style={{
              ...fieldInputStyle,
              fontFamily: 'var(--font-mono)',
              borderColor: idError ? 'var(--color-danger, #c0392b)' : 'var(--color-border)',
            }}
          />
          <p style={{ margin: '0.35rem 0 0', fontSize: '0.8rem', color: 'var(--color-muted)' }}>
            {finalId ? `Entries live in src/content/${finalId}/` : 'Derived from the name.'}
          </p>
        </div>
        <div style={{ flex: '1 1 200px' }}>
          <label style={fieldLabelStyle} htmlFor="c-singular">
            Singular <span style={{ fontWeight: 400 }}>· optional</span>
          </label>
          <input
            id="c-singular"
            value={draft.singular}
            placeholder="e.g. sponsor"
            onChange={(e) => onPatch({ singular: e.target.value })}
            style={fieldInputStyle}
          />
          <p style={{ margin: '0.35rem 0 0', fontSize: '0.8rem', color: 'var(--color-muted)' }}>
            Used by the create button, e.g. “New sponsor”.
          </p>
        </div>
      </div>
    </div>
  );
}
