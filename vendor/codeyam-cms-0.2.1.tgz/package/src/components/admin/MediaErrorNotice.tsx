// The red notice shown when an upload fails, in both the standalone gallery and
// the in-editor picker.
//
// Both surfaces host the same MediaUploader and can fail the same ways (an
// unreadable file, a compression error), so they showed the same banner with the
// same inline style object duplicated verbatim. One component keeps the two
// reading as one system.
interface Props {
  /** The failure message; nothing renders when it's empty. */
  message: string;
}

export default function MediaErrorNotice({ message }: Props) {
  if (!message) return null;
  return (
    <p
      style={{
        color: '#991b1b',
        background: '#fee2e2',
        padding: 'var(--space-sm) var(--space-md)',
        borderRadius: 'var(--radius)',
        margin: 0,
        fontSize: '0.85rem',
      }}
    >
      {message}
    </p>
  );
}
