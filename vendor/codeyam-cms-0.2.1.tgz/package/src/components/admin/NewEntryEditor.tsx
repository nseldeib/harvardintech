// The create-an-entry editor island.
//
// A sibling to `EntryEditor`: same field set (`COLLECTION_FIELDS`) and the same
// stage-then-commit model (a new entry is just a `PendingChange` whose baseline
// is the empty string, so the review shows it as an all-additions file creation
// and `commitAll` writes a brand-new blob). What's different from editing is why
// this is its own component:
//   • the slug isn't known up front — it's derived from the title as you type and
//     stays editable, and it decides the file path.
//   • "Create" is gated: a title/name is required, a slug is required, and the
//     slug must not collide with an entry that already exists in the collection.
// All that gating + change-building is pure logic in `../../lib/newEntry`; this
// component only owns React state, the slug auto-follow effect, and the markup.
// After staging, the form stays open (showing "Staged") so several new entries
// can be added before one commit.
import { useEffect, useMemo, useRef, useState } from 'react';
import type { CollectionName } from '../../lib/adminDashboard';
import { COLLECTION_FIELDS, labelFieldName, type FieldDef, type RawFieldValue } from '../../lib/entryEditor';
import { emptyFieldValues, newEntryStatus, buildNewEntryChange, hasAnyInput } from '../../lib/newEntry';
import { slugify } from '../../lib/slug';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import { EMPTY_MANIFEST, markdownImage, type MediaAsset, type MediaManifest } from '../../lib/mediaLibrary';
import EntryField, { fieldLabelStyle, fieldInputStyle } from './EntryField';
import ImageField from './ImageField';
import MediaPickerModal from './MediaPickerModal';
import EntryPreview from './EntryPreview';
import BodyToolbar from './BodyToolbar';
import SplitTabs from './SplitTabs';
import ViewOnSiteLink from './ViewOnSiteLink';
import { splitCss } from './entryPreviewStyles';

interface Props {
  collection: CollectionName;
  /** The collection's editable fields. Omitted for a built-in collection (falls
   * back to `COLLECTION_FIELDS`); passed explicitly for a custom collection. */
  fields?: FieldDef[];
  /** Slugs already present in the collection — the create-time collision guard. */
  existingSlugs: string[];
  /** Committed media manifest, for the cover-image + insert-image picker. */
  mediaLibrary?: MediaManifest;
  mediaCommitted?: MediaManifest;
}

type PickerTarget = { kind: 'field'; name: string } | { kind: 'body' };

export default function NewEntryEditor({ collection, fields: propFields, existingSlugs, mediaLibrary = EMPTY_MANIFEST, mediaCommitted = EMPTY_MANIFEST }: Props) {
  // The SEO group is refined when EDITING an entry, not at creation — keep the
  // new-entry form focused on the content fields.
  const allFields = propFields ?? (COLLECTION_FIELDS as Record<string, FieldDef[]>)[collection] ?? [];
  const fields = useMemo(() => allFields.filter((f) => f.group !== 'seo'), [allFields]);
  const initialValues = useMemo(() => emptyFieldValues(fields), [fields]);
  const [values, setValues] = useState<Record<string, RawFieldValue>>(initialValues);
  const [body, setBody] = useState('');
  const [slug, setSlug] = useState('');
  // Once the editor edits the slug by hand it stops following the title.
  const [slugTouched, setSlugTouched] = useState(false);
  const [staged, setStaged] = useState(false);
  const [picker, setPicker] = useState<PickerTarget | null>(null);
  const [view, setView] = useState<'edit' | 'preview'>('edit');
  const bodyRef = useRef<HTMLTextAreaElement>(null);

  const labelValue = String(values[labelFieldName(fields)] ?? '');

  // Auto-derive the slug from the title/name until the editor overrides it.
  useEffect(() => {
    if (!slugTouched) setSlug(slugify(labelValue));
  }, [labelValue, slugTouched]);

  const status = newEntryStatus({ collection, fields, values, slug, existingSlugs, staged });

  // Inline errors wait until the editor has actually put something in the form
  // — see `hasAnyInput` for why an untouched form is left alone.
  const started = hasAnyInput(values, slug, body);
  const fieldError = (name: string) => (started ? status.required.fieldErrors[name] : undefined);
  // Mirrors `newEntryStatus`'s message priority: the footer only turns red when
  // the line it is showing is the required-fields one.
  const showingFieldError =
    !staged && !status.collision && !status.missingLabel && !status.missingSlug && status.required.blocked;

  // Reflect this entry's staged status from the shared store (keyed by path, which
  // moves with the slug).
  useEffect(() => {
    const sync = () => setStaged(status.path !== '' && loadChanges().some((c) => c.path === status.path));
    sync();
    return subscribe(sync);
  }, [status.path]);

  const setField = (name: string, value: RawFieldValue) =>
    setValues((prev) => ({ ...prev, [name]: value }));

  const insertIntoBody = (asset: MediaAsset) => {
    const snippet = markdownImage(asset);
    const el = bodyRef.current;
    const at = el ? el.selectionStart : body.length;
    const before = body.slice(0, at);
    const after = body.slice(at);
    const sep = before && !before.endsWith('\n') ? '\n\n' : '';
    setBody(`${before}${sep}${snippet}\n${after}`);
  };

  const onPickImage = (asset: MediaAsset) => {
    if (picker?.kind === 'field') setField(picker.name, asset.url);
    else if (picker?.kind === 'body') insertIntoBody(asset);
    setPicker(null);
  };

  const onCreate = () => {
    if (!status.canCreate) return;
    stageChange(buildNewEntryChange({ collection, fields, values, body, slug: status.finalSlug }));
  };

  const onDiscard = () => {
    if (status.path) discardChange(status.path);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <style>{splitCss}</style>

      <SplitTabs view={view} onChange={setView} />

      <div className="cy-split" data-view={view}>
        <div className="cy-pane-edit" style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
        {fields.map((field) =>
          field.type === 'image' ? (
            <ImageField
              key={field.name}
              field={field}
              value={String(values[field.name] ?? '')}
              onPick={() => setPicker({ kind: 'field', name: field.name })}
              onClear={() => setField(field.name, '')}
              error={fieldError(field.name)}
            />
          ) : (
            <EntryField
              key={field.name}
              field={field}
              value={values[field.name]}
              onChange={(v) => setField(field.name, v)}
              error={fieldError(field.name)}
            />
          ),
        )}

        <div>
          <label style={fieldLabelStyle} htmlFor="f-slug">
            Slug <span style={{ fontWeight: 400 }}>· file name</span>
          </label>
          <input
            id="f-slug"
            value={slug}
            onChange={(e) => {
              // Keep hyphens the editor is typing (don't trim yet) so "foo-bar"
              // is reachable; the strict `finalSlug` trims at use.
              setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]+/g, '-'));
              setSlugTouched(true);
            }}
            style={{
              ...fieldInputStyle,
              fontFamily: 'var(--font-mono)',
              borderColor: status.collision ? 'var(--color-danger, #c0392b)' : 'var(--color-border)',
            }}
          />
          <p style={{ margin: '0.35rem 0 0', fontSize: '0.8rem', color: 'var(--color-muted)' }}>
            {status.path
              ? `Creates ${status.path}`
              : 'The title becomes the file name automatically.'}
          </p>
        </div>

        <div>
          <label style={fieldLabelStyle} htmlFor="f-body">
            Body <span style={{ fontWeight: 400 }}>· markdown</span>
          </label>
          <BodyToolbar
            value={body}
            onChange={setBody}
            textareaRef={bodyRef}
            onInsertImage={() => setPicker({ kind: 'body' })}
          />
          <textarea
            id="f-body"
            ref={bodyRef}
            value={body}
            rows={12}
            onChange={(e) => setBody(e.target.value)}
            style={{ ...fieldInputStyle, resize: 'vertical', fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}
          />
        </div>
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--space-md)',
          borderTop: '1px solid var(--color-border)',
          paddingTop: 'var(--space-md)',
        }}
      >
        <button
          type="button"
          onClick={onCreate}
          disabled={!status.canCreate}
          style={{
            padding: '0.5rem 1.1rem',
            borderRadius: 'var(--radius)',
            border: 'none',
            fontWeight: 600,
            cursor: status.canCreate ? 'pointer' : 'not-allowed',
            background: status.canCreate ? 'var(--color-accent)' : 'var(--color-border)',
            color: status.canCreate ? '#fff' : 'var(--color-muted)',
          }}
        >
          {staged ? 'Staged ✓' : 'Create entry'}
        </button>

        {staged && (
          <button
            type="button"
            onClick={onDiscard}
            style={{
              padding: '0.5rem 1.1rem',
              borderRadius: 'var(--radius)',
              border: '1px solid var(--color-border)',
              background: 'transparent',
              color: 'var(--color-fg)',
              cursor: 'pointer',
            }}
          >
            Remove from staging
          </button>
        )}

        <span
          style={{
            fontSize: '0.85rem',
            color:
              status.collision || showingFieldError
                ? 'var(--color-danger, #c0392b)'
                : 'var(--color-muted)',
          }}
        >
          {status.message}
        </span>

        {/* A not-yet-created entry has no live page — always the "publish first" hint. */}
        <span style={{ marginLeft: 'auto' }}>
          <ViewOnSiteLink published={false} siteUrl="" collection={collection} slug={status.finalSlug} />
        </span>
      </div>
        </div>

        <div className="cy-pane-preview">
          <EntryPreview collection={collection} values={values} body={body} labelField={labelFieldName(fields)} />
        </div>
      </div>

      {picker && (
        <MediaPickerModal
          library={mediaLibrary}
          committed={mediaCommitted}
          purpose={picker.kind === 'field' ? 'cover' : 'insert'}
          selectedUrl={picker.kind === 'field' ? String(values[picker.name] ?? '') : undefined}
          onSelect={onPickImage}
          onClose={() => setPicker(null)}
        />
      )}
    </div>
  );
}
