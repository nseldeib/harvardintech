// One editable field in the entry editor, rendered by its declared type: a
// checkbox for the draft toggle (with a live/hidden hint), a textarea for prose
// fields, a date/number/text input otherwise. Presentational — it owns no state;
// the parent EntryEditor holds the value and receives changes via `onChange`.
import type { CSSProperties } from 'react';
import type { FieldDef, RawFieldValue } from '../../lib/entryEditor';
import FieldError, { errorBorderStyle } from './FieldError';

export const fieldLabelStyle: CSSProperties = {
  display: 'block',
  fontSize: '0.8rem',
  fontWeight: 600,
  color: 'var(--color-muted)',
  marginBottom: 'var(--space-sm)',
};
export const fieldInputStyle: CSSProperties = {
  width: '100%',
  padding: '0.5rem 0.65rem',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  font: 'inherit',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
};

interface Props {
  field: FieldDef;
  value: RawFieldValue;
  onChange: (value: RawFieldValue) => void;
  /** Why this field is blocking — the enforcement half of the "· optional"
   * marker. Rendered beneath the input; the parent computes it. */
  error?: string;
}

export default function EntryField({ field, value, onChange, error }: Props) {
  if (field.type === 'boolean') {
    return (
      <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-sm)', fontWeight: 600 }}>
        <input type="checkbox" checked={value === true} onChange={(e) => onChange(e.target.checked)} />
        {field.label}
        {field.name === 'draft' && (
          <span style={{ fontWeight: 400, fontSize: '0.8rem', color: 'var(--color-muted)' }}>
            {value === true ? 'Hidden from the live site' : 'Live on the site'}
          </span>
        )}
      </label>
    );
  }

  return (
    <div>
      <label style={fieldLabelStyle} htmlFor={`f-${field.name}`}>
        {field.label}
        {field.optional && <span style={{ fontWeight: 400 }}> · optional</span>}
      </label>
      {field.type === 'textarea' ? (
        <textarea
          id={`f-${field.name}`}
          value={String(value ?? '')}
          rows={3}
          onChange={(e) => onChange(e.target.value)}
          style={{ ...fieldInputStyle, resize: 'vertical', ...(error ? errorBorderStyle : null) }}
        />
      ) : (
        <input
          id={`f-${field.name}`}
          type={field.type === 'date' ? 'date' : field.type === 'number' ? 'number' : 'text'}
          value={String(value ?? '')}
          onChange={(e) => onChange(e.target.value)}
          style={{ ...fieldInputStyle, ...(error ? errorBorderStyle : null) }}
        />
      )}
      <FieldError error={error} />
      {field.hint && (
        <p style={{ margin: '0.35rem 0 0', fontSize: '0.78rem', color: 'var(--color-muted)' }}>
          {field.hint}
        </p>
      )}
    </div>
  );
}
