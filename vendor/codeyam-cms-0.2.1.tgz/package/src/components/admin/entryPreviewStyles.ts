// Shared styling for the editor↔preview split, used by EntryEditor and
// NewEntryEditor. `splitCss` is a global stylesheet (injected once via a <style>
// tag) that lays the form and preview side-by-side on wide screens and collapses
// to a single column with an Edit/Preview toggle on narrow ones. `splitTabBtn`
// styles the toggle buttons. Kept out of the components so both hosts stay in sync.
import type { CSSProperties } from 'react';

/** Global CSS for the split. Wide: two columns, preview sticky. Narrow
 * (≤900px): one column, tabs shown, the non-active pane hidden by `data-view`. */
export const splitCss = `
.cy-split { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: var(--space-lg); align-items: start; }
.cy-split-tabs { display: none; }
.cy-pane-preview {
  position: sticky; top: var(--space-md); align-self: start;
  border: 1px solid var(--color-border); border-radius: var(--radius);
  background: var(--color-bg); padding: var(--space-lg);
  max-height: calc(100vh - var(--space-lg) * 2); overflow-y: auto;
}
@media (max-width: 900px) {
  .cy-split { grid-template-columns: 1fr; }
  .cy-split-tabs { display: inline-flex; gap: var(--space-sm); margin-bottom: var(--space-md); }
  .cy-split[data-view="edit"] .cy-pane-preview { display: none; }
  .cy-split[data-view="preview"] .cy-pane-edit { display: none; }
  .cy-pane-preview { position: static; max-height: none; }
}
`;

/** One Edit/Preview toggle button; `active` gets the accent treatment. */
export function splitTabBtn(active: boolean): CSSProperties {
  return {
    padding: '0.35rem 0.9rem',
    borderRadius: 'var(--radius)',
    border: `1px solid ${active ? 'var(--color-accent)' : 'var(--color-border)'}`,
    background: active ? 'var(--color-accent)' : 'var(--color-bg)',
    color: active ? '#fff' : 'var(--color-fg)',
    cursor: 'pointer',
    fontSize: '0.85rem',
    fontWeight: 600,
  };
}
