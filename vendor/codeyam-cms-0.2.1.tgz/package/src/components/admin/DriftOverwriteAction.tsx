// The escape hatch at the foot of the drift warning: commit anyway, overwriting
// whatever the co-editor wrote.
//
// This is its own component because its whole reason for existing is that it
// must NOT look like the button to press. Sometimes you really do mean to
// overwrite — so refusing to offer it would just push editors toward copying
// text out and back in — but it is the one action here that destroys someone
// else's work, so it renders as plain underlined text rather than a button,
// sits below the per-entry rows rather than beside them, and says out loud what
// it does. Keeping that treatment in a named component means a future edit has
// to deliberately promote it rather than casually restyle a stray button.
import { driftOverwriteBtn } from './stagingStyles';

interface Props {
  /** Disable while a commit is in flight. */
  busy?: boolean;
  onOverwrite: () => void;
}

export default function DriftOverwriteAction({ busy = false, onOverwrite }: Props) {
  return (
    <div style={{ marginTop: 'var(--space-md)' }}>
      {/* Dimmed while committing for the same reason as the row actions: a
          disabled control that still looks live invites a second click, and a
          stray click HERE would overwrite a co-editor. */}
      <button
        type="button"
        disabled={busy}
        style={busy ? { ...driftOverwriteBtn, opacity: 0.5, cursor: 'not-allowed' } : driftOverwriteBtn}
        onClick={onOverwrite}
      >
        Publish anyway, overwriting their changes
      </button>
    </div>
  );
}
