// The "someone else changed this" warning, shown in place of a commit when the
// pre-commit freshness check found that the branch moved underneath a staged
// change.
//
// The frame only: a headline naming the scale of the problem, a DriftEntryRow
// per drifted entry, and the de-emphasised overwrite once at the foot. Composing
// the rows rather than mapping them inline keeps this the same shape as the
// review list next to it (ChangeGroupList → ChangeGroup), and keeps the
// overwrite's deliberate visual demotion in a component of its own.
//
// Presentational + interaction-forwarding: the parent owns the staging set and
// re-runs the commit, so this unit-tests and captures as a scenario with no
// network.
import { summarizeDrift, type DriftedChange } from '../../lib/staleCheck';
import DriftEntryRow from './DriftEntryRow';
import DriftOverwriteAction from './DriftOverwriteAction';
import { driftNoticeStyle } from './stagingStyles';

interface Props {
  drifted: DriftedChange[];
  /** Disable every action while a commit is in flight. */
  busy?: boolean;
  /** Unstage the editor's version of this path entirely. */
  onDiscard: (path: string) => void;
  /** Adopt the branch's current content as this change's new baseline, so the
   * review diff shows the co-editor's version against the editor's. */
  onReload: (drift: DriftedChange) => void;
  /** Commit anyway, overwriting the co-editor's work. */
  onOverwrite: () => void;
}

export default function DriftNotice({ drifted, busy = false, onDiscard, onReload, onOverwrite }: Props) {
  if (drifted.length === 0) return null;

  return (
    <div style={driftNoticeStyle} role="alert">
      <strong style={{ color: '#92400e', fontSize: '0.95rem' }}>{summarizeDrift(drifted)}</strong>
      <p style={{ margin: '0.35rem 0 0', color: '#92400e', fontSize: '0.85rem' }}>
        Nothing has been published. Resolve each entry below, then publish again.
      </p>

      {drifted.map((drift) => (
        <DriftEntryRow key={drift.path} drift={drift} busy={busy} onDiscard={onDiscard} onReload={onReload} />
      ))}

      <DriftOverwriteAction busy={busy} onOverwrite={onOverwrite} />
    </div>
  );
}
