// The navigation editor island: the state-owning root for the site menu, a
// one-level-deep tree of NavItemRow children. It owns the items list and wires
// every mutation — item and per-child add/edit/move/remove — through the pure
// `navEditor` helpers, then hands the new list down to the presentational rows.
// "Stage change" serializes the edited menu to canonical JSON and adds a
// PendingChange to the browser staging set; the global StagingBar commits it
// later, batched with any other pending changes. The dirty/diff baseline is the
// nav normalized through the serializer, so reverting cleanly unstages.
import { useEffect, useMemo, useState } from 'react';
import type { NavItem, SiteNav } from '../../lib/siteConfig';
import { NAV_PATH, serializeNav } from '../../lib/siteConfig';
import {
  addNavChild,
  addNavItem,
  buildNavChange,
  moveNavChild,
  moveNavItem,
  moveNavNode,
  removeNavChild,
  removeNavItem,
  updateNavChild,
  updateNavItem,
} from '../../lib/navEditor';
import { useNavDrag } from '../../lib/useNavDrag';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import { addBtnStyle } from './configEditorStyles';
import NavItemRow from './NavItemRow';
import StageFooter from './StageFooter';

interface Props {
  initialNav: SiteNav;
}

export default function NavEditor({ initialNav }: Props) {
  const [items, setItems] = useState<NavItem[]>(initialNav.items ?? []);
  const [staged, setStaged] = useState(false);

  const original = useMemo(() => serializeNav(initialNav), [initialNav]);
  const current = serializeNav({ items });
  const dirty = current !== original;

  useEffect(() => {
    const sync = () => setStaged(loadChanges().some((c) => c.path === NAV_PATH));
    sync();
    return subscribe(sync);
  }, []);

  const onStage = () => stageChange(buildNavChange(initialNav, { items }));
  const onRevert = () => {
    setItems(initialNav.items ?? []);
    discardChange(NAV_PATH);
  };

  const drag = useNavDrag((from, to) => setItems(moveNavNode(items, from, to)));

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <section style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
        <h2 style={{ margin: 0, fontSize: '1.05rem' }}>Navigation</h2>
        {items.length === 0 && (
          <p style={{ margin: 0, color: 'var(--color-muted)', fontSize: '0.9rem' }}>
            No menu items yet — add one to build the site navigation.
          </p>
        )}

        {items.map((item, i) => (
          <NavItemRow
            key={i}
            item={item}
            index={i}
            isFirst={i === 0}
            isLast={i === items.length - 1}
            onItemChange={(patch) => setItems(updateNavItem(items, i, patch))}
            onMove={(delta) => setItems(moveNavItem(items, i, delta))}
            onRemove={() => setItems(removeNavItem(items, i))}
            onAddChild={() => setItems(addNavChild(items, i))}
            onChildChange={(ci, patch) => setItems(updateNavChild(items, i, ci, patch))}
            onChildMove={(ci, delta) => setItems(moveNavChild(items, i, ci, delta))}
            onChildRemove={(ci) => setItems(removeNavChild(items, i, ci))}
            drag={drag}
          />
        ))}

        <button type="button" onClick={() => setItems(addNavItem(items))} style={addBtnStyle}>
          + Add menu item
        </button>
      </section>

      <StageFooter dirty={dirty} staged={staged} onStage={onStage} onRevert={onRevert} />
    </div>
  );
}
