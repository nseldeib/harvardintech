// The media gallery's empty state — shown on day one (the production default,
// an empty manifest) before any image is uploaded. Presentational, no props; it
// nudges the editor toward the upload zone above it. Mirrors the empty-state
// nudge the content lists show when a collection has no entries.
export default function MediaLibraryEmpty() {
  return (
    <div
      style={{
        textAlign: 'center',
        padding: 'var(--space-xl, 2rem) var(--space-lg)',
        color: 'var(--color-muted)',
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius)',
        background: 'var(--color-bg)',
      }}
    >
      <div style={{ fontSize: '2rem', marginBottom: '0.4rem' }}>🖼️</div>
      <div style={{ fontWeight: 600, color: 'var(--color-fg)' }}>No images yet</div>
      <div style={{ fontSize: '0.85rem' }}>Upload your first image to start the library.</div>
    </div>
  );
}
