// The picker modal's title row: what you're choosing for, and the way out.
interface Props {
  title: string;
  onClose: () => void;
}

export default function MediaModalHeader({ title, onClose }: Props) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <h2 style={{ margin: 0, fontSize: '1.1rem' }}>{title}</h2>
      <button
        type="button"
        onClick={onClose}
        style={{
          background: 'transparent',
          border: '1px solid var(--color-border)',
          borderRadius: 'var(--radius)',
          padding: '0.3rem 0.7rem',
          cursor: 'pointer',
          color: 'var(--color-fg)',
        }}
      >
        Close
      </button>
    </div>
  );
}
