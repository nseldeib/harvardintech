// Shared inline styles for the /admin/editors roster + the magic-link sign-in,
// so the team list, its status badges, and the invite form read as one system.
// Plain data (no JSX), safe to import anywhere. Mirrors `authStyles.ts`.
import type { CSSProperties } from 'react';
import type { EditorRole, EditorStatus } from '../../lib/editorsRegistry';

export const listStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-sm)',
  listStyle: 'none',
  margin: 0,
  padding: 0,
};

export const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-md)',
  padding: '0.7rem 0.8rem',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  background: 'var(--color-bg)',
};

export const avatarStyle: CSSProperties = {
  width: '2.2rem',
  height: '2.2rem',
  borderRadius: '50%',
  objectFit: 'cover',
  border: '1px solid var(--color-border)',
  flexShrink: 0,
};

export const avatarFallback: CSSProperties = {
  ...avatarStyle,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  background: 'var(--color-surface)',
  color: 'var(--color-muted)',
  fontSize: '0.8rem',
  fontWeight: 700,
};

export const identityStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: '0.1rem',
  minWidth: 0,
  flex: 1,
};

export const nameStyle: CSSProperties = {
  fontWeight: 600,
  color: 'var(--color-fg)',
  fontSize: '0.95rem',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
};

export const emailStyle: CSSProperties = {
  color: 'var(--color-muted)',
  fontSize: '0.82rem',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
};

export const metaStyle: CSSProperties = {
  color: 'var(--color-muted)',
  fontSize: '0.75rem',
};

export const badgeBase: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  padding: '0.15rem 0.55rem',
  borderRadius: '999px',
  fontSize: '0.72rem',
  fontWeight: 700,
  letterSpacing: '0.02em',
  whiteSpace: 'nowrap',
};

/** Status pill colors — active (green), invited (amber), expired (red). */
export function statusBadgeStyle(status: EditorStatus): CSSProperties {
  const palette: Record<EditorStatus, { bg: string; fg: string; border: string }> = {
    active: { bg: '#d1fae5', fg: '#065f46', border: '#a7f3d0' },
    invited: { bg: '#fef3c7', fg: '#92400e', border: '#fde68a' },
    expired: { bg: '#fee2e2', fg: '#991b1b', border: '#fecaca' },
  };
  const c = palette[status];
  return { ...badgeBase, background: c.bg, color: c.fg, border: `1px solid ${c.border}` };
}

/** Role pill — the owner gets the accent, editors a quiet outline. */
export function roleBadgeStyle(role: EditorRole): CSSProperties {
  if (role === 'owner') {
    return {
      ...badgeBase,
      background: 'color-mix(in srgb, var(--color-accent) 14%, transparent)',
      color: 'var(--color-accent)',
      border: '1px solid color-mix(in srgb, var(--color-accent) 30%, transparent)',
    };
  }
  return {
    ...badgeBase,
    background: 'transparent',
    color: 'var(--color-muted)',
    border: '1px solid var(--color-border)',
  };
}

export const badgeGroup: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 'var(--space-sm)',
  flexShrink: 0,
};

export const rowActions: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 'var(--space-sm)',
  flexShrink: 0,
};

export const linkBtn: CSSProperties = {
  padding: '0.3rem 0.6rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-fg)',
  fontSize: '0.8rem',
  fontWeight: 600,
  cursor: 'pointer',
  whiteSpace: 'nowrap',
};

export const dangerBtn: CSSProperties = {
  ...linkBtn,
  color: '#991b1b',
  borderColor: '#fecaca',
};

// ── Invite form ────────────────────────────────────────────────────────────
export const inviteForm: CSSProperties = {
  display: 'flex',
  gap: 'var(--space-sm)',
  flexWrap: 'wrap',
  alignItems: 'flex-start',
};

export const inviteInput: CSSProperties = {
  flex: 1,
  minWidth: '14rem',
  padding: '0.6rem 0.7rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  fontSize: '0.9rem',
  boxSizing: 'border-box',
};

export const inviteBtn: CSSProperties = {
  padding: '0.6rem 1.1rem',
  borderRadius: 'var(--radius)',
  border: 'none',
  background: 'var(--color-accent)',
  color: '#fff',
  fontWeight: 700,
  fontSize: '0.9rem',
  cursor: 'pointer',
  whiteSpace: 'nowrap',
};

export const inviteError: CSSProperties = {
  margin: '0.1rem 0 0',
  color: '#991b1b',
  fontSize: '0.82rem',
  flexBasis: '100%',
};

export const inviteHint: CSSProperties = {
  margin: '0.1rem 0 0',
  color: 'var(--color-muted)',
  fontSize: '0.82rem',
  flexBasis: '100%',
};

// ── Magic-link sign-in (reuses the gate card look from authStyles) ──────────
export const magicMark: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: '2.4rem',
  height: '2.4rem',
  borderRadius: '10px',
  background: 'var(--color-accent)',
  color: '#fff',
  fontSize: '1.3rem',
  marginBottom: 'var(--space-md)',
};

export const magicBody: CSSProperties = {
  margin: '0 0 var(--space-lg)',
  color: 'var(--color-muted)',
  fontSize: '0.92rem',
  lineHeight: 1.5,
};

export const magicSpinner: CSSProperties = {
  width: '1.6rem',
  height: '1.6rem',
  margin: '0 auto var(--space-md)',
  border: '3px solid var(--color-border)',
  borderTopColor: 'var(--color-accent)',
  borderRadius: '50%',
  animation: 'codeyam-spin 0.8s linear infinite',
};

export const magicSecondaryBtn: CSSProperties = {
  width: '100%',
  marginTop: 'var(--space-sm)',
  padding: '0.6rem 1rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-fg)',
  fontWeight: 600,
  fontSize: '0.9rem',
  cursor: 'pointer',
};
