// The in-editor image picker: a modal over the entry editor for choosing an
// image, used both to set a cover image and to insert one into the body. It
// lists the library (every image in `public/images`, whether or not the CMS
// uploaded it, plus staged uploads) and hosts the same upload zone as the
// standalone gallery — an uploaded image stages immediately and can be picked
// right away, and an image the site already had can be picked without ever
// being uploaded. Selecting an asset calls `onSelect`; the parent decides
// whether that becomes the cover field or a `![alt](url)` body insertion.
import { useMemo, useState } from 'react';
import { libraryFolders, type MediaAsset, type MediaManifest } from '../../lib/mediaLibrary';
import { currentLibrary, stageUpload } from '../../lib/mediaStaging';
import { saveUploadDestination } from '../../lib/uploadDestination';
import MediaCard from './MediaCard';
import MediaUploader from './MediaUploader';
import MediaErrorNotice from './MediaErrorNotice';
import MediaGrid from './MediaGrid';
import MediaModalHeader from './MediaModalHeader';
import MediaPickerEmpty from './MediaPickerEmpty';
import { overlayStyle } from './stagingStyles';

interface Props {
  /** What the grid shows: the `public/images` scan merged with the manifest. */
  library: MediaManifest;
  /** The raw committed manifest — the diff baseline for an upload staged here. */
  committed: MediaManifest;
  /** Currently-chosen asset url, highlighted in the grid (cover-image use). */
  selectedUrl?: string;
  /** What the picker is choosing for — tunes the title/verb. */
  purpose?: 'cover' | 'insert';
  onSelect: (asset: MediaAsset) => void;
  onClose: () => void;
  /** Seed the grid for isolated-component scenarios. */
  initialManifest?: MediaManifest;
}

const panelStyle = {
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-lg)',
  width: 'min(720px, 94vw)',
  maxHeight: '86vh',
  overflowY: 'auto',
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-md)',
} as const;

export default function MediaPickerModal({
  library,
  committed,
  selectedUrl,
  purpose = 'insert',
  onSelect,
  onClose,
  initialManifest,
}: Props) {
  const [manifest, setManifest] = useState<MediaManifest>(
    initialManifest ?? currentLibrary(library, committed),
  );
  const [error, setError] = useState('');

  // Same derivation as the standalone gallery: the folders the grid is showing.
  const folders = useMemo(() => libraryFolders(manifest), [manifest]);

  const onFiles = async (files: File[], destination: string) => {
    setError('');
    try {
      for (const file of files) await stageUpload(file, library, committed, {}, destination);
      saveUploadDestination(destination);
      setManifest(currentLibrary(library, committed));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };

  const title = purpose === 'cover' ? 'Choose a cover image' : 'Insert an image';

  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={panelStyle} onClick={(e) => e.stopPropagation()}>
        <MediaModalHeader title={title} onClose={onClose} />

        <MediaUploader onFiles={onFiles} folders={folders} compact />

        <MediaErrorNotice message={error} />

        {manifest.assets.length === 0 ? (
          <MediaPickerEmpty />
        ) : (
          <MediaGrid minCardWidth="150px">
            {manifest.assets.map((asset) => (
              <MediaCard
                key={asset.filename}
                asset={asset}
                selected={asset.url === selectedUrl}
                onClick={() => onSelect(asset)}
              />
            ))}
          </MediaGrid>
        )}
      </div>
    </div>
  );
}
