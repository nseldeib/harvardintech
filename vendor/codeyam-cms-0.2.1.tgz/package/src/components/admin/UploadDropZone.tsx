// The dashed drop target itself: drag images onto it, or click to open the file
// picker. Filters to `image/*` and hands the parent a plain `File[]` — it knows
// nothing about where the files will go, so the destination concept stays out of
// the zone and a disabled zone has one meaning ("not accepting files") whatever
// the reason.
//
// A drop while disabled is simply not accepted: nothing is read and nothing is
// staged, so the same files can be dropped again once the reason clears.
import { useRef, useState, type CSSProperties } from 'react';

interface Props {
  onFiles: (files: File[]) => void;
  /** Not accepting files — dimmed, and clicks/drops do nothing. */
  disabled?: boolean;
  /** Compact variant for the picker modal (shorter zone). */
  compact?: boolean;
  /** The secondary line under the heading — the parent says why when blocked. */
  hint: string;
}

const zoneStyle = (over: boolean, compact: boolean): CSSProperties => ({
  border: `2px dashed ${over ? 'var(--color-accent)' : 'var(--color-border)'}`,
  borderRadius: 'var(--radius)',
  background: over ? 'color-mix(in srgb, var(--color-accent) 8%, transparent)' : 'var(--color-bg)',
  padding: compact ? 'var(--space-md)' : 'var(--space-lg)',
  textAlign: 'center',
  cursor: 'pointer',
  color: 'var(--color-muted)',
  transition: 'border-color 120ms, background 120ms',
});

export default function UploadDropZone({ onFiles, disabled = false, compact = false, hint }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  // Surface only image/* files from a DOM FileList to the parent.
  const handle = (list: FileList | null) => {
    const files = list ? Array.from(list).filter((f) => f.type.startsWith('image/')) : [];
    if (files.length > 0) onFiles(files);
  };

  return (
    <div
      onClick={() => !disabled && inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        if (!disabled) handle(e.dataTransfer.files);
      }}
      style={{
        ...zoneStyle(over, compact),
        opacity: disabled ? 0.6 : 1,
        cursor: disabled ? 'not-allowed' : 'pointer',
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        hidden
        onChange={(e) => {
          handle(e.target.files);
          e.target.value = '';
        }}
      />
      <div style={{ fontWeight: 600, color: 'var(--color-fg)', marginBottom: '0.2rem' }}>
        {over ? 'Drop to upload' : 'Drag images here or click to upload'}
      </div>
      <div style={{ fontSize: '0.8rem' }}>{hint}</div>
    </div>
  );
}
