// The upload control shared by the media gallery and the in-editor picker:
// a destination folder to file the upload under, above the drag-and-drop zone
// that collects the images. Composition only — the destination rule lives in
// `useUploadDestination`, the folder row in `UploadDestinationField`, and the
// drop target in `UploadDropZone`.
//
// The destination lives HERE rather than in each parent because both upload
// paths need it and a third one shouldn't be able to silently regress to the
// root. Its value is seeded from the folder last used in this browser, so
// uploading a batch means choosing a folder once. The parent does the actual
// read-and-stage, receiving the files and the chosen destination together.
import UploadDestinationField from './UploadDestinationField';
import UploadDropZone from './UploadDropZone';
import { useUploadDestination } from '../../lib/useUploadDestination';

interface Props {
  /** Receives the picked images and the folder to file them under ('' = root). */
  onFiles: (files: File[], destination: string) => void;
  /** Folders currently in the library, root first — see `libraryFolders`. */
  folders?: string[];
  disabled?: boolean;
  /** Compact variant for the picker modal (shorter zone, one-line control). */
  compact?: boolean;
  /**
   * Seed the destination for isolated-component scenarios instead of reading the
   * browser preference. A value that isn't in `folders` starts the control in
   * its new-folder state with the text pre-filled — which is also how the
   * invalid-folder state is demonstrated.
   */
  initialDestination?: string;
}

export default function MediaUploader({
  onFiles,
  folders = [''],
  disabled = false,
  compact = false,
  initialDestination,
}: Props) {
  const dest = useUploadDestination(folders, initialDestination);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-xs, 0.4rem)' }}>
      <UploadDestinationField
        folders={folders}
        choice={dest.choice}
        newFolder={dest.newFolder}
        typing={dest.typing}
        invalid={dest.invalid}
        disabled={disabled}
        compact={compact}
        onChoice={dest.setChoice}
        onNewFolder={dest.setNewFolder}
      />

      <UploadDropZone
        onFiles={(files) => onFiles(files, dest.destination)}
        disabled={disabled || dest.invalid !== null}
        compact={compact}
        hint={
          dest.invalid
            ? 'Choose a valid destination to upload'
            : 'PNG, JPG, GIF, SVG — staged with your other changes'
        }
      />
    </div>
  );
}
