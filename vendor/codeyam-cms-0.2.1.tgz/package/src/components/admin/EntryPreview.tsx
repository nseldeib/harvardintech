// The live preview pane: an entry rendered as it will appear on the published
// site. Reads the editor's current field values + body and shows a hero image
// (cover / photo), the title, a meta line (date / role / location), and the
// markdown body rendered to HTML — styled with the site's typography so it reads
// like the real article, not a raw textarea. Pure/presentational: the parent
// EntryEditor owns the values and re-renders this on every keystroke.
import { useMemo } from 'react';
import type { CollectionName } from '../../lib/adminDashboard';
import type { RawFieldValue } from '../../lib/entryEditor';
import { renderMarkdown } from '../../lib/renderMarkdown';
import { asStr, previewTitle, previewMetaLine } from '../../lib/entryPreview';
import { withBase } from '../../lib/adminUrl';

interface Props {
  collection: CollectionName;
  values: Record<string, RawFieldValue>;
  body: string;
  /** The collection's designated label field, so a custom collection's preview
   * titles by its own field (e.g. `company`) instead of falling back to Untitled. */
  labelField?: string;
}

export default function EntryPreview({ collection, values, body, labelField }: Props) {
  const html = useMemo(() => renderMarkdown(body), [body]);
  const hero = asStr(values.coverImage) || asStr(values.photo);
  const title = previewTitle(values, labelField);
  const meta = previewMetaLine(values);
  // Team entries keep their prose in the `bio` field, not the markdown body.
  const bioHtml = useMemo(
    () => (collection === 'team' ? renderMarkdown(asStr(values.bio)) : ''),
    [collection, values.bio],
  );
  const bodyHtml = html || bioHtml;

  return (
    <div className="cy-preview">
      <style>{PREVIEW_CSS}</style>
      {hero && <img className="cy-preview-hero" src={withBase(hero)} alt="" />}
      <h1 className={`cy-preview-title${title.placeholder ? ' cy-preview-muted' : ''}`}>{title.text}</h1>
      {meta && <div className="cy-preview-meta">{meta}</div>}
      {bodyHtml ? (
        <div className="cy-preview-body" dangerouslySetInnerHTML={{ __html: bodyHtml }} />
      ) : (
        <div className="cy-preview-empty">Nothing to preview yet — start writing the body.</div>
      )}
    </div>
  );
}

// Scoped article typography for the rendered markdown, keyed to `.cy-preview` so
// it never leaks into the admin chrome. Mirrors the public post look (content
// width, sans body, accent links).
const PREVIEW_CSS = `
.cy-preview { max-width: var(--content-width, 720px); margin: 0 auto; color: var(--color-fg); font-family: var(--font-sans); line-height: 1.6; }
.cy-preview-hero { width: 100%; max-height: 320px; object-fit: cover; border-radius: var(--radius); margin-bottom: var(--space-md); }
.cy-preview-title { font-size: 1.9rem; line-height: 1.2; margin: 0 0 var(--space-sm); }
.cy-preview-muted { color: var(--color-muted); font-style: italic; }
.cy-preview-meta { color: var(--color-muted); font-size: 0.9rem; margin-bottom: var(--space-lg); }
.cy-preview-empty { color: var(--color-muted); font-style: italic; padding: var(--space-lg) 0; }
.cy-preview-body { font-size: 1.02rem; }
.cy-preview-body h1, .cy-preview-body h2, .cy-preview-body h3 { line-height: 1.25; margin: var(--space-lg) 0 var(--space-sm); }
.cy-preview-body h1 { font-size: 1.6rem; } .cy-preview-body h2 { font-size: 1.35rem; } .cy-preview-body h3 { font-size: 1.15rem; }
.cy-preview-body p { margin: 0 0 var(--space-md); }
.cy-preview-body a { color: var(--color-accent); }
.cy-preview-body img { max-width: 100%; height: auto; border-radius: var(--radius); }
.cy-preview-body ul, .cy-preview-body ol { padding-left: 1.4rem; margin: 0 0 var(--space-md); }
.cy-preview-body li { margin: 0.2rem 0; }
.cy-preview-body blockquote { margin: 0 0 var(--space-md); padding-left: var(--space-md); border-left: 3px solid var(--color-border); color: var(--color-muted); }
.cy-preview-body code { font-family: var(--font-mono); font-size: 0.9em; background: var(--color-surface, #f1f1f6); padding: 0.1rem 0.3rem; border-radius: 4px; }
.cy-preview-body pre { background: var(--color-surface, #f1f1f6); padding: var(--space-md); border-radius: var(--radius); overflow-x: auto; }
.cy-preview-body pre code { background: none; padding: 0; }
.cy-preview-body table { border-collapse: collapse; margin: 0 0 var(--space-md); }
.cy-preview-body th, .cy-preview-body td { border: 1px solid var(--color-border); padding: 0.3rem 0.6rem; }
`;
