// The dashboard-wide search: one box on /admin that finds entries across every
// collection at once. While the box is empty it renders nothing but itself, so
// the dashboard below shows normally; once the editor types, it filters via the
// shared `searchEntries` matcher (title + body) and lists the hits grouped by
// collection, each linking into that entry's editor. No matches → the shared
// empty-with-Clear state. All client-side: the static build hands this island a
// prebuilt search index, so there is no server round-trip.
import { useState } from 'react';
import SearchBox from './SearchBox';
import SearchEmpty from './SearchEmpty';
import SearchResultGroup from './SearchResultGroup';
import {
  groupByCollection,
  normalizeQuery,
  searchEntries,
  type SearchableEntry,
} from '../../lib/entrySearch';

interface Props {
  entries: SearchableEntry[];
  /** Pre-fills the search box — used by the isolation scenarios to capture a
   * results / no-results state deterministically. */
  initialQuery?: string;
}

export default function DashboardSearch({ entries, initialQuery = '' }: Props) {
  const [query, setQuery] = useState(initialQuery);
  const searching = normalizeQuery(query) !== '';
  const matches = searchEntries(entries, query);
  const groups = groupByCollection(matches);

  return (
    <div style={{ marginBottom: 'var(--space-lg)' }}>
      <SearchBox
        value={query}
        onChange={setQuery}
        placeholder="Search all content…"
        ariaLabel="Search all content"
      />

      {searching && matches.length === 0 && (
        <SearchEmpty query={query.trim()} onClear={() => setQuery('')} />
      )}

      {searching && groups.map((group) => <SearchResultGroup key={group.collection} group={group} />)}
    </div>
  );
}
