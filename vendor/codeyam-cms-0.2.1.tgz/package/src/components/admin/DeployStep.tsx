// One row of the deploy-pipeline stepper: a status dot + a stage label. The dot
// colour and glyph encode the row's state — done (green ✓), active (accent),
// pending (muted), failed (red ✕) — so the whole pipeline reads at a glance.
// Presentational; the parent DeployStatus derives the rows via `deploySteps` and
// maps each to one of these, mirroring how ReviewDrawer maps to ChangeDiffCard.
import type { StepVisual } from '../../lib/githubPages';
import { stepRowStyle, stepDot, stepLabel } from './stagingStyles';

const GLYPH: Record<StepVisual, string> = { done: '✓', active: '', pending: '', failed: '✕' };

interface Props {
  label: string;
  visual: StepVisual;
}

export default function DeployStep({ label, visual }: Props) {
  return (
    <li style={stepRowStyle}>
      <span style={stepDot[visual]} aria-hidden="true">
        {GLYPH[visual]}
      </span>
      <span style={stepLabel[visual]}>{label}</span>
    </li>
  );
}
