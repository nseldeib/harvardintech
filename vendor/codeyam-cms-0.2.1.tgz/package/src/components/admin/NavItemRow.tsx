// One editable top-level nav item: a grip handle, its label, a URL field when it
// is a plain link, the up/down/remove controls, the list of NavChildRow children
// when it is a dropdown, and the "+ Add sub-item" button that turns a link into a
// dropdown. The whole card is a drag source (reorder among top-level items) AND a
// drop target; a dropdown's indented children area is a NEST ZONE that accepts a
// dragged leaf as a new child. Presentational — the parent NavEditor owns the
// items list and forwards every mutation through the pure `navEditor` helpers,
// plus the shared `useNavDrag` instance that coordinates the drag across the tree.
import type { NavItem } from '../../lib/siteConfig';
import { isDropdown } from '../../lib/navEditor';
import { noNavDrag, type NavDrag } from '../../lib/useNavDrag';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';
import { addBtnStyle, rowCardStyle, dragRowStyle } from './configEditorStyles';
import RowControls from './RowControls';
import DragHandle from './DragHandle';
import NavChildRow from './NavChildRow';

interface Props {
  item: NavItem;
  index: number;
  isFirst: boolean;
  isLast: boolean;
  onItemChange: (patch: Partial<NavItem>) => void;
  onMove: (delta: number) => void;
  onRemove: () => void;
  onAddChild: () => void;
  onChildChange: (childIndex: number, patch: Partial<NavItem>) => void;
  onChildMove: (childIndex: number, delta: number) => void;
  onChildRemove: (childIndex: number) => void;
  /** Shared drag session from `useNavDrag`; defaults to an inert one for
   * standalone/component-scenario rendering where no live drag exists. */
  drag?: NavDrag;
}

export default function NavItemRow({
  item,
  index,
  isFirst,
  isLast,
  onItemChange,
  onMove,
  onRemove,
  onAddChild,
  onChildChange,
  onChildMove,
  onChildRemove,
  drag = noNavDrag,
}: Props) {
  const dropdown = isDropdown(item);
  const children = item.children ?? [];
  const addr = { parent: null, index };

  return (
    <div
      style={{ ...rowCardStyle, ...dragRowStyle(drag.isDragging(addr), drag.isOverRow(addr)) }}
      {...drag.rowProps(addr, !dropdown)}
    >
      <div style={{ display: 'flex', gap: 'var(--space-sm)', alignItems: 'flex-end', flexWrap: 'wrap' }}>
        <DragHandle label="Drag to reorder menu item" {...drag.handleProps(addr)} />
        <div style={{ flex: '1 1 8rem' }}>
          <label style={fieldLabelStyle} htmlFor={`nav-label-${index}`}>
            Label
          </label>
          <input
            id={`nav-label-${index}`}
            type="text"
            value={item.label}
            placeholder="About"
            onChange={(e) => onItemChange({ label: e.target.value })}
            style={fieldInputStyle}
          />
        </div>
        {dropdown ? (
          <span style={{ flex: '2 1 12rem', fontSize: '0.8rem', color: 'var(--color-muted)', paddingBottom: '0.55rem' }}>
            Dropdown · {children.length} {children.length === 1 ? 'item' : 'items'}
          </span>
        ) : (
          <div style={{ flex: '2 1 12rem' }}>
            <label style={fieldLabelStyle} htmlFor={`nav-url-${index}`}>
              URL
            </label>
            <input
              id={`nav-url-${index}`}
              type="text"
              value={item.url ?? ''}
              placeholder="/pages/about"
              onChange={(e) => onItemChange({ url: e.target.value })}
              style={fieldInputStyle}
            />
          </div>
        )}
        <RowControls
          canUp={!isFirst}
          canDown={!isLast}
          onUp={() => onMove(-1)}
          onDown={() => onMove(1)}
          onRemove={onRemove}
          removeLabel="Remove menu item"
        />
      </div>

      {children.length > 0 && (
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 'var(--space-sm)',
            marginLeft: 'var(--space-lg)',
            paddingLeft: 'var(--space-md)',
            borderLeft: '2px solid var(--color-border)',
            ...(drag.isOverNest(index)
              ? { outline: '2px dashed var(--color-accent)', outlineOffset: '4px', borderRadius: 'var(--radius)' }
              : {}),
          }}
          {...drag.nestZoneProps(index, children.length)}
        >
          {children.map((child, ci) => {
            const childAddr = { parent: index, index: ci };
            return (
              <NavChildRow
                key={ci}
                child={child}
                parentIndex={index}
                index={ci}
                isFirst={ci === 0}
                isLast={ci === children.length - 1}
                onChange={(patch) => onChildChange(ci, patch)}
                onMove={(delta) => onChildMove(ci, delta)}
                onRemove={() => onChildRemove(ci)}
                rowDragProps={drag.rowProps(childAddr, true)}
                handleProps={drag.handleProps(childAddr)}
                isDragging={drag.isDragging(childAddr)}
                isDropTarget={drag.isOverRow(childAddr)}
              />
            );
          })}
        </div>
      )}

      <button
        type="button"
        onClick={onAddChild}
        style={{ ...addBtnStyle, marginLeft: children.length > 0 ? 'var(--space-lg)' : 0, fontSize: '0.85rem' }}
      >
        + Add sub-item
      </button>
    </div>
  );
}
