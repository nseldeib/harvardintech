// Shared inline-style constants for the entry version-history tab and its
// sub-components (EntryHistory, RevisionRow, RevisionViewer). Kept in one module
// so the row, the viewer, and the list stay visually identical — matching how
// entryPreviewStyles / editorsStyles centralize a feature's styling.
import type { CSSProperties } from 'react';

/** A bordered card row — one revision in the history list. */
export const revisionRowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'baseline',
  gap: 'var(--space-md)',
  padding: 'var(--space-md)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  background: 'var(--color-surface)',
};

/** The accent call-to-action (Restore). */
export const historyPrimaryBtn: CSSProperties = {
  padding: '0.5rem 1.1rem',
  borderRadius: 'var(--radius)',
  border: 'none',
  fontWeight: 600,
  cursor: 'pointer',
  background: 'var(--color-accent)',
  color: '#fff',
};

/** A quiet outlined button (View, Back, Try again). */
export const historyGhostBtn: CSSProperties = {
  padding: '0.4rem 0.9rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-fg)',
  cursor: 'pointer',
};

/** The pill that marks the newest version as the live one. */
export const currentBadgeStyle: CSSProperties = {
  marginLeft: 'auto',
  fontSize: '0.72rem',
  fontWeight: 600,
  color: 'var(--color-accent)',
  border: '1px solid var(--color-accent)',
  borderRadius: '999px',
  padding: '0.1rem 0.55rem',
};

/** Muted danger text used by the error states. */
export const historyErrorText: CSSProperties = { color: 'var(--color-danger, #c0392b)' };
