// The Publish page's title block: the "Publish" heading and its one-line
// explanation of the accumulate-then-commit model. Presentational and static —
// extracted so PublishPage composes sections rather than holding raw markup.
export default function PublishHeader() {
  return (
    <div style={{ marginBottom: 'var(--space-lg)' }}>
      <h1 style={{ margin: '0 0 var(--space-xs, 0.25rem)', fontSize: '1.6rem' }}>Publish</h1>
      <p style={{ margin: 0, color: 'var(--color-muted)' }}>
        Review your staged changes and publish them to the live site in one commit.
      </p>
    </div>
  );
}
