// The compact up / down / remove control cluster on an editable list row —
// shared by the social-link rows, the nav item rows, and the nav child rows.
// Presentational: it owns no state, just disables the up/down buttons at the
// ends and forwards the move/remove intents to the parent list editor.
import { iconBtnStyle, removeBtnStyle } from './configEditorStyles';

interface Props {
  /** Whether "move up" is available (false on the first row). */
  canUp: boolean;
  /** Whether "move down" is available (false on the last row). */
  canDown: boolean;
  onUp: () => void;
  onDown: () => void;
  onRemove: () => void;
  /** Accessible label for the remove button, e.g. "Remove social link". */
  removeLabel: string;
}

export default function RowControls({ canUp, canDown, onUp, onDown, onRemove, removeLabel }: Props) {
  return (
    <div style={{ display: 'flex', gap: '0.25rem' }}>
      <button
        type="button"
        aria-label="Move up"
        disabled={!canUp}
        onClick={onUp}
        style={{ ...iconBtnStyle, opacity: canUp ? 1 : 0.4 }}
      >
        ↑
      </button>
      <button
        type="button"
        aria-label="Move down"
        disabled={!canDown}
        onClick={onDown}
        style={{ ...iconBtnStyle, opacity: canDown ? 1 : 0.4 }}
      >
        ↓
      </button>
      <button type="button" aria-label={removeLabel} onClick={onRemove} style={removeBtnStyle}>
        ✕
      </button>
    </div>
  );
}
