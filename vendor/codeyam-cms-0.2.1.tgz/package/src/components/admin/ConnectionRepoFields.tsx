// The repo-target section of the "Repository connection" editor: one labelled
// input per repo field (owner, repo, branch), driven by the REPO_FIELDS
// descriptor list, with a per-field validation error under owner and repo.
// Presentational — the parent ConnectionEditor holds the config state and
// receives edits via onChange, and computes the errors. Parallel to
// SiteDetailsFields.
import type { RepoTarget } from '../../lib/githubCommit';
import { REPO_FIELDS, type CmsConfigErrors } from '../../lib/configEditor';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';
import { errorTextStyle } from './connectionEditorStyles';

interface Props {
  repo: RepoTarget;
  errors: CmsConfigErrors;
  onChange: (name: keyof RepoTarget, value: string) => void;
}

export default function ConnectionRepoFields({ repo, errors, onChange }: Props) {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      {REPO_FIELDS.map((field) => {
        const err = field.name === 'owner' ? errors.owner : field.name === 'repo' ? errors.repo : undefined;
        return (
          <div key={field.name}>
            <label style={fieldLabelStyle} htmlFor={`cms-${field.name}`}>
              {field.label}
              {!field.required && (
                <span style={{ color: 'var(--color-muted)', fontWeight: 400 }}> (optional)</span>
              )}
            </label>
            <input
              id={`cms-${field.name}`}
              type="text"
              value={repo[field.name] ?? ''}
              placeholder={field.placeholder}
              onChange={(e) => onChange(field.name, e.target.value)}
              style={fieldInputStyle}
            />
            {err && <p style={errorTextStyle}>{err}</p>}
          </div>
        );
      })}
    </section>
  );
}
