// One editable dropdown child row: a grip handle, a label + URL input, and the
// up/down/remove controls, indented under its parent nav item. Draggable — it can
// be reordered within its dropdown, promoted to a top-level item, or moved to
// another dropdown, all via the shared `useNavDrag` props the parent NavItemRow
// threads in. Presentational — the parent owns the children list and forwards
// patch/move/remove intents keyed by this child's index.
import type { HTMLAttributes } from 'react';
import type { NavItem } from '../../lib/siteConfig';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';
import { dragRowStyle } from './configEditorStyles';
import RowControls from './RowControls';
import DragHandle from './DragHandle';

interface Props {
  child: NavItem;
  /** Parent item index and this child's index — used to build unique input ids. */
  parentIndex: number;
  index: number;
  isFirst: boolean;
  isLast: boolean;
  onChange: (patch: Partial<NavItem>) => void;
  onMove: (delta: number) => void;
  onRemove: () => void;
  /** Drag-reorder / re-nest wiring from `useNavDrag`. Defaulted so a standalone
   * render (component scenarios) still shows the grip without a live session. */
  rowDragProps?: HTMLAttributes<HTMLElement>;
  handleProps?: HTMLAttributes<HTMLSpanElement>;
  isDragging?: boolean;
  isDropTarget?: boolean;
}

export default function NavChildRow({
  child,
  parentIndex,
  index,
  isFirst,
  isLast,
  onChange,
  onMove,
  onRemove,
  rowDragProps,
  handleProps,
  isDragging = false,
  isDropTarget = false,
}: Props) {
  return (
    <div
      style={{
        display: 'flex',
        gap: 'var(--space-sm)',
        alignItems: 'flex-end',
        flexWrap: 'wrap',
        ...dragRowStyle(isDragging, isDropTarget),
      }}
      {...rowDragProps}
    >
      <DragHandle label="Drag to reorder sub-item" {...handleProps} />
      <div style={{ flex: '1 1 7rem' }}>
        <label style={fieldLabelStyle} htmlFor={`nav-${parentIndex}-child-label-${index}`}>
          Label
        </label>
        <input
          id={`nav-${parentIndex}-child-label-${index}`}
          type="text"
          value={child.label}
          placeholder="Upcoming"
          onChange={(e) => onChange({ label: e.target.value })}
          style={fieldInputStyle}
        />
      </div>
      <div style={{ flex: '2 1 11rem' }}>
        <label style={fieldLabelStyle} htmlFor={`nav-${parentIndex}-child-url-${index}`}>
          URL
        </label>
        <input
          id={`nav-${parentIndex}-child-url-${index}`}
          type="text"
          value={child.url ?? ''}
          placeholder="/events"
          onChange={(e) => onChange({ url: e.target.value })}
          style={fieldInputStyle}
        />
      </div>
      <RowControls
        canUp={!isFirst}
        canDown={!isLast}
        onUp={() => onMove(-1)}
        onDown={() => onMove(1)}
        onRemove={onRemove}
        removeLabel="Remove sub-item"
      />
    </div>
  );
}
