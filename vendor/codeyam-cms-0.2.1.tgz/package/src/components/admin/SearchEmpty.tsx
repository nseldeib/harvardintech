// The "nothing matched" state shared by both admin searches: a muted message
// naming the query the editor typed, plus a Clear control that resets the search
// back to the full list. Presentational — the parent island owns the query and
// the reset.
import type { CSSProperties } from 'react';

const boxStyle: CSSProperties = {
  background: 'var(--color-bg)',
  border: '1px dashed var(--color-border)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-lg)',
  color: 'var(--color-muted)',
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-sm)',
  flexWrap: 'wrap',
};

const clearStyle: CSSProperties = {
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-accent)',
  cursor: 'pointer',
  borderRadius: 'var(--radius)',
  padding: '0.3rem 0.7rem',
  font: 'inherit',
  fontWeight: 600,
};

interface Props {
  query: string;
  onClear: () => void;
}

export default function SearchEmpty({ query, onClear }: Props) {
  return (
    <div style={boxStyle} role="status">
      <span>
        No entries match “{query}”.
      </span>
      <button type="button" onClick={onClear} style={clearStyle}>
        Clear
      </button>
    </div>
  );
}
