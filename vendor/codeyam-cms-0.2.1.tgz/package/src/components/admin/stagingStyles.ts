// Shared inline styles for the staging bar, review drawer, and diff cards, so
// the pill and drawer read as one system and button styling isn't duplicated
// across the three components. Plain data (no JSX), safe to import anywhere.
import type { CSSProperties } from 'react';

export const diffColor: Record<string, string> = {
  add: '#166534',
  remove: '#991b1b',
  context: 'var(--color-muted)',
};
export const diffBg: Record<string, string> = {
  add: '#dcfce7',
  remove: '#fee2e2',
  context: 'transparent',
};

export const barStyle: CSSProperties = {
  position: 'fixed',
  left: '50%',
  bottom: 'var(--space-lg)',
  transform: 'translateX(-50%)',
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-md)',
  background: 'var(--color-accent)',
  color: '#fff',
  padding: '0.6rem 1.1rem',
  borderRadius: '999px',
  boxShadow: '0 6px 24px rgba(0,0,0,0.18)',
  zIndex: 50,
};
export const primaryBtn: CSSProperties = {
  padding: '0.4rem 0.9rem',
  borderRadius: 'var(--radius)',
  border: 'none',
  background: '#fff',
  color: 'var(--color-accent)',
  fontWeight: 700,
  cursor: 'pointer',
};
// An accent-FILLED primary button for light surfaces (the Publish page), where
// the pill's white-on-accent `primaryBtn` would vanish. Disabled state dims it.
export const accentBtn: CSSProperties = {
  padding: '0.5rem 1.1rem',
  borderRadius: 'var(--radius)',
  border: 'none',
  background: 'var(--color-accent)',
  color: '#fff',
  fontWeight: 700,
  cursor: 'pointer',
};
export const ghostBtn: CSSProperties = {
  padding: '0.35rem 0.8rem',
  borderRadius: 'var(--radius)',
  border: '1px solid rgba(255,255,255,0.6)',
  background: 'transparent',
  color: '#fff',
  cursor: 'pointer',
};
export const ghostBtnDark: CSSProperties = {
  padding: '0.35rem 0.8rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-fg)',
  cursor: 'pointer',
};
export const overlayStyle: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(0,0,0,0.4)',
  display: 'flex',
  alignItems: 'flex-end',
  justifyContent: 'center',
  zIndex: 60,
};
export const drawerStyle: CSSProperties = {
  background: 'var(--color-bg)',
  width: '100%',
  maxWidth: '720px',
  borderRadius: 'var(--radius) var(--radius) 0 0',
  padding: 'var(--space-lg)',
  maxHeight: '85vh',
  overflowY: 'auto',
};

// Drift warning: the amber surface shown when the pre-commit freshness check
// found that the branch moved underneath a staged change. Amber rather than the
// red error palette on purpose — nothing has gone wrong and nothing is lost;
// the commit was held back and needs a decision. Shared by DriftNotice and its
// two children so the notice reads as one block.
export const driftNoticeStyle: CSSProperties = {
  border: '1px solid #fcd34d',
  background: '#fffbeb',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-md)',
  margin: 'var(--space-md) 0 0',
};
export const driftEntryStyle: CSSProperties = {
  borderTop: '1px solid #fde68a',
  paddingTop: 'var(--space-sm)',
  marginTop: 'var(--space-sm)',
};
/** A quieter, smaller button for the per-entry safe actions. */
export const driftEntryBtn: CSSProperties = {
  ...ghostBtnDark,
  borderColor: '#d97706',
  color: '#92400e',
  fontSize: '0.8rem',
  padding: '0.25rem 0.7rem',
};
/** The overwrite: deliberately plain text-on-transparent so it never reads as
 * the button to press. It is the one action that loses someone else's work. */
export const driftOverwriteBtn: CSSProperties = {
  border: 'none',
  background: 'transparent',
  color: '#92400e',
  textDecoration: 'underline',
  fontSize: '0.8rem',
  cursor: 'pointer',
  padding: 0,
};

// Deploy-pipeline stepper: a vertical list of stages the commit passes through
// (Committed → Build queued → Building → Live), each a status dot + label. The
// dot colour and glyph encode the stage's state so the whole pipeline reads at a
// glance: done (green ✓), active (accent, pulsing), pending (muted), failed (red ✕).
export const stepListStyle: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-md)',
  margin: 'var(--space-lg) 0',
  padding: 0,
  listStyle: 'none',
};
export const stepRowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-md)',
};
export const stepDotBase: CSSProperties = {
  flex: '0 0 auto',
  width: '1.6rem',
  height: '1.6rem',
  borderRadius: '999px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontSize: '0.9rem',
  fontWeight: 700,
  lineHeight: 1,
};
export const stepDot: Record<'done' | 'active' | 'pending' | 'failed', CSSProperties> = {
  done: { ...stepDotBase, background: '#dcfce7', color: '#166534' },
  active: { ...stepDotBase, background: 'var(--color-accent)', color: '#fff' },
  pending: { ...stepDotBase, background: 'var(--color-border)', color: 'var(--color-muted)' },
  failed: { ...stepDotBase, background: '#fee2e2', color: '#991b1b' },
};
export const stepLabel: Record<'done' | 'active' | 'pending' | 'failed', CSSProperties> = {
  done: { color: 'var(--color-fg)', fontWeight: 600 },
  active: { color: 'var(--color-fg)', fontWeight: 700 },
  pending: { color: 'var(--color-muted)' },
  failed: { color: '#991b1b', fontWeight: 700 },
};
export const linkBtn: CSSProperties = {
  color: 'var(--color-accent)',
  textDecoration: 'underline',
  fontSize: '0.85rem',
};
// The accent "View live site" call-to-action on a successful deploy.
export const liveLinkBtn: CSSProperties = {
  display: 'inline-block',
  padding: '0.5rem 1.1rem',
  borderRadius: 'var(--radius)',
  background: 'var(--color-accent)',
  color: '#fff',
  fontWeight: 700,
  textDecoration: 'none',
};
