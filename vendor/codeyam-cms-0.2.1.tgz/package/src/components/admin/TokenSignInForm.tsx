// The paste-a-token sign-in form — the server-free path, extracted from AuthGate
// so the gate composes it rather than inlining the form. Owns the token input
// state and the form submit; delegates the actual sign-in to `onSubmit` (the gate
// wires that to the authSession store, or to a scenario/test seam). The helper
// text links to GitHub's token page and names the exact scope + repo, so setting
// up a server-free site is unambiguous.
import { useState } from 'react';
import type { RepoTarget } from '../../lib/githubCommit';
import { signInBtn, tokenForm, tokenHelp, tokenHelpLink, tokenInput, tokenLabel } from './authStyles';

// GitHub's fine-grained personal access token creation page. Scopes can't be
// prefilled via URL, so the helper text spells out exactly what to grant.
const NEW_TOKEN_URL = 'https://github.com/settings/personal-access-tokens/new';

interface Props {
  /** The publish target — named in the helper so editors scope the token right. */
  repo: RepoTarget;
  /** Disable the field + button while a sign-in is resolving. */
  disabled: boolean;
  /** Scenario/test seam: pre-fill the token input. */
  initialToken?: string;
  /**
   * Hand the entered token up to the gate to validate + sign in. Optional so an
   * isolated-component scenario can render the form without wiring a handler
   * (Astro can't serialize a function across the island boundary); in the gate
   * it is always supplied.
   */
  onSubmit?: (token: string) => void | Promise<void>;
}

export default function TokenSignInForm({ repo, disabled, initialToken, onSubmit }: Props) {
  const [token, setToken] = useState<string>(initialToken ?? '');

  return (
    <form
      style={tokenForm}
      onSubmit={(e) => {
        e.preventDefault();
        void onSubmit?.(token);
      }}
    >
      <label style={tokenLabel} htmlFor="cms-token">
        GitHub token
      </label>
      <input
        id="cms-token"
        type="password"
        style={tokenInput}
        value={token}
        onChange={(e) => setToken(e.target.value)}
        placeholder="github_pat_…"
        autoComplete="off"
        spellCheck={false}
        disabled={disabled}
        aria-label="GitHub token"
      />
      <button type="submit" style={signInBtn} disabled={disabled}>
        {disabled ? 'Signing in…' : 'Sign in'}
      </button>
      <p style={tokenHelp}>
        No server needed — your token stays in this browser.{' '}
        <a href={NEW_TOKEN_URL} target="_blank" rel="noreferrer" style={tokenHelpLink}>
          Create a token
        </a>{' '}
        with <strong>Contents: Read &amp; Write</strong> on{' '}
        <code>
          {repo.owner}/{repo.repo}
        </code>
        , then paste it above.
      </p>
    </form>
  );
}
