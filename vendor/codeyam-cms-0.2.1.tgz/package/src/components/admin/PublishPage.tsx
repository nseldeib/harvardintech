// The Publish page island (/admin/publish). The dedicated home for the
// accumulate-then-commit flow: unlike the floating StagingBar it is always
// reachable, so it hosts a proper resting state and a grouped, per-area review
// instead of a flat diff drawer.
//
// Three states, driven by the browser staging set:
//   • pending changes → a grouped review list (ChangeGroup per area) + a single
//     "Publish N changes" action that commits them all as ONE commit;
//   • committing/deploying → the live GitHub Pages stepper (the shared
//     DeployStatus, reused unchanged);
//   • nothing staged → PublishEmptyState with the last successful deploy.
//
// Both the commit and deploy transports are injected (defaulting to the real
// GitHub-token paths) so isolated-component scenarios and unit tests drive every
// state deterministically without a live repo — the same pattern StagingBar uses.
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  buildCommitMessage,
  changesToWrites,
  changesToDeletes,
  commitAll,
  isStaleBaselineError,
  type CommitResult,
  type FetchFn,
  type RepoTarget,
} from '../../lib/githubCommit';
import {
  pollDeploy,
  fetchLastDeploy,
  readDeployBaseline,
  type DeployBaseline,
  type DeployState,
  type LastDeploy,
} from '../../lib/githubPages';
import { ensureGithubToken } from '../../lib/githubAuth';
import { markExpired } from '../../lib/authSession';
import { groupPendingChanges, type PendingChange } from '../../lib/pendingChanges';
import {
  loadChanges,
  discardChange,
  clearChanges,
  reloadChangeBaseline,
  subscribe,
} from '../../lib/pendingChangesStore';
import type { DriftedChange } from '../../lib/staleCheck';
import type { ChecklistContext } from '../../lib/publishChecklist';
import type { CommitFn, DeployFn } from './StagingBar';
import PublishHeader from './PublishHeader';
import ChangeGroupList from './ChangeGroupList';
import PublishChecklist from './PublishChecklist';
import PublishActions from './PublishActions';
import PublishEmptyState from './PublishEmptyState';
import DriftNotice from './DriftNotice';
import DeployStatus from './DeployStatus';

type Phase = 'idle' | 'committing' | 'error' | 'deploying';

interface Props {
  repo: RepoTarget;
  authEndpoint: string;
  /** Human labels for content collections (the singleton areas label themselves). */
  areaLabels?: Record<string, string>;
  /** Override the commit transport (scenarios / tests). Defaults to real GitHub. */
  commit?: CommitFn;
  /** Override the deploy-watch transport (scenarios / tests). Defaults to polling Pages. */
  deploy?: DeployFn;
  /** Override the last-deploy lookup (scenarios / tests). Defaults to querying Pages. */
  loadLastDeploy?: () => Promise<LastDeploy | null>;
  /** Seed the staging set for isolated-component scenarios / tests. */
  initialChanges?: PendingChange[];
  /** Facts the pre-publish checklist resolves against (known pages, media
   * manifest, site description). When provided, the advisory checklist renders
   * above the Publish action; omitted → no checklist (backwards-compatible). */
  checklist?: ChecklistContext;
  /** Seed the resting-state last deploy. `null` = known "no deploys yet";
   * omitted = fetch it live. */
  lastDeploy?: LastDeploy | null;
  /** Open directly into a phase (e.g. `deploying`) for scenario capture. */
  initialPhase?: Phase;
  /** Seed the commit-error message alongside `initialPhase: 'error'` — without
   * it an errored scenario renders the phase but no message. */
  initialError?: string;
  /** Seed the drift warning for isolated-component scenarios / tests, without
   * needing a live co-editor to race against. */
  initialDrifted?: DriftedChange[];
}

export default function PublishPage({
  repo,
  authEndpoint,
  areaLabels,
  commit,
  deploy,
  loadLastDeploy,
  initialChanges,
  checklist,
  lastDeploy: seededLastDeploy,
  initialPhase = 'idle',
  initialError = '',
  initialDrifted,
}: Props) {
  const [changes, setChanges] = useState<PendingChange[]>(initialChanges ?? []);
  const [phase, setPhase] = useState<Phase>(initialPhase);
  const [result, setResult] = useState<CommitResult | null>(null);
  const [error, setError] = useState<string>(initialError);
  const [drifted, setDrifted] = useState<DriftedChange[]>(initialDrifted ?? []);
  const [deployState, setDeployState] = useState<DeployState>({ stage: 'committed' });
  const [deployNonce, setDeployNonce] = useState(0);
  // `undefined` = not yet loaded; `null` = known "no deploys"; object = known deploy.
  const [lastDeploy, setLastDeploy] = useState<LastDeploy | null | undefined>(seededLastDeploy);
  const [lastDeployLoading, setLastDeployLoading] = useState(false);
  // The site's deploy marker as it read BEFORE this publish. See StagingBar for
  // why this is a ref rather than state.
  const deployBaseline = useRef<DeployBaseline | null>(null);

  useEffect(() => {
    if (initialChanges) return; // seeded scenario — stay on the injected set
    const sync = () => setChanges(loadChanges());
    sync();
    return subscribe(sync);
  }, [initialChanges]);

  const committer: CommitFn = useMemo(() => {
    if (commit) return commit;
    return async (writes, message, deletes = [], options) => {
      const token = await ensureGithubToken(authEndpoint);
      try {
        return await commitAll(writes, message, repo, token, globalThis.fetch as unknown as FetchFn, deletes, options);
      } catch (e) {
        // A drift refusal is the check working, not a bad token — leave the
        // session alone so the editor can resolve and retry in place.
        if (isStaleBaselineError(e)) throw e;
        // A stale/insufficient token shouldn't be reused: expire the session so
        // the sign-in gate re-shows. Staged edits survive (localStorage).
        markExpired();
        throw e;
      }
    };
  }, [commit, authEndpoint, repo]);

  const deployer: DeployFn = useMemo(() => {
    if (deploy) return deploy;
    return async (_commit, onUpdate) => {
      const token = await ensureGithubToken(authEndpoint);
      return pollDeploy(repo, token, globalThis.fetch as unknown as FetchFn, onUpdate, {
        ...(deployBaseline.current ?? {}),
      });
    };
  }, [deploy, authEndpoint, repo]);

  const lastDeployLoader = useMemo(() => {
    if (loadLastDeploy) return loadLastDeploy;
    return async () => {
      const token = await ensureGithubToken(authEndpoint);
      return fetchLastDeploy(repo, token, globalThis.fetch as unknown as FetchFn);
    };
  }, [loadLastDeploy, authEndpoint, repo]);

  // Look up the last deploy for the resting state — only when there is nothing
  // to publish, it wasn't seeded, and we aren't mid-deploy. A lookup failure is
  // non-fatal: fall back to the "no deploys yet" copy rather than block the page.
  useEffect(() => {
    if (seededLastDeploy !== undefined) return;
    if (changes.length > 0 || phase === 'deploying' || lastDeploy !== undefined || lastDeployLoading) return;
    let live = true;
    setLastDeployLoading(true);
    lastDeployLoader()
      .then((d) => {
        if (live) setLastDeploy(d);
      })
      .catch(() => {
        if (live) setLastDeploy(null);
      })
      .finally(() => {
        if (live) setLastDeployLoading(false);
      });
    return () => {
      live = false;
    };
  }, [seededLastDeploy, changes.length, phase, lastDeploy, lastDeployLoading, lastDeployLoader]);

  // Drive the deploy watch whenever we (re-)enter the deploying phase.
  useEffect(() => {
    if (phase !== 'deploying' || !result) return;
    let live = true;
    setDeployState({ stage: 'committed' });
    deployer(result, (state) => {
      if (live) setDeployState(state);
    }).catch(() => {
      if (live) setDeployState({ stage: 'failed', error: 'Could not reach GitHub Pages to check the build.' });
    });
    return () => {
      live = false;
    };
  }, [phase, result, deployNonce, deployer]);

  const groups = useMemo(() => groupPendingChanges(changes, areaLabels), [changes, areaLabels]);

  // `overwriteDrift` is the deliberate override behind "Publish anyway" — the
  // ordinary path always passes the staged changes so `commitAll` checks them.
  const onPublish = async (overwriteDrift = false) => {
    setPhase('committing');
    setError('');
    // Sample the served marker BEFORE the commit — see StagingBar.onCommit.
    deployBaseline.current = await readDeployBaseline(repo, globalThis.fetch as unknown as FetchFn);
    try {
      const res = await committer(changesToWrites(changes), buildCommitMessage(changes), changesToDeletes(changes), {
        changes,
        overwriteDrift,
      });
      clearChanges();
      setDrifted([]);
      setResult(res);
      setPhase('deploying');
    } catch (e) {
      if (isStaleBaselineError(e)) {
        setDrifted(e.drifted);
        setError('');
        setPhase('idle');
        return;
      }
      setDrifted([]);
      setError(e instanceof Error ? e.message : String(e));
      setPhase('error');
    }
  };

  // Resolving an entry clears it from the warning: whatever is left is what
  // still needs attention, and an empty list means publishing can be retried.
  const resolveDrift = (path: string) => setDrifted((d) => d.filter((x) => x.path !== path));

  const onDiscardDrift = (path: string) => {
    discardChange(path);
    resolveDrift(path);
  };

  const onReloadDrift = (drift: DriftedChange) => {
    reloadChangeBaseline(drift);
    resolveDrift(drift.path);
  };

  const onDeployClose = () => {
    // After a deploy resolves, drop back to the (now empty) resting state and
    // re-check the last deploy so the summary reflects what we just published.
    setPhase('idle');
    setResult(null);
    setLastDeploy(seededLastDeploy);
  };

  const committing = phase === 'committing';

  return (
    <section>
      <PublishHeader />

      {changes.length === 0 ? (
        <PublishEmptyState repo={repo} lastDeploy={lastDeploy} loading={lastDeployLoading} />
      ) : (
        <>
          <ChangeGroupList groups={groups} committing={committing} onDiscard={discardChange} />
          {checklist && <PublishChecklist changes={changes} context={checklist} />}
          <DriftNotice
            drifted={drifted}
            busy={committing}
            onDiscard={onDiscardDrift}
            onReload={onReloadDrift}
            onOverwrite={() => onPublish(true)}
          />
          <PublishActions
            repo={repo}
            count={changes.length}
            committing={committing}
            errored={phase === 'error'}
            error={error}
            blocked={drifted.length > 0}
            onPublish={() => onPublish()}
          />
        </>
      )}

      {phase === 'deploying' && result && (
        <DeployStatus
          repo={repo}
          commitUrl={result.commitUrl}
          state={deployState}
          onRetry={() => setDeployNonce((n) => n + 1)}
          onClose={onDeployClose}
        />
      )}
    </section>
  );
}
