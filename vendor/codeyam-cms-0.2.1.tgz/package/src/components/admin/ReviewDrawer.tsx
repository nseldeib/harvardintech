// The review drawer: a bottom-sheet overlay listing every staged change as a
// ChangeDiffCard, with the commit target line and the Cancel / Commit-all
// footer. Presentational + interaction-forwarding — the parent StagingBar owns
// the staging set, the commit phase, and the actual commit; this renders the
// review of it and forwards close / discard / commit intents.
import type { PendingChange } from '../../lib/pendingChanges';
import type { RepoTarget } from '../../lib/githubCommit';
import type { DriftedChange } from '../../lib/staleCheck';
import ChangeDiffCard from './ChangeDiffCard';
import CommitErrorNotice from './CommitErrorNotice';
import DriftNotice from './DriftNotice';
import { overlayStyle, drawerStyle, primaryBtn, ghostBtnDark } from './stagingStyles';

export type DrawerPhase = 'reviewing' | 'committing' | 'error';

interface Props {
  repo: RepoTarget;
  changes: PendingChange[];
  phase: DrawerPhase;
  error: string;
  /** Staged changes the branch moved underneath. Non-empty → the commit was
   * refused and the drift warning replaces the ordinary commit affordance. */
  drifted?: DriftedChange[];
  onClose: () => void;
  onDiscard: (path: string) => void;
  onCommit: () => void;
  onDiscardDrift?: (path: string) => void;
  onReloadDrift?: (drift: DriftedChange) => void;
  onOverwriteDrift?: () => void;
}

export default function ReviewDrawer({
  repo,
  changes,
  phase,
  error,
  drifted = [],
  onClose,
  onDiscard,
  onCommit,
  onDiscardDrift,
  onReloadDrift,
  onOverwriteDrift,
}: Props) {
  const committing = phase === 'committing';
  const blocked = drifted.length > 0;

  return (
    <div style={overlayStyle} onClick={() => !committing && onClose()}>
      <div style={drawerStyle} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-md)' }}>
          <h2 style={{ margin: 0, fontSize: '1.15rem' }}>Pending changes</h2>
          <button type="button" onClick={onClose} disabled={committing} style={ghostBtnDark}>
            Close
          </button>
        </div>

        <p style={{ margin: '0 0 var(--space-md)', color: 'var(--color-muted)', fontSize: '0.85rem' }}>
          Committing to <strong>{repo.owner}/{repo.repo}</strong> on <strong>{repo.branch}</strong> — one commit,{' '}
          {changes.length} {changes.length === 1 ? 'file' : 'files'}.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)', maxHeight: '50vh', overflowY: 'auto' }}>
          {changes.map((change) => (
            <ChangeDiffCard key={change.path} change={change} disabled={committing} onDiscard={onDiscard} />
          ))}
        </div>

        {blocked && (
          <DriftNotice
            drifted={drifted}
            busy={committing}
            onDiscard={onDiscardDrift ?? onDiscard}
            onReload={onReloadDrift ?? (() => {})}
            onOverwrite={onOverwriteDrift ?? onCommit}
          />
        )}

        {phase === 'error' && <CommitErrorNotice message={error} />}

        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-md)', marginTop: 'var(--space-lg)' }}>
          <button type="button" onClick={onClose} disabled={committing} style={ghostBtnDark}>
            Cancel
          </button>
          <button
            type="button"
            onClick={onCommit}
            disabled={committing || changes.length === 0 || blocked}
            style={blocked ? { ...primaryBtn, opacity: 0.5, cursor: 'not-allowed' } : primaryBtn}
          >
            {committing
              ? 'Committing…'
              : blocked
                ? 'Resolve the entries above'
                : phase === 'error'
                  ? 'Retry commit'
                  : `Commit all ${changes.length}`}
          </button>
        </div>
      </div>
    </div>
  );
}
