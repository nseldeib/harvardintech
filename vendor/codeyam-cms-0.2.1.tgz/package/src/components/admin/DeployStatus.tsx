// The in-drawer deploy view. Once "Commit all" lands the commit, the review
// drawer stops showing the diff list and shows THIS instead — the same overlay +
// drawer shell, transformed in place into a live status of the GitHub Pages
// pipeline the commit kicked off:
//
//   Committed → Build queued → Building → Live      (or → Failed)
//
// Presentational + intent-forwarding: the parent StagingBar owns the polling and
// feeds the current `DeployState` down; this renders the stepper, the commit
// link, the "View live site" call-to-action on success, and the log link + retry
// on failure. Driving it from a plain `state` prop (not an internal poll) is what
// lets an isolated-component scenario capture any single stage deterministically.
import {
  deploySteps,
  deploySubhead,
  isTerminalStage,
  pagesLogUrl,
  pagesSiteUrl,
  type DeployState,
} from '../../lib/githubPages';
import type { RepoTarget } from '../../lib/githubCommit';
import DeployStep from './DeployStep';
import { overlayStyle, drawerStyle, ghostBtnDark, primaryBtn, linkBtn, liveLinkBtn, stepListStyle } from './stagingStyles';

interface Props {
  repo: RepoTarget;
  /** Human URL of the commit that kicked off this deploy. */
  commitUrl: string;
  state: DeployState;
  /** Live-site URL override (a custom domain from settings); defaults to the github.io URL. */
  siteUrl?: string;
  /** Re-check the build after a failure. Optional so isolated scenarios render statically. */
  onRetry?: () => void;
  /** Dismiss the drawer once terminal. Optional so isolated scenarios render statically. */
  onClose?: () => void;
}

export default function DeployStatus({ repo, commitUrl, state, siteUrl, onRetry, onClose }: Props) {
  const failed = state.stage === 'failed';
  const live = state.stage === 'live';
  const terminal = isTerminalStage(state.stage);
  const steps = deploySteps(state.stage);

  const heading = failed ? 'Publish failed' : live ? 'Your site is live' : 'Publishing…';
  const subhead = deploySubhead(state.stage, repo);

  return (
    <div style={overlayStyle} onClick={() => terminal && onClose?.()}>
      <div style={drawerStyle} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ margin: 0, fontSize: '1.15rem' }}>{heading}</h2>
          <a href={commitUrl} target="_blank" rel="noreferrer" style={linkBtn}>
            View commit
          </a>
        </div>

        <p style={{ margin: 'var(--space-sm) 0 0', color: 'var(--color-muted)', fontSize: '0.85rem' }}>{subhead}</p>

        <ul style={stepListStyle}>
          {steps.map((step) => (
            <DeployStep key={step.stage} label={step.label} visual={step.visual} />
          ))}
        </ul>

        {failed && (
          <p
            style={{
              color: '#991b1b',
              background: '#fee2e2',
              padding: 'var(--space-sm) var(--space-md)',
              borderRadius: 'var(--radius)',
              margin: '0 0 var(--space-md)',
              fontSize: '0.85rem',
            }}
          >
            {state.error || 'The GitHub Pages build errored.'}
          </p>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 'var(--space-md)' }}>
          {failed && (
            <a href={pagesLogUrl(repo)} target="_blank" rel="noreferrer" style={linkBtn}>
              View build log
            </a>
          )}
          {failed && (
            <button type="button" onClick={() => onRetry?.()} style={primaryBtn}>
              Retry
            </button>
          )}
          {live && (
            <a href={siteUrl || pagesSiteUrl(repo)} target="_blank" rel="noreferrer" style={liveLinkBtn}>
              View live site →
            </a>
          )}
          <button type="button" onClick={() => onClose?.()} disabled={!terminal} style={ghostBtnDark}>
            {terminal ? 'Done' : 'Working…'}
          </button>
        </div>
      </div>
    </div>
  );
}
