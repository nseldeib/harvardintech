// One row in the entry version-history list: a revision's subject, its author
// and time, and a trailing affordance — a "Current" badge for the newest
// version, or a "View" button for an earlier one the editor can open. Purely
// presentational; the parent (EntryHistory) owns the list and the open action.
import { formatRevisionTime, type EntryRevision } from '../../lib/githubHistory';
import { revisionRowStyle, historyGhostBtn, currentBadgeStyle } from './historyStyles';

interface Props {
  revision: EntryRevision;
  /** The newest version — shows a "Current" badge instead of a View action. */
  current?: boolean;
  /** Open this (earlier) revision in the read-only viewer. */
  onView?: (revision: EntryRevision) => void;
}

export default function RevisionRow({ revision, current = false, onView }: Props) {
  const when = formatRevisionTime(revision.date);
  return (
    <div style={revisionRowStyle}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.15rem' }}>
        <strong style={{ fontSize: '0.92rem', fontWeight: current ? 700 : 500 }}>{revision.subject}</strong>
        <span style={{ fontSize: '0.8rem', color: 'var(--color-muted)' }}>
          {revision.authorName}
          {when ? ` · ${when}` : ''}
        </span>
      </div>
      {current ? (
        <span style={currentBadgeStyle}>Current</span>
      ) : (
        onView && (
          <span style={{ marginLeft: 'auto' }}>
            <button type="button" style={historyGhostBtn} onClick={() => onView(revision)}>
              View
            </button>
          </span>
        )
      )}
    </div>
  );
}
