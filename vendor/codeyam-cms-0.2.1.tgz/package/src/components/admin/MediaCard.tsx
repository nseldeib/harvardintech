// One image tile in the media gallery / picker. Presentational: it renders a
// thumbnail, the filename, and a size/dimension detail line, and forwards a
// click. Optional badges mark an asset that's currently selected (the cover
// choice) or freshly uploaded-but-not-yet-committed (staged), and an optional
// action slot hosts a Remove / Select button supplied by the parent.
import type { CSSProperties, HTMLAttributes, ReactNode } from 'react';
import type { MediaAsset } from '../../lib/mediaLibrary';
import { dragRowStyle } from './configEditorStyles';
import DragHandle from './DragHandle';
import MediaCardLabel from './MediaCardLabel';
import { withBase } from '../../lib/adminUrl';

interface Props {
  asset: MediaAsset;
  /** Highlight as the active choice (e.g. the current cover image). */
  selected?: boolean;
  /** Mark as uploaded this session but not yet committed. */
  staged?: boolean;
  /** Optional click handler for pick-to-use flows. */
  onClick?: () => void;
  /** Optional footer action (Select / Remove) rendered under the detail line. */
  action?: ReactNode;
  /** Drag-reorder wiring from `useListDrag` (absent = no drag, e.g. the picker). */
  rowDragProps?: HTMLAttributes<HTMLElement>;
  handleProps?: HTMLAttributes<HTMLSpanElement>;
  isDragging?: boolean;
  isDropTarget?: boolean;
}

const cardStyle = (selected: boolean, clickable: boolean): CSSProperties => ({
  border: `1px solid ${selected ? 'var(--color-accent)' : 'var(--color-border)'}`,
  outline: selected ? '1px solid var(--color-accent)' : 'none',
  borderRadius: 'var(--radius)',
  overflow: 'hidden',
  background: 'var(--color-bg)',
  display: 'flex',
  flexDirection: 'column',
  cursor: clickable ? 'pointer' : 'default',
  textAlign: 'left',
  padding: 0,
  font: 'inherit',
  color: 'var(--color-fg)',
});

const thumbWrapStyle: CSSProperties = {
  position: 'relative',
  aspectRatio: '4 / 3',
  background: 'var(--color-surface, #f1f1f6)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
};

const badgeStyle = (bg: string): CSSProperties => ({
  position: 'absolute',
  top: '0.4rem',
  right: '0.4rem',
  background: bg,
  color: '#fff',
  fontSize: '0.65rem',
  fontWeight: 700,
  letterSpacing: '0.02em',
  textTransform: 'uppercase',
  padding: '0.15rem 0.4rem',
  borderRadius: '4px',
});

export default function MediaCard({
  asset,
  selected = false,
  staged = false,
  onClick,
  action,
  rowDragProps,
  handleProps,
  isDragging = false,
  isDropTarget = false,
}: Props) {
  const clickable = typeof onClick === 'function';
  const Tag = clickable ? 'button' : 'div';
  return (
    <Tag
      {...(clickable ? { type: 'button' as const, onClick } : {})}
      {...(rowDragProps ?? {})}
      style={{ ...cardStyle(selected, clickable), ...dragRowStyle(isDragging, isDropTarget) }}
    >
      <div style={thumbWrapStyle}>
        <img
          src={withBase(asset.url)}
          alt={asset.alt ?? asset.filename}
          loading="lazy"
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
        {handleProps && (
          <DragHandle
            label="Drag to reorder image"
            {...handleProps}
            style={{
              position: 'absolute',
              top: '0.4rem',
              left: '0.4rem',
              width: '1.6rem',
              height: '1.6rem',
              alignSelf: 'auto',
              background: 'rgba(0,0,0,0.55)',
              color: '#fff',
              borderRadius: '4px',
            }}
          />
        )}
        {staged && <span style={badgeStyle('var(--color-accent)')}>New</span>}
        {selected && !staged && <span style={badgeStyle('#16a34a')}>Selected</span>}
      </div>
      <div style={{ padding: '0.5rem 0.6rem', display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
        <MediaCardLabel asset={asset} />
        {action}
      </div>
    </Tag>
  );
}
