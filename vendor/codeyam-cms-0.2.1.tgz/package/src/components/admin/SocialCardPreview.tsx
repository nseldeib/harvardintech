// The live share-card preview: how the entry looks when its URL is pasted into
// X / Facebook / LinkedIn. A generic large-image card (image on top, then domain
// · title · description) driven by the entry's EFFECTIVE SEO metadata — the
// override-or-fallback chain resolved by `socialCard.ts`, the same one the
// rendered page's <head> emits. Pure/presentational: the parent EntryEditor owns
// the values and re-renders this on every keystroke, so an editor sees the card
// change as they type an override.
import { useMemo } from 'react';
import type { CollectionName } from '../../lib/adminDashboard';
import { asStr, previewTitle } from '../../lib/entryPreview';
import { entryPublicUrl } from '../../lib/publicUrl';
import type { RawFieldValue } from '../../lib/entryEditor';
import {
  effectiveSeo,
  overridesFromValues,
  truncate,
  cardDomain,
  CARD_TITLE_MAX,
  CARD_DESCRIPTION_MAX,
} from '../../lib/socialCard';
import { withBase } from '../../lib/adminUrl';

interface Props {
  collection: CollectionName;
  slug: string;
  values: Record<string, RawFieldValue>;
  /** The collection's designated label field, so a custom collection titles the
   * card by its own field. */
  labelField?: string;
  /** Site defaults from `settings.json` — the last-resort fallbacks. */
  siteTitle?: string;
  siteDescription?: string;
  /** Configured public base URL (`settings.siteUrl`); blank until the editor sets it. */
  siteUrl?: string;
}

export default function SocialCardPreview({
  collection,
  slug,
  values,
  labelField,
  siteTitle = '',
  siteDescription = '',
  siteUrl = '',
}: Props) {
  const seo = useMemo(() => {
    const title = previewTitle(values, labelField);
    return effectiveSeo(overridesFromValues(values), {
      // A placeholder ("Untitled") title is treated as absent so the card falls
      // back to the site title rather than showing the placeholder.
      entryTitle: title.placeholder ? '' : title.text,
      entryDescription: asStr(values.summary) || asStr(values.description),
      entryImage: asStr(values.coverImage) || asStr(values.photo),
      siteTitle,
      siteDescription,
      pageUrl: entryPublicUrl(siteUrl, collection, slug),
    });
  }, [values, labelField, siteTitle, siteDescription, siteUrl, collection, slug]);

  const domain = cardDomain(seo.canonicalUrl) || 'your-site.com';
  const title = truncate(seo.title, CARD_TITLE_MAX) || 'Untitled';
  const description = truncate(seo.description, CARD_DESCRIPTION_MAX);

  return (
    <div className="cy-social">
      <style>{SOCIAL_CSS}</style>
      <div className="cy-social-caption">Share preview · how this looks when posted</div>
      <div className="cy-social-card">
        {seo.image ? (
          <img className="cy-social-img" src={withBase(seo.image)} alt="" />
        ) : (
          <div className="cy-social-img cy-social-img-empty">
            No share image — add one for a large-image card
          </div>
        )}
        <div className="cy-social-body">
          <div className="cy-social-domain">{domain}</div>
          <div className="cy-social-title">{title}</div>
          {description ? (
            <div className="cy-social-desc">{description}</div>
          ) : (
            <div className="cy-social-desc cy-social-muted">No description set</div>
          )}
        </div>
      </div>
    </div>
  );
}

// Scoped to `.cy-social` so it never leaks into the admin chrome. Mimics the
// neutral large-image card layout common to X / Facebook / LinkedIn: a 1.91:1
// image, then a metadata strip with an uppercase domain, a bold title, and a
// two-line description.
const SOCIAL_CSS = `
.cy-social { max-width: 500px; }
.cy-social-caption { font-size: 0.75rem; font-weight: 600; letter-spacing: 0.03em; text-transform: uppercase; color: var(--color-muted); margin-bottom: var(--space-sm); }
.cy-social-card { border: 1px solid var(--color-border); border-radius: var(--radius); overflow: hidden; background: var(--color-bg); }
.cy-social-img { display: block; width: 100%; aspect-ratio: 1.91 / 1; object-fit: cover; background: var(--color-surface, #f1f1f6); }
.cy-social-img-empty { display: flex; align-items: center; justify-content: center; text-align: center; padding: var(--space-md); color: var(--color-muted); font-size: 0.85rem; font-style: italic; }
.cy-social-body { padding: var(--space-md); border-top: 1px solid var(--color-border); }
.cy-social-domain { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.02em; color: var(--color-muted); margin-bottom: 0.25rem; }
.cy-social-title { font-weight: 700; font-size: 1rem; line-height: 1.3; color: var(--color-fg); }
.cy-social-desc { margin-top: 0.3rem; font-size: 0.88rem; line-height: 1.4; color: var(--color-muted); }
.cy-social-muted { font-style: italic; }
`;
