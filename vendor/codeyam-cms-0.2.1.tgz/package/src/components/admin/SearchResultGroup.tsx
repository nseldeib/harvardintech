// One collection's block of dashboard-wide search results: a heading with the
// match count and a list of result rows. The dashboard search island renders one
// of these per collection that has matches.
import type { CSSProperties } from 'react';
import SearchResultRow from './SearchResultRow';
import type { CollectionGroup, SearchableEntry } from '../../lib/entrySearch';

const headingStyle: CSSProperties = {
  fontSize: '0.78rem',
  textTransform: 'uppercase',
  letterSpacing: '0.06em',
  color: 'var(--color-muted)',
  margin: '0 0 var(--space-sm)',
};

const listStyle: CSSProperties = {
  listStyle: 'none',
  margin: 0,
  padding: 0,
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-sm)',
};

interface Props {
  group: CollectionGroup<SearchableEntry>;
}

export default function SearchResultGroup({ group }: Props) {
  return (
    <section style={{ marginBottom: 'var(--space-lg)' }}>
      <h2 style={headingStyle}>
        {group.collectionLabel} ({group.entries.length})
      </h2>
      <ul style={listStyle}>
        {group.entries.map((entry) => (
          <li key={entry.slug}>
            <SearchResultRow entry={entry} />
          </li>
        ))}
      </ul>
    </section>
  );
}
