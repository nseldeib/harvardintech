// The right-hand action cluster of an entry-list row. Presentational: it renders
// one of three mutually-exclusive states and forwards intent to the parent
// EntryRow, which owns the staging-store wiring.
//   • a STAGED row  → a "will archive / publish / delete" badge + Undo
//   • MID-CONFIRM   → the inline "…this entry? Confirm / Cancel" prompt
//   • the DEFAULT   → Archive (or Unarchive, for a draft) + Delete buttons
// Delete is the only action a draft and a published entry both offer; a draft
// swaps Archive for Unarchive since it is already unpublished.
import type { ChangeKind } from '../../lib/pendingChanges';

/** Which actions the inline confirm can be gating. Delete is destructive. */
export type RowAction = 'archive' | 'unarchive' | 'delete';

interface Props {
  /** True when the entry currently carries `draft: true`. */
  draft: boolean;
  /** The kind of the row's staged change, or null when nothing is staged. */
  stagedKind: ChangeKind | null;
  /** The action awaiting inline confirmation, or null when showing buttons. */
  confirming: RowAction | null;
  onRequest: (action: RowAction) => void;
  onConfirm: () => void;
  onCancel: () => void;
  onUndo: () => void;
}

const actionBtn: React.CSSProperties = {
  padding: '0.3rem 0.7rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-fg)',
  fontSize: '0.8rem',
  cursor: 'pointer',
};

const dangerBtn: React.CSSProperties = { ...actionBtn, border: '1px solid #fca5a5', color: '#b91c1c' };

/** Badge shown when this row has a staged action. */
const STAGED_BADGE: Partial<Record<ChangeKind, { label: string; fg: string; bg: string }>> = {
  archive: { label: 'Will archive', fg: '#92400e', bg: '#fde68a' },
  unarchive: { label: 'Will publish', fg: '#166534', bg: '#dcfce7' },
  delete: { label: 'Will delete', fg: '#991b1b', bg: '#fee2e2' },
};

/** The question shown beside Confirm / Cancel for each pending action. */
const CONFIRM_PROMPT: Record<RowAction, string> = {
  archive: 'Archive this entry?',
  unarchive: 'Publish this entry?',
  delete: 'Delete this entry?',
};

export default function EntryRowActions({
  draft,
  stagedKind,
  confirming,
  onRequest,
  onConfirm,
  onCancel,
  onUndo,
}: Props) {
  const badge = stagedKind ? STAGED_BADGE[stagedKind] : undefined;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-sm)' }}>
      {badge ? (
        <>
          <span
            style={{
              display: 'inline-block',
              background: badge.bg,
              color: badge.fg,
              borderRadius: '999px',
              padding: '0.05rem 0.5rem',
              fontSize: '0.72rem',
              fontWeight: 600,
            }}
          >
            {badge.label}
          </span>
          <button type="button" onClick={onUndo} style={actionBtn}>
            Undo
          </button>
        </>
      ) : confirming ? (
        <>
          <span style={{ fontSize: '0.8rem', color: 'var(--color-muted)' }}>{CONFIRM_PROMPT[confirming]}</span>
          <button type="button" onClick={onConfirm} style={confirming === 'delete' ? dangerBtn : actionBtn}>
            Confirm
          </button>
          <button type="button" onClick={onCancel} style={actionBtn}>
            Cancel
          </button>
        </>
      ) : (
        <>
          {draft ? (
            <button type="button" onClick={() => onRequest('unarchive')} style={actionBtn}>
              Unarchive
            </button>
          ) : (
            <button type="button" onClick={() => onRequest('archive')} style={actionBtn}>
              Archive
            </button>
          )}
          <button type="button" onClick={() => onRequest('delete')} style={dangerBtn}>
            Delete
          </button>
        </>
      )}
    </div>
  );
}
