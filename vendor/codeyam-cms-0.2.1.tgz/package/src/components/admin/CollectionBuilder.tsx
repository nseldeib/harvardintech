// The create-a-collection builder island.
//
// A sibling to NavEditor + NewEntryEditor: the editor names a new collection and
// designs its fields (add / edit / remove / reorder rows), and "Create" stages a
// PendingChange that writes the `collections.json` registry — riding the same
// stage-then-commit pipeline as every other edit. All gating + change-building is
// pure logic in `../../lib/collectionRegistry`; this component owns React state,
// the id auto-follow effect, and the markup. After staging, the form stays open
// (showing "Staged") so the editor can review before committing.
import { useEffect, useMemo, useState } from 'react';
import {
  COLLECTIONS_PATH,
  addCollection,
  addDraftField,
  buildCollectionsChange,
  builderStatus,
  draftToCollection,
  emptyDraft,
  existingCollectionIds,
  moveDraftField,
  removeDraftField,
  reorderDraftField,
  updateDraftField,
  type CollectionDraft,
  type CollectionsRegistry,
} from '../../lib/collectionRegistry';
import { slugify } from '../../lib/slug';
import { useListDrag } from '../../lib/useListDrag';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import CollectionMetaFields from './CollectionMetaFields';
import CollectionFieldRow from './CollectionFieldRow';

interface Props {
  /** The committed registry — the baseline the staged change diffs against. */
  initialRegistry: CollectionsRegistry;
  /** Seed the builder with a partly-designed collection — used by isolated-component
   * scenarios to capture a specific builder state (e.g. a list field expanded).
   * Defaults to a fresh blank draft. */
  initialDraft?: CollectionDraft;
}

export default function CollectionBuilder({ initialRegistry, initialDraft }: Props) {
  const [draft, setDraft] = useState<CollectionDraft>(initialDraft ?? emptyDraft());
  const [idTouched, setIdTouched] = useState(false);
  const [staged, setStaged] = useState(false);

  const existingIds = useMemo(() => existingCollectionIds(initialRegistry), [initialRegistry]);
  const status = builderStatus(draft, existingIds);

  // Auto-derive the collection id from its label until the editor overrides it.
  useEffect(() => {
    if (!idTouched) setDraft((d) => ({ ...d, id: slugify(d.label) }));
  }, [draft.label, idTouched]);

  // Reflect the registry's staged status from the shared store.
  useEffect(() => {
    const sync = () => setStaged(loadChanges().some((c) => c.path === COLLECTIONS_PATH));
    sync();
    return subscribe(sync);
  }, []);

  const patch = (p: Partial<CollectionDraft>) => setDraft((d) => ({ ...d, ...p }));
  const patchFields = (fields: CollectionDraft['fields']) => setDraft((d) => ({ ...d, fields }));

  const fieldDrag = useListDrag((from, to) =>
    setDraft((d) => ({ ...d, fields: reorderDraftField(d.fields, from, to) })),
  );

  const onCreate = () => {
    if (!status.canCreate) return;
    const nextReg = addCollection(initialRegistry, draftToCollection(draft));
    stageChange(buildCollectionsChange(initialRegistry, nextReg));
  };

  const onDiscard = () => discardChange(COLLECTIONS_PATH);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <CollectionMetaFields
        draft={draft}
        finalId={status.finalId}
        idError={status.idError}
        onPatch={patch}
        onIdEdit={(value) => {
          patch({ id: value });
          setIdTouched(true);
        }}
      />

      {/* Fields */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 style={{ fontSize: '1.05rem', margin: 0 }}>Fields</h2>
          <button
            type="button"
            onClick={() => patchFields(addDraftField(draft.fields))}
            style={{
              padding: '0.4rem 0.9rem',
              borderRadius: 'var(--radius)',
              border: '1px solid var(--color-border)',
              background: 'transparent',
              color: 'var(--color-fg)',
              cursor: 'pointer',
              fontWeight: 600,
            }}
          >
            + Add field
          </button>
        </div>
        <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--color-muted)' }}>
          Every collection also gets a markdown <strong>Body</strong> and a <strong>Draft</strong> toggle.
        </p>

        {draft.fields.map((field, i) => (
          <CollectionFieldRow
            key={i}
            field={field}
            index={i}
            error={status.fieldErrors[i]}
            subErrors={status.subFieldErrors[i]}
            canUp={i > 0}
            canDown={i < draft.fields.length - 1}
            onChange={(p) => patchFields(updateDraftField(draft.fields, i, p))}
            onMove={(delta) => patchFields(moveDraftField(draft.fields, i, delta))}
            onRemove={() => patchFields(removeDraftField(draft.fields, i))}
            rowDragProps={fieldDrag.rowProps(i)}
            handleProps={fieldDrag.handleProps(i)}
            isDragging={fieldDrag.dragIndex === i}
            isDropTarget={fieldDrag.overIndex === i && fieldDrag.dragIndex !== i}
          />
        ))}
      </div>

      {/* Footer */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--space-md)',
          borderTop: '1px solid var(--color-border)',
          paddingTop: 'var(--space-md)',
        }}
      >
        <button
          type="button"
          onClick={onCreate}
          disabled={!status.canCreate}
          style={{
            padding: '0.5rem 1.1rem',
            borderRadius: 'var(--radius)',
            border: 'none',
            fontWeight: 600,
            cursor: status.canCreate ? 'pointer' : 'not-allowed',
            background: status.canCreate ? 'var(--color-accent)' : 'var(--color-border)',
            color: status.canCreate ? '#fff' : 'var(--color-muted)',
          }}
        >
          {staged ? 'Staged ✓' : 'Create collection'}
        </button>

        {staged && (
          <button
            type="button"
            onClick={onDiscard}
            style={{
              padding: '0.5rem 1.1rem',
              borderRadius: 'var(--radius)',
              border: '1px solid var(--color-border)',
              background: 'transparent',
              color: 'var(--color-fg)',
              cursor: 'pointer',
            }}
          >
            Remove from staging
          </button>
        )}

        <span
          style={{
            fontSize: '0.85rem',
            color: status.idError ? 'var(--color-danger, #c0392b)' : 'var(--color-muted)',
          }}
        >
          {staged ? 'Staged for the next commit.' : status.message}
        </span>
      </div>
    </div>
  );
}
