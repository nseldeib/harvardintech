// Shared inline styles for the sign-in gate + header account menu, so the gate
// card and the identity chip read as one system. Plain data (no JSX), safe to
// import anywhere. Mirrors `stagingStyles.ts`.
import type { CSSProperties } from 'react';

// Full-viewport, OPAQUE cover — it must hide the admin content behind it, not
// just dim it. Sits above the staging bar (z 50/60).
export const gateOverlay: CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'var(--color-surface, #f7f7fb)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 'var(--space-lg)',
  zIndex: 100,
};

export const gateCard: CSSProperties = {
  background: 'var(--color-bg)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  boxShadow: '0 10px 40px rgba(0,0,0,0.10)',
  padding: 'var(--space-lg)',
  width: '100%',
  maxWidth: '380px',
  textAlign: 'center',
};

export const gateMark: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: '2.4rem',
  height: '2.4rem',
  borderRadius: '10px',
  background: 'var(--color-accent)',
  color: '#fff',
  fontSize: '1.3rem',
  fontWeight: 700,
  marginBottom: 'var(--space-md)',
};

export const gateTitle: CSSProperties = {
  margin: '0 0 0.25rem',
  fontSize: '1.25rem',
  color: 'var(--color-fg)',
};

export const gateSubtitle: CSSProperties = {
  margin: '0 0 var(--space-lg)',
  color: 'var(--color-muted)',
  fontSize: '0.95rem',
};

export const signInBtn: CSSProperties = {
  width: '100%',
  padding: '0.7rem 1rem',
  borderRadius: 'var(--radius)',
  border: 'none',
  background: 'var(--color-accent)',
  color: '#fff',
  fontWeight: 700,
  fontSize: '0.95rem',
  cursor: 'pointer',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 'var(--space-sm)',
};

// ── Paste-a-token sign-in (the server-free path) ──────────────────────────
// A left-aligned stack: label, the token input, the submit button, and the
// "how to create a token" helper — reading as one field group inside the card.
export const tokenForm: CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-sm)',
  textAlign: 'left',
};

export const tokenLabel: CSSProperties = {
  fontSize: '0.85rem',
  fontWeight: 600,
  color: 'var(--color-fg)',
};

export const tokenInput: CSSProperties = {
  width: '100%',
  padding: '0.6rem 0.7rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  fontSize: '0.9rem',
  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
  boxSizing: 'border-box',
};

// The muted "how to create a token" helper under the input, with an inline link
// straight to GitHub's token page and a note on the exact scope to grant.
export const tokenHelp: CSSProperties = {
  margin: 0,
  fontSize: '0.8rem',
  lineHeight: 1.5,
  color: 'var(--color-muted)',
};

export const tokenHelpLink: CSSProperties = {
  color: 'var(--color-accent)',
  fontWeight: 600,
  textDecoration: 'none',
};

// "or" divider between the token form and the "Sign in with GitHub" button when
// a site enables both paths.
export const orDivider: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-sm)',
  margin: 'var(--space-md) 0',
  color: 'var(--color-muted)',
  fontSize: '0.75rem',
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
};

export const orRule: CSSProperties = {
  flex: 1,
  height: 1,
  background: 'var(--color-border)',
};

// The worker "Sign in with GitHub" button rendered as SECONDARY when the token
// form is the primary action (outline instead of filled accent).
export const workerBtnSecondary: CSSProperties = {
  width: '100%',
  padding: '0.7rem 1rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-fg)',
  fontWeight: 600,
  fontSize: '0.95rem',
  cursor: 'pointer',
};

// The amber "session expired" note above the sign-in button.
export const expiredNote: CSSProperties = {
  margin: '0 0 var(--space-md)',
  padding: '0.6rem 0.75rem',
  borderRadius: 'var(--radius)',
  background: '#fef3c7',
  border: '1px solid #fde68a',
  color: '#92400e',
  fontSize: '0.85rem',
  textAlign: 'left',
};

export const errorNote: CSSProperties = {
  marginTop: 'var(--space-md)',
  color: '#991b1b',
  fontSize: '0.85rem',
};

// Header identity chip + sign-out.
export const accountWrap: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 'var(--space-sm)',
};

export const avatarImg: CSSProperties = {
  width: '1.6rem',
  height: '1.6rem',
  borderRadius: '50%',
  objectFit: 'cover',
  border: '1px solid var(--color-border)',
};

export const accountName: CSSProperties = {
  fontWeight: 600,
  color: 'var(--color-fg)',
  fontSize: '0.9rem',
};

export const signOutBtn: CSSProperties = {
  padding: '0.3rem 0.7rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'transparent',
  color: 'var(--color-muted)',
  fontSize: '0.85rem',
  cursor: 'pointer',
};
