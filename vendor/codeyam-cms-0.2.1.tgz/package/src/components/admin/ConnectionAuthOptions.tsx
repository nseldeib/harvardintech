// The sign-in-options section of the "Repository connection" editor: the token
// and worker toggles, the at-least-one-sign-in guardrail error, and the
// conditional auth-endpoint input shown only when the worker path is enabled.
// Presentational — the parent ConnectionEditor holds the config state and the
// computed guardrail error. Parallel to SocialLinksEditor.
import type { CmsAuthOptions } from '../../lib/cmsConfig';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';
import { errorTextStyle, toggleRowStyle } from './connectionEditorStyles';

interface Props {
  auth: CmsAuthOptions;
  authEndpoint: string;
  /** The guardrail error when neither sign-in option is enabled. */
  error?: string;
  onToggle: (name: keyof CmsAuthOptions, on: boolean) => void;
  onEndpointChange: (value: string) => void;
}

export default function ConnectionAuthOptions({
  auth,
  authEndpoint,
  error,
  onToggle,
  onEndpointChange,
}: Props) {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
      <h3 style={{ margin: 0, fontSize: '0.95rem' }}>Sign-in options</h3>
      <label style={toggleRowStyle}>
        <input
          type="checkbox"
          checked={auth.token}
          onChange={(e) => onToggle('token', e.target.checked)}
        />
        <span style={{ fontSize: '0.9rem' }}>
          <strong>Paste a token</strong> — server-free sign-in with a GitHub token. No extra
          infrastructure.
        </span>
      </label>
      <label style={toggleRowStyle}>
        <input
          type="checkbox"
          checked={auth.worker}
          onChange={(e) => onToggle('worker', e.target.checked)}
        />
        <span style={{ fontSize: '0.9rem' }}>
          <strong>Sign in with GitHub</strong> — an OAuth popup served by the cms-auth-worker.
        </span>
      </label>
      <label style={toggleRowStyle}>
        <input
          type="checkbox"
          checked={auth.magicLink}
          onChange={(e) => onToggle('magicLink', e.target.checked)}
        />
        <span style={{ fontSize: '0.9rem' }}>
          <strong>Invite by email</strong> — a magic sign-in link for non-technical editors. They
          never see GitHub; invite them on the Editors page.
        </span>
      </label>
      {error && <p style={errorTextStyle}>{error}</p>}

      {auth.worker && (
        <div style={{ marginTop: 'var(--space-sm)' }}>
          <label style={fieldLabelStyle} htmlFor="cms-authEndpoint">
            Auth endpoint
          </label>
          <input
            id="cms-authEndpoint"
            type="text"
            value={authEndpoint}
            placeholder="/auth"
            onChange={(e) => onEndpointChange(e.target.value)}
            style={fieldInputStyle}
          />
        </div>
      )}
    </section>
  );
}
