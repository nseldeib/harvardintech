// The red notice shown when a commit fails, in both the review drawer and the
// Publish page.
//
// Both surfaces run the same commit through the same transport and can fail the
// same ways (a rejected token, a GitHub outage, a freshness check that could not
// run), so they rendered the same banner with the same inline style object
// duplicated verbatim — the exact duplication MediaErrorNotice was extracted to
// fix on the upload side. One component keeps the two reading as one system.
//
// Note this is for a commit that FAILED. A refused commit — the freshness check
// finding that someone else edited your work — is not an error and does not
// render here; it gets the amber DriftNotice, because nothing went wrong and
// nothing was lost.
interface Props {
  /** The failure message; nothing renders when it's empty. */
  message: string;
  /** Margin above the notice, so each host can space it to its own layout. */
  marginTop?: string;
}

export default function CommitErrorNotice({ message, marginTop = 'var(--space-md)' }: Props) {
  if (!message) return null;
  return (
    <p
      style={{
        color: '#991b1b',
        background: '#fee2e2',
        padding: 'var(--space-sm) var(--space-md)',
        borderRadius: 'var(--radius)',
        margin: `${marginTop} 0 0`,
        fontSize: '0.85rem',
      }}
    >
      {message}
    </p>
  );
}
