// One entry in the drift warning: what happened to it, which file it is, and
// the two SAFE ways out.
//
// The copy is the point. This row appears at the moment someone is about to
// lose work, so it names the entry and says plainly what a co-editor did —
// "conflict" alone tells an editor nothing about what to do next. The two
// actions here are both non-destructive: discard your version, or adopt the
// branch's content as your new baseline so the review diff becomes
// theirs-vs-yours and you can re-apply your edit against what actually landed.
// The overwrite is deliberately NOT here — it lives once at the foot of the
// notice (DriftOverwriteAction), so a row never offers losing someone's work as
// one of three equal-looking choices.
//
// Presentational + intent-forwarding: the parent owns the staging set.
import { describeDrift, type DriftedChange } from '../../lib/staleCheck';
import { driftEntryStyle, driftEntryBtn } from './stagingStyles';

interface Props {
  drift: DriftedChange;
  /** Disable both actions while a commit is in flight. */
  busy?: boolean;
  onDiscard: (path: string) => void;
  onReload: (drift: DriftedChange) => void;
}

export default function DriftEntryRow({ drift, busy = false, onDiscard, onReload }: Props) {
  // `disabled` alone stops the click but leaves the button looking live, so a
  // commit in flight reads as "these still work" — dim them to match how the
  // Publish button behaves while committing.
  const btn = busy ? { ...driftEntryBtn, opacity: 0.5, cursor: 'not-allowed' } : driftEntryBtn;

  return (
    <div style={driftEntryStyle}>
      <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--color-fg)' }}>{describeDrift(drift)}</p>
      <p style={{ margin: '0.15rem 0 0.5rem', fontSize: '0.75rem', color: 'var(--color-muted)' }}>{drift.path}</p>
      <div style={{ display: 'flex', gap: 'var(--space-sm)', flexWrap: 'wrap', alignItems: 'center' }}>
        <button type="button" disabled={busy} style={btn} onClick={() => onDiscard(drift.path)}>
          Discard my version
        </button>
        {/* A file that is already deleted has no content to adopt, so reloading
            a baseline from it would be a no-op dressed up as a choice. */}
        {drift.kind !== 'already-gone' && (
          <button type="button" disabled={busy} style={btn} onClick={() => onReload(drift)}>
            Reload current
          </button>
        )}
      </div>
    </div>
  );
}
