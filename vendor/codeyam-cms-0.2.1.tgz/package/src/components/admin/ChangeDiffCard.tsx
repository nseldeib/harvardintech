// One staged change in the review drawer: its edited title, content path, a
// kind badge, a Discard action, and — for a WRITE — the line-level diff (only
// changed lines shown; context is dropped). A deletion has no diff, so it shows
// a removal notice instead. Presentational — the parent drawer owns the staging
// set and handles the discard.
import { diffLines, isBinary, isDeletion, type ChangeKind, type PendingChange } from '../../lib/pendingChanges';
import { imageDataUrl } from '../../lib/mediaLibrary';
import { diffColor, diffBg, ghostBtnDark } from './stagingStyles';

interface Props {
  change: PendingChange;
  disabled: boolean;
  onDiscard: (path: string) => void;
}

/** The badge label + colors for each change kind (edit has no badge). */
const KIND_BADGE: Partial<Record<ChangeKind, { label: string; fg: string; bg: string }>> = {
  archive: { label: 'Archive', fg: '#92400e', bg: '#fde68a' },
  unarchive: { label: 'Publish', fg: '#166534', bg: '#dcfce7' },
  delete: { label: 'Delete', fg: '#991b1b', bg: '#fee2e2' },
};


export default function ChangeDiffCard({ change, disabled, onDiscard }: Props) {
  const badge = change.kind ? KIND_BADGE[change.kind] : undefined;
  return (
    <div style={{ border: '1px solid var(--color-border)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 'var(--space-sm)',
          padding: 'var(--space-sm) var(--space-md)',
          background: 'var(--color-surface, #f7f7fb)',
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-sm)' }}>
            {badge && (
              <span
                style={{
                  display: 'inline-block',
                  background: badge.bg,
                  color: badge.fg,
                  borderRadius: '999px',
                  padding: '0.05rem 0.5rem',
                  fontSize: '0.68rem',
                  fontWeight: 700,
                  textTransform: 'uppercase',
                  letterSpacing: '0.04em',
                }}
              >
                {badge.label}
              </span>
            )}
            <span style={{ fontWeight: 600 }}>{change.title}</span>
          </div>
          <div style={{ fontSize: '0.75rem', color: 'var(--color-muted)' }}>{change.path}</div>
        </div>
        <button type="button" onClick={() => onDiscard(change.path)} disabled={disabled} style={ghostBtnDark}>
          Discard
        </button>
      </div>
      {isDeletion(change) ? (
        <p
          style={{
            margin: 0,
            padding: 'var(--space-sm) var(--space-md)',
            fontSize: '0.8rem',
            color: '#991b1b',
            background: '#fef2f2',
          }}
        >
          This entry will be removed from the site on the next commit.
        </p>
      ) : isBinary(change) ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-md)', padding: 'var(--space-sm) var(--space-md)' }}>
          <img
            src={imageDataUrl(change.path, change.updated)}
            alt={change.title}
            style={{ width: '72px', height: '54px', objectFit: 'cover', borderRadius: 'var(--radius)', border: '1px solid var(--color-border)' }}
          />
          <span style={{ fontSize: '0.8rem', color: 'var(--color-muted)' }}>New image — will be added to the repo on the next commit.</span>
        </div>
      ) : (
        <pre
        style={{
          margin: 0,
          padding: 'var(--space-sm) var(--space-md)',
          fontFamily: 'var(--font-mono)',
          fontSize: '0.78rem',
          overflowX: 'auto',
        }}
      >
        {diffLines(change.original, change.updated)
          .filter((l) => l.kind !== 'context')
          .map((line, i) => (
            <div key={i} style={{ background: diffBg[line.kind], color: diffColor[line.kind] }}>
              {line.kind === 'add' ? '+ ' : '- '}
              {line.text}
            </div>
          ))}
        </pre>
      )}
    </div>
  );
}
