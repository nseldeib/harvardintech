// The shared "Stage change / Revert edits" footer used by the site-settings and
// navigation editor islands. It mirrors the entry editor's footer so staging a
// settings or nav edit looks and reads exactly like staging an entry edit:
// "Stage change" while dirty, "Staged ✓" once staged, a Revert that both resets
// the form (via the parent's onRevert) and drops the pending change. Purely
// presentational — the parent owns the state and the staging store.
import type { CSSProperties } from 'react';

interface Props {
  /** Form differs from the last-committed baseline. */
  dirty: boolean;
  /** A change for this singleton currently sits in the staging set. */
  staged: boolean;
  onStage: () => void;
  onRevert: () => void;
}

const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 'var(--space-md)',
  borderTop: '1px solid var(--color-border)',
  paddingTop: 'var(--space-md)',
  flexWrap: 'wrap',
};

export default function StageFooter({ dirty, staged, onStage, onRevert }: Props) {
  return (
    <div style={rowStyle}>
      <button
        type="button"
        onClick={onStage}
        disabled={!dirty}
        style={{
          padding: '0.5rem 1.1rem',
          borderRadius: 'var(--radius)',
          border: 'none',
          fontWeight: 600,
          cursor: dirty ? 'pointer' : 'not-allowed',
          background: dirty ? 'var(--color-accent)' : 'var(--color-border)',
          color: dirty ? '#fff' : 'var(--color-muted)',
        }}
      >
        {staged && !dirty ? 'Staged ✓' : 'Stage change'}
      </button>

      {(dirty || staged) && (
        <button
          type="button"
          onClick={onRevert}
          style={{
            padding: '0.5rem 1.1rem',
            borderRadius: 'var(--radius)',
            border: '1px solid var(--color-border)',
            background: 'transparent',
            color: 'var(--color-fg)',
            cursor: 'pointer',
          }}
        >
          Revert edits
        </button>
      )}

      <span style={{ fontSize: '0.85rem', color: 'var(--color-muted)' }}>
        {dirty
          ? 'Unsaved edits — stage them to add to your pending changes.'
          : staged
            ? 'Staged for the next commit.'
            : 'No changes yet.'}
      </span>
    </div>
  );
}
