// The editor-roster island: the state-owning root for /admin/editors. It owns
// the roster, composes InviteEditorForm + a list of EditorRow + the shared
// StageFooter, and — exactly like SettingsEditor — "Stage change" does NOT write
// editors.json. It serializes the edited roster to canonical JSON and adds a
// PendingChange to the browser staging set; the global StagingBar commits it,
// batched with any other pending edits. Inviting, revoking, and resending all
// mutate the in-memory roster; nothing is live until it's staged and committed.
//
// The broker that would actually email the magic link and mint tokens is out of
// scope this cycle: here an invite is a row in editors.json, which in the real
// system is the source the broker checks when a link is redeemed.
import { useEffect, useMemo, useState } from 'react';
import {
  EDITORS_PATH,
  addInvite,
  buildEditorsChange,
  inviteError,
  removeEditor,
  resendInvite,
  serializeEditors,
  sortForDisplay,
  type EditorRecord,
  type EditorsRegistry,
} from '../../lib/editorsRegistry';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import InviteEditorForm from './InviteEditorForm';
import EditorRow from './EditorRow';
import EditorsEmpty from './EditorsEmpty';
import StageFooter from './StageFooter';
import { listStyle } from './editorsStyles';

interface Props {
  initialEditors: EditorsRegistry;
  /** Reference "now" for relative invite times + new-invite timestamps. Defaults
   * to the real clock; scenarios inject a fixed value for deterministic capture. */
  nowIso?: string;
}

export default function EditorsManager({ initialEditors, nowIso }: Props) {
  const now = nowIso ?? new Date().toISOString();
  const [editors, setEditors] = useState<EditorRecord[]>(initialEditors.editors);
  const [staged, setStaged] = useState(false);

  const original = useMemo(() => serializeEditors(initialEditors), [initialEditors]);
  const current = serializeEditors({ editors });
  const dirty = current !== original;

  useEffect(() => {
    const sync = () => setStaged(loadChanges().some((c) => c.path === EDITORS_PATH));
    sync();
    return subscribe(sync);
  }, []);

  // invitedBy is the roster's owner — the person doing the inviting from this
  // screen. Falls back to empty (the record just omits it) if there's no owner.
  const ownerEmail = editors.find((e) => e.role === 'owner')?.email ?? '';

  const onInvite = (email: string) => setEditors((prev) => addInvite(prev, email, ownerEmail, now));
  const onRemove = (email: string) => setEditors((prev) => removeEditor(prev, email));
  const onResend = (email: string) => setEditors((prev) => resendInvite(prev, email, now));

  const onStage = () => stageChange(buildEditorsChange(initialEditors, { editors }));
  const onRevert = () => {
    setEditors(initialEditors.editors);
    discardChange(EDITORS_PATH);
  };

  const sorted = sortForDisplay(editors);
  const pending = editors.filter((e) => e.status === 'invited' || e.status === 'expired').length;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <InviteEditorForm validate={(email) => inviteError(editors, email)} onInvite={onInvite} />

      {sorted.length > 0 ? (
        <ul style={listStyle}>
          {sorted.map((editor) => (
            <EditorRow
              key={editor.email}
              editor={editor}
              nowIso={now}
              onResend={onResend}
              onRemove={onRemove}
            />
          ))}
        </ul>
      ) : (
        <EditorsEmpty />
      )}

      {pending > 0 && (
        <p style={{ color: 'var(--color-muted)', fontSize: '0.82rem', margin: 0 }}>
          {pending} pending invite{pending === 1 ? '' : 's'} · invites and removals stage like any
          other edit and go live on your next publish.
        </p>
      )}

      <StageFooter dirty={dirty} staged={staged} onStage={onStage} onRevert={onRevert} />
    </div>
  );
}
