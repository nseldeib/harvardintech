// The "Social links" section of the settings editor: the heading, an empty-state
// nudge, one SocialLinkRow per link, and the "Add social link" button. The list
// mutation logic lives in the pure `settingsEditor` helpers; this component
// applies them and hands the new list up via onChange. Presentational — the
// parent SettingsEditor owns the settings state.
import type { SocialLink } from '../../lib/siteConfig';
import { addSocial, moveSocial, removeSocial, reorderSocial, updateSocial } from '../../lib/settingsEditor';
import { useListDrag } from '../../lib/useListDrag';
import { addBtnStyle } from './configEditorStyles';
import SocialLinkRow from './SocialLinkRow';

interface Props {
  socials: SocialLink[];
  onChange: (socials: SocialLink[]) => void;
}

export default function SocialLinksEditor({ socials, onChange }: Props) {
  const drag = useListDrag((from, to) => onChange(reorderSocial(socials, from, to)));
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      <h2 style={{ margin: 0, fontSize: '1.05rem' }}>Social links</h2>
      {socials.length === 0 && (
        <p style={{ margin: 0, color: 'var(--color-muted)', fontSize: '0.9rem' }}>
          No social links yet — add one to show it in the site footer.
        </p>
      )}
      {socials.map((social, i) => (
        <SocialLinkRow
          key={i}
          social={social}
          index={i}
          isFirst={i === 0}
          isLast={i === socials.length - 1}
          onChange={(patch) => onChange(updateSocial(socials, i, patch))}
          onMove={(delta) => onChange(moveSocial(socials, i, delta))}
          onRemove={() => onChange(removeSocial(socials, i))}
          rowDragProps={drag.rowProps(i)}
          handleProps={drag.handleProps(i)}
          isDragging={drag.dragIndex === i}
          isDropTarget={drag.overIndex === i && drag.dragIndex !== i}
        />
      ))}
      <button type="button" onClick={() => onChange(addSocial(socials))} style={addBtnStyle}>
        + Add social link
      </button>
    </section>
  );
}
