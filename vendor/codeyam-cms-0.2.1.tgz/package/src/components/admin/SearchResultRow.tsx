// One row of dashboard-wide search results: a link into the matched entry's
// editor, its label, and a Draft pill when the entry is unpublished.
// Presentational — the parent group maps matched entries onto this.
import type { CSSProperties } from 'react';
import type { SearchableEntry } from '../../lib/entrySearch';
import { withBase } from '../../lib/adminUrl';

const rowStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 'var(--space-sm)',
  background: 'var(--color-bg)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-md) var(--space-lg)',
};

const draftPillStyle: CSSProperties = {
  fontSize: '0.7rem',
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
  color: 'var(--color-muted)',
  border: '1px solid var(--color-border)',
  borderRadius: '999px',
  padding: '0.1rem 0.5rem',
};

interface Props {
  entry: SearchableEntry;
}

export default function SearchResultRow({ entry }: Props) {
  return (
    <a href={withBase(`/admin/${entry.collection}/${entry.slug}`)} style={rowStyle}>
      <span style={{ fontWeight: 600, color: 'var(--color-fg)' }}>{entry.label}</span>
      {entry.draft && <span style={draftPillStyle}>Draft</span>}
    </a>
  );
}
