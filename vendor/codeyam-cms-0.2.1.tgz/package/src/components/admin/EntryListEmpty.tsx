// The empty-state nudge shown when a collection has no entries at all — the
// production default on day one, before the editor creates the first entry. The
// React counterpart of the old server-rendered empty card, so it can live inside
// the client-side search island.
import type { CSSProperties } from 'react';

const style: CSSProperties = {
  background: 'var(--color-bg)',
  border: '1px dashed var(--color-border)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-lg)',
  color: 'var(--color-muted)',
};

interface Props {
  label: string;
}

export default function EntryListEmpty({ label }: Props) {
  return <p style={style}>No entries yet in {label}.</p>;
}
