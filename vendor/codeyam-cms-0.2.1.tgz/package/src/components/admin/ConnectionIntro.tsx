// The intro block of the "Repository connection" editor: the heading + helper
// copy, which flips between a prominent first-run "Connect your repository" call
// to action and the neutral "Repository connection" reconfigure copy. Purely
// presentational — the parent ConnectionEditor decides `firstRun` from the
// committed baseline.

interface Props {
  /** The site has no commit target yet — show the first-run call to action. */
  firstRun: boolean;
}

export default function ConnectionIntro({ firstRun }: Props) {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)' }}>
      <h2 style={{ margin: 0, fontSize: '1.05rem' }}>
        {firstRun ? 'Connect your repository' : 'Repository connection'}
      </h2>
      <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--color-muted)' }}>
        {firstRun
          ? 'Point this CMS at the GitHub repository it should commit content to. Your changes stage and commit through the same review flow as every other edit.'
          : 'The GitHub repository and branch this CMS commits to, and how editors sign in. Changes stage like any other edit and commit together.'}
      </p>
    </section>
  );
}
