// Shared inline styles for the list-based controls in the site-settings and
// navigation editors: the small up / down / remove icon buttons on each row and
// the dashed "add" button. Kept beside the islands so both editors render an
// identical control vocabulary.
import type { CSSProperties } from 'react';

/** A compact square icon button (move up, move down, remove). */
export const iconBtnStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: '1.9rem',
  height: '1.9rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  cursor: 'pointer',
  fontSize: '0.9rem',
  lineHeight: 1,
};

/** The remove button reuses the icon button but reads as destructive. */
export const removeBtnStyle: CSSProperties = {
  ...iconBtnStyle,
  color: '#991b1b',
  borderColor: '#fecaca',
};

/** A full-width dashed "add another" button. */
export const addBtnStyle: CSSProperties = {
  padding: '0.5rem 0.9rem',
  borderRadius: 'var(--radius)',
  border: '1px dashed var(--color-border)',
  background: 'transparent',
  color: 'var(--color-accent)',
  fontWeight: 600,
  cursor: 'pointer',
  alignSelf: 'flex-start',
};

/** A card wrapping one editable row (a social link, a nav item). */
export const rowCardStyle: CSSProperties = {
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-md)',
  background: 'var(--color-bg)',
  display: 'flex',
  flexDirection: 'column',
  gap: 'var(--space-sm)',
};

/** The braille-dots grip a row is grabbed by to drag-reorder it. Purely a grab
 * affordance — the row itself carries the native `draggable`; see `useListDrag`. */
export const dragHandleStyle: CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: '1.5rem',
  alignSelf: 'stretch',
  color: 'var(--color-muted)',
  cursor: 'grab',
  userSelect: 'none',
  touchAction: 'none',
  fontSize: '1.1rem',
  lineHeight: 1,
  flex: '0 0 auto',
};

/**
 * Visual feedback merged onto a row while a drag is in flight: the lifted row
 * dims, and the row the pointer is over shows an accent ring as the drop target.
 * Shared so every reorderable list reads identically.
 */
export function dragRowStyle(isDragging: boolean, isDropTarget: boolean): CSSProperties {
  if (isDragging) return { opacity: 0.4 };
  if (isDropTarget) return { outline: '2px solid var(--color-accent)', outlineOffset: '2px' };
  return {};
}
