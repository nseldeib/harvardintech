// One button in the formatting toolbar (and its heading menu trigger).
//
// A tiny presentational wrapper so BodyToolbar and HeadingMenu render identical,
// consistently-styled buttons instead of repeating the markup a dozen times. The
// `onMouseDown` preventDefault is the load-bearing bit: it keeps focus (and the
// selection) on the body textarea when a button is pressed, so a wrap/insert acts
// on what the editor had selected rather than losing it to the button.
import type { CSSProperties, ReactNode } from 'react';

export const btnStyle: CSSProperties = {
  minWidth: '2rem',
  height: '2rem',
  padding: '0 0.5rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
  cursor: 'pointer',
  fontSize: '0.85rem',
  lineHeight: 1,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
};

interface Props {
  label: ReactNode;
  title: string;
  onClick: () => void;
  style?: CSSProperties;
}

export default function ToolbarButton({ label, title, onClick, style }: Props) {
  return (
    <button
      type="button"
      style={{ ...btnStyle, ...style }}
      title={title}
      aria-label={title}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
    >
      {label}
    </button>
  );
}
