// The Publish page's commit bar: the one-commit target line, the Publish / Retry
// button, and (on a failed commit) the error message above them. Presentational
// + intent-forwarding — the parent PublishPage owns the commit and feeds the
// phase/error down; this renders the call to action and forwards the publish
// intent.
import type { RepoTarget } from '../../lib/githubCommit';
import CommitErrorNotice from './CommitErrorNotice';
import { accentBtn } from './stagingStyles';

interface Props {
  repo: RepoTarget;
  /** Number of staged files this commit will land. */
  count: number;
  /** True while the commit is in flight (disables the button, shows "Publishing…"). */
  committing: boolean;
  /** True when the last commit attempt errored (button reads "Retry publish"). */
  errored: boolean;
  /** The commit error message, shown above the bar when present. */
  error: string;
  /** True when the freshness check refused the commit — publishing stays
   * unavailable until every drifted entry is resolved. */
  blocked?: boolean;
  onPublish: () => void;
}

export default function PublishActions({ repo, count, committing, errored, error, blocked = false, onPublish }: Props) {
  const disabled = committing || blocked;
  return (
    <>
      {errored && <CommitErrorNotice message={error} />}

      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 'var(--space-md)',
          marginTop: 'var(--space-lg)',
        }}
      >
        <span style={{ color: 'var(--color-muted)', fontSize: '0.85rem' }}>
          Committing to{' '}
          <strong>
            {repo.owner}/{repo.repo}
          </strong>{' '}
          on <strong>{repo.branch}</strong> — one commit, {count} {count === 1 ? 'file' : 'files'}.
        </span>
        <button
          type="button"
          onClick={onPublish}
          disabled={disabled}
          style={{
            ...accentBtn,
            // A blocked publish must not still LOOK like the button to press —
            // dropping it to the muted surface says "not available yet" at a
            // glance, where a dimmed accent still reads as the call to action.
            ...(blocked
              ? { background: 'var(--color-border)', color: 'var(--color-muted)', cursor: 'not-allowed' }
              : {}),
            opacity: committing ? 0.6 : 1,
          }}
        >
          {committing
            ? 'Publishing…'
            : blocked
              ? 'Resolve the entries above'
              : errored
                ? 'Retry publish'
                : `Publish ${count} ${count === 1 ? 'change' : 'changes'}`}
        </button>
      </div>
    </>
  );
}
