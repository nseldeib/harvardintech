// The "Site details" section of the settings editor: one labelled input per
// editable scalar field (title, description, contact email, footer text), driven
// by the SETTINGS_FIELDS descriptor list. Presentational — the parent
// SettingsEditor holds the settings state and receives edits via onChange.
import type { SiteSettings } from '../../lib/siteConfig';
import { SETTINGS_FIELDS, type SettingsFieldDef } from '../../lib/settingsEditor';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';

type ScalarField = SettingsFieldDef['name'];

interface Props {
  settings: SiteSettings;
  onChange: (name: ScalarField, value: string) => void;
}

export default function SiteDetailsFields({ settings, onChange }: Props) {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      <h2 style={{ margin: 0, fontSize: '1.05rem' }}>Site details</h2>
      {SETTINGS_FIELDS.map((field) => (
        <div key={field.name}>
          <label style={fieldLabelStyle} htmlFor={`s-${field.name}`}>
            {field.label}
          </label>
          {field.type === 'textarea' ? (
            <textarea
              id={`s-${field.name}`}
              value={String(settings[field.name] ?? '')}
              rows={3}
              onChange={(e) => onChange(field.name, e.target.value)}
              style={{ ...fieldInputStyle, resize: 'vertical' }}
            />
          ) : (
            <input
              id={`s-${field.name}`}
              type="text"
              value={String(settings[field.name] ?? '')}
              onChange={(e) => onChange(field.name, e.target.value)}
              style={fieldInputStyle}
            />
          )}
        </div>
      ))}
    </section>
  );
}
