// One row of the Publish checklist: a status dot, the check's name, and either
// its reassuring "all good" line (when it passed) or the list of plain-English
// findings (when it has issues). Presentational — the pure `publishChecklist`
// lib decides what the findings are; this only lays one check's result out.
import type { CheckResult } from '../../lib/publishChecklist';
import ChecklistStatusDot from './ChecklistStatusDot';

const WARN_FG = '#92400e';

interface Props {
  check: CheckResult;
}

export default function ChecklistCheckRow({ check }: Props) {
  const ok = check.findings.length === 0;
  return (
    <li style={{ display: 'flex', gap: 'var(--space-md)', alignItems: 'flex-start' }}>
      <ChecklistStatusDot ok={ok} />
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 600, color: 'var(--color-fg)' }}>{check.label}</div>
        {ok ? (
          <div style={{ color: 'var(--color-muted)', fontSize: '0.85rem' }}>{check.okLabel}</div>
        ) : (
          <ul
            style={{
              margin: '0.35rem 0 0',
              padding: 0,
              listStyle: 'none',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.35rem',
            }}
          >
            {check.findings.map((f, i) => (
              <li key={`${f.path}-${i}`} style={{ fontSize: '0.85rem', color: 'var(--color-fg)' }}>
                <strong style={{ color: WARN_FG }}>{f.entryTitle}</strong>
                <span style={{ color: 'var(--color-muted)' }}> — {f.message}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </li>
  );
}
