// The formatting toolbar above the entry-body textarea.
//
// A thin, self-contained UI layer over the pure `applyFormat` engine: each button
// reads the textarea's live selection, runs the corresponding `FormatAction`, and
// writes the new text back through `onChange` — then restores the caret/selection
// the engine computed so typing continues in the right place. It also binds the
// ⌘/Ctrl+B / +I / +K shortcuts to the same textarea. Both EntryEditor and
// NewEntryEditor render it over their shared `bodyRef`, so the toolbar lives in one
// place instead of being duplicated per editor. The button chrome is `ToolbarButton`
// and the heading dropdown is `HeadingMenu`; the image button defers to the parent
// (which owns the media picker) via `onInsertImage`.
import { useCallback, useEffect, useRef, type CSSProperties, type RefObject } from 'react';
import { applyFormat, type FormatAction } from '../../lib/markdownFormat';
import ToolbarButton from './ToolbarButton';
import HeadingMenu from './HeadingMenu';

interface Props {
  value: string;
  onChange: (next: string) => void;
  textareaRef: RefObject<HTMLTextAreaElement | null>;
  /** Open the media picker for a body insertion; the parent inserts the image. */
  onInsertImage: () => void;
}

/** Keyboard shortcut → action (with ⌘/Ctrl held). */
const SHORTCUTS: Record<string, FormatAction> = { b: 'bold', i: 'italic', k: 'link' };

const rowStyle: CSSProperties = {
  display: 'flex',
  flexWrap: 'wrap',
  gap: '0.3rem',
  marginBottom: 'var(--space-sm)',
};

/** The toolbar buttons after the heading menu, in display order. */
const BUTTONS: { action: FormatAction; label: string; title: string; style?: CSSProperties }[] = [
  { action: 'bold', label: 'B', title: 'Bold (⌘B)', style: { fontWeight: 700 } },
  { action: 'italic', label: 'I', title: 'Italic (⌘I)', style: { fontStyle: 'italic' } },
  { action: 'link', label: '🔗', title: 'Link (⌘K)' },
  { action: 'ul', label: '•', title: 'Bullet list' },
  { action: 'ol', label: '1.', title: 'Numbered list' },
  { action: 'quote', label: '“', title: 'Quote' },
  { action: 'code', label: '</>', title: 'Inline code' },
  { action: 'codeblock', label: '{ }', title: 'Code block' },
  { action: 'strike', label: 'S', title: 'Strikethrough', style: { textDecoration: 'line-through' } },
  { action: 'hr', label: '—', title: 'Horizontal rule' },
];

export default function BodyToolbar({ value, onChange, textareaRef, onInsertImage }: Props) {
  // The selection the engine wants after the text change; applied post-render once
  // the textarea holds the new value.
  const pending = useRef<{ start: number; end: number } | null>(null);
  // Latest value read at click time, so `run` stays referentially stable (the
  // keyboard listener subscribes once rather than re-binding every keystroke).
  const valueRef = useRef(value);
  valueRef.current = value;

  useEffect(() => {
    const el = textareaRef.current;
    if (el && pending.current) {
      el.focus();
      el.setSelectionRange(pending.current.start, pending.current.end);
      pending.current = null;
    }
  });

  const run = useCallback(
    (action: FormatAction) => {
      const el = textareaRef.current;
      const text = valueRef.current;
      const start = el ? el.selectionStart : text.length;
      const end = el ? el.selectionEnd : text.length;
      const next = applyFormat({ text, selectionStart: start, selectionEnd: end }, action);
      pending.current = { start: next.selectionStart, end: next.selectionEnd };
      onChange(next.text);
    },
    [textareaRef, onChange],
  );

  // Bind the ⌘/Ctrl shortcuts to the shared textarea.
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    const handler = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey) || e.altKey) return;
      const action = SHORTCUTS[e.key.toLowerCase()];
      if (!action) return;
      e.preventDefault();
      run(action);
    };
    el.addEventListener('keydown', handler);
    return () => el.removeEventListener('keydown', handler);
  }, [textareaRef, run]);

  return (
    <div style={rowStyle} role="toolbar" aria-label="Formatting">
      <ToolbarButton label="B" title="Bold (⌘B)" style={{ fontWeight: 700 }} onClick={() => run('bold')} />
      <ToolbarButton label="I" title="Italic (⌘I)" style={{ fontStyle: 'italic' }} onClick={() => run('italic')} />
      <HeadingMenu onSelect={run} />
      {BUTTONS.slice(2).map((b) => (
        <ToolbarButton key={b.action} label={b.label} title={b.title} style={b.style} onClick={() => run(b.action)} />
      ))}
      <ToolbarButton label="🖼️" title="Insert image" onClick={onInsertImage} />
    </div>
  );
}
