// The heading-level dropdown in the formatting toolbar.
//
// Its own stateful island: the "H▾" trigger opens a small popover of H1/H2/H3, and
// picking one calls `onSelect` with the matching FormatAction (the parent applies
// it to the body). Split out of BodyToolbar because it owns real interaction state
// — open/close plus an outside-click closer — that the flat button row does not.
// The trigger toggles on mousedown (before the document closer can fire) so a
// second press reliably closes it.
import { useEffect, useState } from 'react';
import type { FormatAction } from '../../lib/markdownFormat';
import { btnStyle } from './ToolbarButton';

interface Props {
  onSelect: (action: FormatAction) => void;
}

const HEADINGS: { action: FormatAction; label: string }[] = [
  { action: 'h1', label: 'Heading 1' },
  { action: 'h2', label: 'Heading 2' },
  { action: 'h3', label: 'Heading 3' },
];

export default function HeadingMenu({ onSelect }: Props) {
  const [open, setOpen] = useState(false);

  // Close on any click outside the menu.
  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);

  return (
    <span style={{ position: 'relative', display: 'inline-flex' }}>
      <button
        type="button"
        style={btnStyle}
        title="Heading"
        aria-label="Heading"
        aria-haspopup="menu"
        aria-expanded={open}
        onMouseDown={(e) => {
          // Toggle from mousedown so the outside-click closer doesn't fight it.
          e.preventDefault();
          e.stopPropagation();
          setOpen((o) => !o);
        }}
      >
        H▾
      </button>
      {open && (
        <div
          role="menu"
          style={{
            position: 'absolute',
            top: 'calc(100% + 4px)',
            left: 0,
            zIndex: 5,
            background: 'var(--color-bg)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius)',
            boxShadow: '0 4px 14px rgba(0,0,0,0.12)',
            padding: '0.25rem',
            display: 'flex',
            flexDirection: 'column',
            minWidth: '8.5rem',
          }}
          onMouseDown={(e) => e.stopPropagation()}
        >
          {HEADINGS.map((h, i) => (
            <button
              key={h.action}
              type="button"
              role="menuitem"
              style={{
                ...btnStyle,
                width: '100%',
                justifyContent: 'flex-start',
                border: 'none',
                height: 'auto',
                padding: '0.4rem 0.5rem',
                fontSize: `${1.15 - i * 0.12}rem`,
                fontWeight: 700,
              }}
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => {
                onSelect(h.action);
                setOpen(false);
              }}
            >
              {h.label}
            </button>
          ))}
        </div>
      )}
    </span>
  );
}
