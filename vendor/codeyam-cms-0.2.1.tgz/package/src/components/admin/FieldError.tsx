// The inline "this required field is blank" message shown beneath an entry
// field's input. The enforcement half of the "· optional" marker the label
// already renders: the marker says which fields may be left blank, this says
// when one that may not has been. Purely presentational and shared by every
// field type that can hold a scalar — EntryField's text/textarea/date/number
// inputs and ImageField — so a blocking field reads the same wherever it
// appears. Renders nothing when there is no error, so callers can pass the
// possibly-undefined message straight through.
import type { CSSProperties } from 'react';

export const fieldErrorStyle: CSSProperties = {
  margin: '0.35rem 0 0',
  fontSize: '0.78rem',
  fontWeight: 600,
  color: 'var(--color-danger, #c0392b)',
};

/** The input treatment that goes with the message. Restates the whole `border`
 * shorthand rather than just `borderColor`, which React warns about mixing with
 * `fieldInputStyle`'s shorthand. */
export const errorBorderStyle: CSSProperties = { border: '1px solid var(--color-danger, #c0392b)' };

interface Props {
  /** The message, or undefined when the field is fine. */
  error?: string;
}

export default function FieldError({ error }: Props) {
  if (!error) return null;
  return <p style={fieldErrorStyle}>{error}</p>;
}
