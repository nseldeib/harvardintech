// The responsive grid the media library and the in-editor picker both lay their
// cards out in.
//
// It owns geometry and nothing else — the two surfaces render DIFFERENT cards
// (the gallery wires drag handles and a Remove action, the picker wires
// selection), so each maps its own and passes the results in. What must stay
// identical between them is the layout: cards the same size in both places is
// what makes the picker feel like the gallery in a modal.
import type { ReactNode } from 'react';

interface Props {
  /** Minimum card width before the grid reflows; the picker's is narrower. */
  minCardWidth?: string;
  children: ReactNode;
}

export default function MediaGrid({ minCardWidth = '180px', children }: Props) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(auto-fill, minmax(${minCardWidth}, 1fr))`,
        gap: 'var(--space-md)',
      }}
    >
      {children}
    </div>
  );
}
