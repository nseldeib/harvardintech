// The text block under a media card's thumbnail: what the asset is called,
// where it lives, and how big it is.
//
// An asset's identity is its path within `public/images`, so at a real
// consumer's scale (dozens of images across several folders) labelling a card
// with the whole path makes a grid of shared prefixes that reads as a wall.
// The basename leads instead, the folder sits underneath as a location, and
// the full path stays available as the name's tooltip. A root-level asset has
// no folder line at all, so a flat library keeps its original two-line card.
import type { CSSProperties } from 'react';
import { assetBasename, assetDirname, assetMetaLine, type MediaAsset } from '../../lib/mediaLibrary';

interface Props {
  asset: MediaAsset;
}

const nameStyle: CSSProperties = {
  fontSize: '0.8rem',
  fontWeight: 600,
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
};

/** The containing folder, marked with a trailing `/` so it reads as a location. */
const folderStyle: CSSProperties = {
  fontSize: '0.72rem',
  color: 'var(--color-muted)',
  fontWeight: 600,
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
};

// Left free to wrap — the picker's cards are narrower than the gallery's, and
// clipping `1.8 MB → 262 KB` mid-arrow loses the number that makes the line
// worth showing.
const metaStyle: CSSProperties = {
  fontSize: '0.72rem',
  color: 'var(--color-muted)',
};

export default function MediaCardLabel({ asset }: Props) {
  const folder = assetDirname(asset.filename);
  return (
    <>
      <span style={nameStyle} title={asset.filename}>
        {assetBasename(asset.filename)}
      </span>
      {folder && (
        <span style={folderStyle} title={folder}>
          {folder}/
        </span>
      )}
      <span style={metaStyle}>{assetMetaLine(asset)}</span>
    </>
  );
}
