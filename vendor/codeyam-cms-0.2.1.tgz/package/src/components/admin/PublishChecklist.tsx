// The Publish Checklist panel on the Publish page: a friendly, ADVISORY preflight
// summary shown above the Publish button. It runs four plain-English checks over
// the staged changes (broken links, missing alt text, missing SEO, oversized
// images) and lays them out as a green "looks good" list or an amber "a few
// things worth a look" list. It never blocks — the Publish button stays enabled
// regardless — so this is reassurance and a nudge, not a gate.
//
// All the logic lives in the pure `publishChecklist` lib; this component only
// composes the summary banner and one row per check, so what it shows is exactly
// what the unit tests assert.
import { useMemo } from 'react';
import type { PendingChange } from '../../lib/pendingChanges';
import { runPublishChecklist, checklistHeadline, type ChecklistContext } from '../../lib/publishChecklist';
import ChecklistSummary from './ChecklistSummary';
import ChecklistCheckRow from './ChecklistCheckRow';

interface Props {
  /** The staged changes about to be published — the same set the review list shows. */
  changes: PendingChange[];
  /** Site facts the checks resolve against (known pages, media manifest, …). */
  context: ChecklistContext;
}

export default function PublishChecklist({ changes, context }: Props) {
  const result = useMemo(() => runPublishChecklist(changes, context), [changes, context]);

  return (
    <section
      aria-label="Publish checklist"
      style={{
        marginTop: 'var(--space-lg)',
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius)',
        overflow: 'hidden',
      }}
    >
      <ChecklistSummary allClear={result.allClear} headline={checklistHeadline(result)} />

      <ul
        style={{
          margin: 0,
          padding: 'var(--space-md)',
          listStyle: 'none',
          display: 'flex',
          flexDirection: 'column',
          gap: 'var(--space-md)',
          background: 'var(--color-bg)',
        }}
      >
        {result.checks.map((check) => (
          <ChecklistCheckRow key={check.id} check={check} />
        ))}
      </ul>
    </section>
  );
}
