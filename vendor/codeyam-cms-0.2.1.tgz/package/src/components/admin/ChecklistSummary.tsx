// The Publish-checklist header banner: a green "Before you publish / looks good"
// when everything passed, or an amber "N things worth a look" nudge otherwise.
// The headline copy comes from the pure `checklistHeadline` helper so the wording
// is unit-tested; this component only picks the colour and glyph for the state.

const OK_FG = '#166534';
const OK_BG = '#dcfce7';
const WARN_FG = '#92400e';
const WARN_BG = '#fef3c7';

interface Props {
  /** True → the reassuring green banner; false → the amber advisory banner. */
  allClear: boolean;
  /** The one-line summary (from `checklistHeadline`). */
  headline: string;
}

export default function ChecklistSummary({ allClear, headline }: Props) {
  return (
    <header
      style={{
        display: 'flex',
        gap: 'var(--space-md)',
        alignItems: 'center',
        padding: 'var(--space-md)',
        background: allClear ? OK_BG : WARN_BG,
        color: allClear ? OK_FG : WARN_FG,
      }}
    >
      <span aria-hidden="true" style={{ fontSize: '1.1rem' }}>{allClear ? '✓' : '⚑'}</span>
      <div>
        <div style={{ fontWeight: 700 }}>Before you publish</div>
        <div style={{ fontSize: '0.85rem' }}>{headline}</div>
      </div>
    </header>
  );
}
