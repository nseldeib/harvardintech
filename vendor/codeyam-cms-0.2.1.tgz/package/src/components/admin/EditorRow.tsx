// One row in the /admin/editors roster: the person's avatar (or initials),
// name + email, their role and status badges with a relative "invited N ago",
// and the row actions. Purely presentational — the parent EditorsManager owns
// the roster state and the staging store, and passes the resend/remove handlers
// (absent for the owner, who can't be removed or re-invited).
import {
  displayName,
  formatInvitedAgo,
  initials,
  roleLabel,
  statusLabel,
  type EditorRecord,
} from '../../lib/editorsRegistry';
import {
  avatarFallback,
  avatarStyle,
  badgeGroup,
  dangerBtn,
  emailStyle,
  identityStyle,
  linkBtn,
  metaStyle,
  nameStyle,
  roleBadgeStyle,
  rowActions,
  rowStyle,
  statusBadgeStyle,
} from './editorsStyles';

interface Props {
  editor: EditorRecord;
  /** Reference time for the "invited N ago" phrase (injected for determinism). */
  nowIso: string;
  /** Re-send a pending/expired invite. Omitted → no resend action shown. */
  onResend?: (email: string) => void;
  /** Remove / revoke. Omitted (e.g. for the owner) → no remove action shown. */
  onRemove?: (email: string) => void;
}

export default function EditorRow({ editor, nowIso, onResend, onRemove }: Props) {
  const name = displayName(editor);
  const ago = formatInvitedAgo(editor.invitedAt, nowIso);
  const isOwner = editor.role === 'owner';
  const canResend = !isOwner && editor.status !== 'active' && onResend;
  const canRemove = !isOwner && onRemove;

  // The meta line under the name: active editors show nothing extra; pending /
  // expired invites show when they were invited so the owner can chase them.
  const meta =
    editor.status === 'active'
      ? ''
      : editor.status === 'expired'
        ? ago
          ? `Invite expired · sent ${ago}`
          : 'Invite expired'
        : ago
          ? `Invited ${ago}`
          : 'Invite pending';

  return (
    <li style={rowStyle}>
      {editor.avatarUrl ? (
        <img src={editor.avatarUrl} alt="" style={avatarStyle} />
      ) : (
        <span style={avatarFallback} aria-hidden="true">
          {initials(editor)}
        </span>
      )}

      <span style={identityStyle}>
        <span style={nameStyle} title={name}>
          {name}
        </span>
        <span style={emailStyle} title={editor.email}>
          {editor.email}
        </span>
        {meta && <span style={metaStyle}>{meta}</span>}
      </span>

      <span style={badgeGroup}>
        <span style={roleBadgeStyle(editor.role)}>{roleLabel(editor.role)}</span>
        <span style={statusBadgeStyle(editor.status)}>{statusLabel(editor.status)}</span>
      </span>

      <span style={rowActions}>
        {canResend && (
          <button type="button" style={linkBtn} onClick={() => onResend!(editor.email)}>
            {editor.status === 'expired' ? 'Resend' : 'Resend link'}
          </button>
        )}
        {canRemove && (
          <button
            type="button"
            style={dangerBtn}
            onClick={() => onRemove!(editor.email)}
            aria-label={`Remove ${name}`}
          >
            {editor.status === 'active' ? 'Remove' : 'Revoke'}
          </button>
        )}
      </span>
    </li>
  );
}
