// The "Upload to" row above the drop zone: which folder the next upload lands
// in. A select of the folders the library is really using (plus the images
// root), and an option to name one that does not exist yet — a dropdown alone
// cannot express "put this somewhere new", and a bare text field would turn the
// common case, reusing a folder, into typing.
//
// Presentational: it owns no state. The parent holds the choice via
// `useUploadDestination` and passes the blocking message down, so the same rule
// that disables the drop zone is the one shown here. Stays on ONE line in the
// compact variant so the picker modal does not grow a second section.
import type { CSSProperties } from 'react';
import FieldError from './FieldError';
import { NEW_FOLDER } from '../../lib/useUploadDestination';

interface Props {
  /** Folders in use, root first — see `libraryFolders`. */
  folders: string[];
  /** Current select value: a folder, '' for the root, or `NEW_FOLDER`. */
  choice: string;
  /** The typed folder name, shown only while `typing`. */
  newFolder: string;
  /** Whether the free-text input is showing. */
  typing: boolean;
  /** Why the destination is unusable, or null. */
  invalid: string | null;
  disabled?: boolean;
  /** Compact variant for the picker modal (smaller type, tighter controls). */
  compact?: boolean;
  onChoice: (value: string) => void;
  onNewFolder: (value: string) => void;
}

const fieldStyle = (compact: boolean): CSSProperties => ({
  fontSize: compact ? '0.8rem' : '0.85rem',
  padding: compact ? '0.2rem 0.35rem' : '0.3rem 0.45rem',
  borderRadius: 'var(--radius)',
  border: '1px solid var(--color-border)',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
});

export default function UploadDestinationField({
  folders,
  choice,
  newFolder,
  typing,
  invalid,
  disabled = false,
  compact = false,
  onChoice,
  onNewFolder,
}: Props) {
  return (
    <div>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          fontSize: compact ? '0.8rem' : '0.85rem',
          color: 'var(--color-muted)',
        }}
      >
        <label htmlFor="upload-destination" style={{ whiteSpace: 'nowrap' }}>
          Upload to
        </label>
        <select
          id="upload-destination"
          value={choice}
          disabled={disabled}
          onChange={(e) => onChoice(e.target.value)}
          style={fieldStyle(compact)}
        >
          {folders.map((folder) => (
            <option key={folder || 'root'} value={folder}>
              {folder ? `${folder}/` : 'Images root'}
            </option>
          ))}
          <option value={NEW_FOLDER}>New folder…</option>
        </select>
        {typing && (
          <input
            type="text"
            value={newFolder}
            placeholder="folder name"
            aria-label="New folder name"
            disabled={disabled}
            onChange={(e) => onNewFolder(e.target.value)}
            style={{ ...fieldStyle(compact), minWidth: 0, flex: '1 1 8rem' }}
          />
        )}
      </div>

      <FieldError error={invalid ?? undefined} />
    </div>
  );
}
