// The standalone Media gallery island (the `/admin/media` page body).
//
// Shows every image in the library as a grid of MediaCards with an upload zone
// on top. "Every image" includes ones the CMS never uploaded: the library it
// receives is a merge of the `public/images` scan with the manifest, so a site
// that already had an images tree sees it here on first open. Uploads are STAGED
// (image bytes + manifest edit) via `mediaStaging`, so they join the same
// one-commit publish as content edits — the global StagingBar picks them up. The
// gallery reflects staged-but-uncommitted uploads immediately by re-merging the
// staging set over the library, and stays in sync as changes are staged or
// discarded elsewhere.
import { useEffect, useMemo, useState } from 'react';
import { assetRepoPath, libraryFolders, type MediaAsset, type MediaManifest } from '../../lib/mediaLibrary';
import { currentLibrary, stageUpload, discardUpload, reorderMedia } from '../../lib/mediaStaging';
import { saveUploadDestination } from '../../lib/uploadDestination';
import { useListDrag } from '../../lib/useListDrag';
import { loadChanges, subscribe } from '../../lib/pendingChangesStore';
import MediaCard from './MediaCard';
import MediaUploader from './MediaUploader';
import MediaLibraryEmpty from './MediaLibraryEmpty';
import MediaErrorNotice from './MediaErrorNotice';
import MediaCardRemoveButton from './MediaCardRemoveButton';
import MediaGrid from './MediaGrid';

interface Props {
  /**
   * What the gallery shows: the `public/images` scan merged with the manifest,
   * so a site's existing images are in the library without ever being uploaded.
   */
  library: MediaManifest;
  /** The raw committed manifest read from disk (the staged-change diff baseline). */
  committed: MediaManifest;
  /** Seed the view for isolated-component scenarios (skips the store subscription). */
  initialManifest?: MediaManifest;
}

export default function MediaLibrary({ library, committed, initialManifest }: Props) {
  const [manifest, setManifest] = useState<MediaManifest>(initialManifest ?? library);
  const [error, setError] = useState('');

  // Track the staging set so uploads/discards elsewhere reflect here. Scenarios
  // pass initialManifest and stay on it.
  useEffect(() => {
    if (initialManifest) return;
    const sync = () => setManifest(currentLibrary(library, committed));
    sync();
    return subscribe(sync);
  }, [library, committed, initialManifest]);

  const stagedFilenames = useMemo(() => {
    const paths = new Set(loadChanges().map((c) => c.path));
    return new Set(manifest.assets.filter((a) => paths.has(assetRepoPath(a.filename))).map((a) => a.filename));
  }, [manifest]);

  // Offered as upload destinations: whatever folders the visible library is
  // really using, so the list reflects the tree rather than any config.
  const folders = useMemo(() => libraryFolders(manifest), [manifest]);

  const onFiles = async (files: File[], destination: string) => {
    setError('');
    try {
      for (const file of files) await stageUpload(file, library, committed, {}, destination);
      saveUploadDestination(destination);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  };

  // Drop a staged upload — unstage its blob and trim it from the manifest.
  const onRemove = (asset: MediaAsset) => discardUpload(committed, asset.filename);

  // Drag-reorder the gallery. In isolated-component scenarios (initialManifest)
  // there's no store subscription, so reflect the new order in local state too;
  // on the live page the subscription already re-derives it from staging.
  const drag = useListDrag((from, to) => {
    reorderMedia(library, committed, from, to);
    if (initialManifest) {
      setManifest((m) => ({
        assets: (() => {
          const next = [...m.assets];
          const [moved] = next.splice(from, 1);
          next.splice(to, 0, moved);
          return next;
        })(),
      }));
    }
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <MediaUploader onFiles={onFiles} folders={folders} />

      <MediaErrorNotice message={error} />

      {manifest.assets.length === 0 ? (
        <MediaLibraryEmpty />
      ) : (
        <MediaGrid>
          {manifest.assets.map((asset, i) => {
            const staged = stagedFilenames.has(asset.filename);
            return (
              <MediaCard
                key={asset.filename}
                asset={asset}
                staged={staged}
                rowDragProps={drag.rowProps(i)}
                handleProps={drag.handleProps(i)}
                isDragging={drag.dragIndex === i}
                isDropTarget={drag.overIndex === i && drag.dragIndex !== i}
                action={staged ? <MediaCardRemoveButton onClick={() => onRemove(asset)} /> : null}
              />
            );
          })}
        </MediaGrid>
      )}
    </div>
  );
}
