// The single-entry editor island.
//
// Composes one EntryField per collection field plus a markdown body textarea and
// an actions footer, bound to local state. "Stage change" does NOT write the file
// — it serializes the edited values to markdown and adds a PendingChange to the
// browser staging set (`pendingChangesStore`); the StagingBar picks it up and the
// actual commit happens later, all at once. The baseline for dirty-detection and
// diffing is the entry NORMALIZED through our serializer, so re-serialization
// order/quoting never reads as a spurious edit and reverting every field cleanly
// unstages the entry.
import { useEffect, useMemo, useRef, useState } from 'react';
import type { CollectionName } from '../../lib/adminDashboard';
import {
  COLLECTION_FIELDS,
  fieldOrder,
  formValuesToData,
  dataToFormValues,
  extractExtras,
  entryLabel,
  labelFieldName,
  validateRequiredFields,
  stageStatusMessage,
  type FieldDef,
  type RawFieldValue,
  type RawRowValue,
} from '../../lib/entryEditor';
import { serializeEntry, parseEntry, type FrontmatterValue } from '../../lib/frontmatter';
import type { PendingChange } from '../../lib/pendingChanges';
import type { RepoTarget } from '../../lib/githubCommit';
import type { EntryRevision } from '../../lib/githubHistory';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import { EMPTY_MANIFEST, markdownImage, type MediaAsset, type MediaManifest } from '../../lib/mediaLibrary';
import EntryField, { fieldLabelStyle, fieldInputStyle } from './EntryField';
import ImageField from './ImageField';
import ListField from './ListField';
import MediaPickerModal from './MediaPickerModal';
import EntryPreview from './EntryPreview';
import EntryHistory from './EntryHistory';
import EntryTabs from './EntryTabs';
import SocialCardPreview from './SocialCardPreview';
import BodyToolbar from './BodyToolbar';
import SplitTabs from './SplitTabs';
import ViewOnSiteLink from './ViewOnSiteLink';
import UnsavedChangesDialog from './UnsavedChangesDialog';
import { guardedNavTarget } from '../../lib/unsavedGuard';
import { splitCss } from './entryPreviewStyles';

interface Props {
  collection: CollectionName;
  slug: string;
  path: string;
  /** The collection's editable fields. Omitted for a built-in collection (falls
   * back to `COLLECTION_FIELDS`); passed explicitly for a custom collection. */
  fields?: FieldDef[];
  initialValues: Record<string, RawFieldValue>;
  /** Frontmatter keys present in the entry but NOT in `fields` — e.g. a consumer
   * site's `embedUrl` or `chapter`. Carried through untouched on save so editing
   * an entry never drops frontmatter the CMS doesn't render. */
  initialExtras?: Record<string, FrontmatterValue>;
  initialBody: string;
  /** The media library (public/images scan merged with the manifest) the
   * cover-image + insert-image picker chooses from — so an image the site
   * already had is pickable without ever being uploaded. */
  mediaLibrary?: MediaManifest;
  /** The raw committed manifest — diff baseline for an upload staged from
   * the picker. */
  mediaCommitted?: MediaManifest;
  /** Configured public site base URL (`settings.siteUrl`) for the "View on site"
   * link; blank when the editor hasn't set one yet. */
  siteUrl?: string;
  /** Site-wide title/description (`settings.json`) — the last-resort fallbacks the
   * SEO share-card preview shows when an entry sets no override. */
  siteTitle?: string;
  siteDescription?: string;
  /** Which GitHub repo/branch this entry's history is read from, and where the
   * auth popup lives — threaded from `cms.json` for the History tab. Blank when
   * the CMS isn't connected to a repo yet. */
  repo?: RepoTarget;
  authEndpoint?: string;
  /** Open on a specific tab (scenario capture); defaults to the editor. */
  initialTab?: 'edit' | 'history';
  /** Seed the History tab's revision list for isolated-component scenarios. */
  historyInitialRevisions?: EntryRevision[];
}

const EMPTY_REPO: RepoTarget = { owner: '', repo: '', branch: 'main' };

/** What an open media picker is choosing for: a named image field, an image
 * sub-field inside a `list` row, or the body. */
type PickerTarget =
  | { kind: 'field'; name: string }
  | { kind: 'listImage'; field: string; row: number; sub: string }
  | { kind: 'body' };

/** Serialize the current form state to the markdown that would be committed.
 * `extras` are frontmatter keys the CMS does not render; they're carried through
 * so saving an entry never erases keys outside the collection's field list. */
function toMarkdown(
  fields: FieldDef[],
  values: Record<string, RawFieldValue>,
  body: string,
  extras: Record<string, FrontmatterValue>,
): string {
  const data = formValuesToData(fields, values, extras);
  return serializeEntry({ data, body }, fieldOrder(fields));
}

export default function EntryEditor({
  collection,
  slug,
  path,
  fields: propFields,
  initialValues,
  initialExtras = {},
  initialBody,
  mediaLibrary = EMPTY_MANIFEST,
  mediaCommitted = EMPTY_MANIFEST,
  siteUrl = '',
  siteTitle = '',
  siteDescription = '',
  repo = EMPTY_REPO,
  authEndpoint = '/auth',
  initialTab = 'edit',
  historyInitialRevisions,
}: Props) {
  const fields = propFields ?? (COLLECTION_FIELDS as Record<string, FieldDef[]>)[collection] ?? [];
  // The content fields render inline; the SEO group renders in its own panel with
  // the share-card preview.
  const contentFields = fields.filter((f) => f.group !== 'seo');
  const seoFields = fields.filter((f) => f.group === 'seo');
  const [values, setValues] = useState<Record<string, RawFieldValue>>(initialValues);
  // Passthrough frontmatter the form never renders. Stateful so restoring a past
  // version can swap in that version's own extras rather than the entry's.
  const [extras, setExtras] = useState<Record<string, FrontmatterValue>>(initialExtras);
  const [body, setBody] = useState(initialBody);
  const [staged, setStaged] = useState(false);
  const [picker, setPicker] = useState<PickerTarget | null>(null);
  // Top-level tab: the editor itself vs. this entry's git version history.
  const [tab, setTab] = useState<'edit' | 'history'>(initialTab);
  // Which pane shows on a narrow screen (ignored on wide, where both show).
  const [view, setView] = useState<'edit' | 'preview'>('edit');
  // When set, an in-app navigation is being held pending the unsaved-edits
  // dialog; it carries the destination to go to if the editor confirms leaving.
  const [pendingHref, setPendingHref] = useState<string | null>(null);
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  // Flipped just before a confirmed navigation so `beforeunload` lets it through
  // instead of stacking a second, native prompt on top of our dialog.
  const leavingRef = useRef(false);

  // The immutable baseline this entry is compared against.
  const original = useMemo(
    () => toMarkdown(fields, initialValues, initialBody, initialExtras),
    [fields, initialValues, initialBody, initialExtras],
  );
  const current = toMarkdown(fields, values, body, extras);
  const dirty = current !== original;

  // Required-field enforcement. `initialValues` is the baseline, so an entry that
  // ARRIVED with a blank required field shows the problem but is still stageable
  // — the CMS has to stay able to fix the entries that need fixing. A field the
  // editor blanks themselves blocks staging until they fill it back in.
  const required = useMemo(
    () => validateRequiredFields({ fields, values, baseline: initialValues }),
    [fields, values, initialValues],
  );
  const canStage = dirty && !required.blocked;

  // Reflect this entry's staged/unstaged status from the shared store.
  useEffect(() => {
    const sync = () => setStaged(loadChanges().some((c) => c.path === path));
    sync();
    return subscribe(sync);
  }, [path]);

  // Unsaved-changes guard. Only unstaged edits are at risk — staged edits live in
  // the pending-changes store and survive navigation. While dirty we (a) arm the
  // native `beforeunload` prompt for hard exits (refresh, close tab, typed URL)
  // and (b) capture-intercept clicks on in-app links so the styled dialog can
  // offer Stay / Leave / Stage & leave before a same-tab navigation.
  useEffect(() => {
    if (!dirty) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      if (leavingRef.current) return;
      e.preventDefault();
      e.returnValue = '';
    };
    const onClick = (e: MouseEvent) => {
      if (e.defaultPrevented || leavingRef.current) return;
      const anchor = (e.target as HTMLElement | null)?.closest?.('a');
      if (!anchor) return;
      const target = guardedNavTarget({
        href: anchor.href,
        rawHref: anchor.getAttribute('href') ?? '',
        targetAttr: anchor.target,
        sameOrigin: anchor.origin === window.location.origin,
        modified: e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0,
      });
      if (!target) return;
      e.preventDefault();
      setPendingHref(target);
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    document.addEventListener('click', onClick, true);
    return () => {
      window.removeEventListener('beforeunload', onBeforeUnload);
      document.removeEventListener('click', onClick, true);
    };
  }, [dirty]);

  const setField = (name: string, value: RawFieldValue) =>
    setValues((prev) => ({ ...prev, [name]: value }));

  /** Insert a Markdown image reference at the body caret (or append if unfocused). */
  const insertIntoBody = (asset: MediaAsset) => {
    const snippet = markdownImage(asset);
    const el = bodyRef.current;
    const at = el ? el.selectionStart : body.length;
    const before = body.slice(0, at);
    const after = body.slice(at);
    const sep = before && !before.endsWith('\n') ? '\n\n' : '';
    setBody(`${before}${sep}${snippet}\n${after}`);
  };

  /** Set an image sub-field's url inside a `list` field's row. */
  const setRowImage = (fieldName: string, row: number, sub: string, url: string) =>
    setValues((prev) => {
      const rows = Array.isArray(prev[fieldName]) ? [...(prev[fieldName] as RawRowValue[])] : [];
      rows[row] = { ...rows[row], [sub]: url };
      return { ...prev, [fieldName]: rows };
    });

  /** Resolve a picker selection to its target: a cover field, a list-row image,
   * or the body. */
  const onPickImage = (asset: MediaAsset) => {
    if (picker?.kind === 'field') setField(picker.name, asset.url);
    else if (picker?.kind === 'listImage') setRowImage(picker.field, picker.row, picker.sub, asset.url);
    else if (picker?.kind === 'body') insertIntoBody(asset);
    setPicker(null);
  };

  const onStage = () => {
    // Guards the button AND the dialog's "Stage & leave", which calls this
    // directly — a blocked entry must not slip into the staging set either way.
    if (!canStage) return;
    const data = formValuesToData(fields, values, extras);
    const change: PendingChange = {
      collection,
      slug,
      path,
      title: entryLabel(data, slug, labelFieldName(fields)),
      original,
      updated: current,
    };
    stageChange(change);
  };

  const onRevert = () => {
    setValues(initialValues);
    setExtras(initialExtras);
    setBody(initialBody);
    discardChange(path);
  };

  /** Load a past version's raw markdown into the editor as unsaved edits, then
   * switch back to the editor. It reads as a normal edit (dirty vs. the current
   * baseline), so the existing Stage → review → publish flow takes it from here
   * — restore never commits or force-pushes on its own. */
  const onRestoreVersion = (raw: string) => {
    const { data, body: restoredBody } = parseEntry(raw);
    setValues(dataToFormValues(fields, data));
    setExtras(extractExtras(fields, data));
    setBody(restoredBody);
    setTab('edit');
    setView('edit');
  };

  /** Complete a held navigation, bypassing the `beforeunload` guard. */
  const navigateAway = (href: string) => {
    leavingRef.current = true;
    window.location.href = href;
  };
  const onStayOnEntry = () => setPendingHref(null);
  const onLeaveAnyway = () => pendingHref && navigateAway(pendingHref);
  const onStageAndLeave = () => {
    onStage();
    if (pendingHref) navigateAway(pendingHref);
  };

  /** Render one field by type: the media picker for images, the plain input
   * otherwise. Shared by the content fields and the SEO panel. */
  const renderField = (field: FieldDef) =>
    field.type === 'list' ? (
      <ListField
        key={field.name}
        field={field}
        rows={Array.isArray(values[field.name]) ? (values[field.name] as RawRowValue[]) : []}
        onChange={(rows) => setField(field.name, rows)}
        onPickImage={(row, sub) => setPicker({ kind: 'listImage', field: field.name, row, sub })}
        errors={required.rowErrors[field.name]}
      />
    ) : field.type === 'image' ? (
      <ImageField
        key={field.name}
        field={field}
        value={String(values[field.name] ?? '')}
        onPick={() => setPicker({ kind: 'field', name: field.name })}
        onClear={() => setField(field.name, '')}
        error={required.fieldErrors[field.name]}
      />
    ) : (
      <EntryField
        key={field.name}
        field={field}
        value={values[field.name]}
        onChange={(v) => setField(field.name, v)}
        error={required.fieldErrors[field.name]}
      />
    );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <style>{splitCss}</style>

      <EntryTabs tab={tab} onChange={setTab} />

      {tab === 'history' ? (
        <EntryHistory
          repo={repo}
          authEndpoint={authEndpoint}
          path={path}
          onRestore={onRestoreVersion}
          initialRevisions={historyInitialRevisions}
        />
      ) : (
        <>
      <SplitTabs view={view} onChange={setView} />

      <div className="cy-split" data-view={view}>
        <div className="cy-pane-edit" style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
        {contentFields.map(renderField)}

        <div>
          <label style={fieldLabelStyle} htmlFor="f-body">
            Body <span style={{ fontWeight: 400 }}>· markdown</span>
          </label>
          <BodyToolbar
            value={body}
            onChange={setBody}
            textareaRef={bodyRef}
            onInsertImage={() => setPicker({ kind: 'body' })}
          />
          <textarea
            id="f-body"
            ref={bodyRef}
            value={body}
            rows={12}
            onChange={(e) => setBody(e.target.value)}
            style={{ ...fieldInputStyle, resize: 'vertical', fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}
          />
        </div>

        {seoFields.length > 0 && (
          <section
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 'var(--space-md)',
              borderTop: '1px solid var(--color-border)',
              paddingTop: 'var(--space-md)',
            }}
          >
            <div>
              <h3 style={{ margin: 0, fontSize: '1rem' }}>SEO &amp; Social</h3>
              <p style={{ margin: '0.25rem 0 0', fontSize: '0.82rem', color: 'var(--color-muted)' }}>
                Optional overrides for search results and social shares. Leave blank to fall
                back to this entry’s own fields and the site defaults.
              </p>
            </div>
            {seoFields.map(renderField)}
            <SocialCardPreview
              collection={collection}
              slug={slug}
              values={values}
              labelField={labelFieldName(fields)}
              siteTitle={siteTitle}
              siteDescription={siteDescription}
              siteUrl={siteUrl}
            />
          </section>
        )}
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--space-md)',
          borderTop: '1px solid var(--color-border)',
          paddingTop: 'var(--space-md)',
        }}
      >
        <button
          type="button"
          onClick={onStage}
          disabled={!canStage}
          style={{
            padding: '0.5rem 1.1rem',
            borderRadius: 'var(--radius)',
            border: 'none',
            fontWeight: 600,
            cursor: canStage ? 'pointer' : 'not-allowed',
            background: canStage ? 'var(--color-accent)' : 'var(--color-border)',
            color: canStage ? '#fff' : 'var(--color-muted)',
          }}
        >
          {staged && !dirty ? 'Staged ✓' : 'Stage change'}
        </button>

        {(dirty || staged) && (
          <button
            type="button"
            onClick={onRevert}
            style={{
              padding: '0.5rem 1.1rem',
              borderRadius: 'var(--radius)',
              border: '1px solid var(--color-border)',
              background: 'transparent',
              color: 'var(--color-fg)',
              cursor: 'pointer',
            }}
          >
            Revert edits
          </button>
        )}

        {/* A greyed button with no reason is its own bug: when validation is what
            blocks staging, the footer says which field and why. */}
        <span
          style={{
            fontSize: '0.85rem',
            color: required.blocked ? 'var(--color-danger, #c0392b)' : 'var(--color-muted)',
          }}
        >
          {stageStatusMessage({ dirty, staged, required })}
        </span>

        {/* This entry exists in committed content, so it has a live page. */}
        <span style={{ marginLeft: 'auto' }}>
          <ViewOnSiteLink published siteUrl={siteUrl} collection={collection} slug={slug} />
        </span>
      </div>
        </div>

        <div className="cy-pane-preview">
          <EntryPreview collection={collection} values={values} body={body} labelField={labelFieldName(fields)} />
        </div>
      </div>
        </>
      )}

      {picker && (
        <MediaPickerModal
          library={mediaLibrary}
          committed={mediaCommitted}
          purpose={picker.kind === 'body' ? 'insert' : 'cover'}
          selectedUrl={
            picker.kind === 'field'
              ? String(values[picker.name] ?? '')
              : picker.kind === 'listImage'
                ? String((values[picker.field] as RawRowValue[] | undefined)?.[picker.row]?.[picker.sub] ?? '')
                : undefined
          }
          onSelect={onPickImage}
          onClose={() => setPicker(null)}
        />
      )}

      {pendingHref && (
        <UnsavedChangesDialog
          onStay={onStayOnEntry}
          onLeave={onLeaveAnyway}
          onStageAndLeave={onStageAndLeave}
        />
      )}
    </div>
  );
}
