// The picker's empty state, for a project with no images at all.
//
// Distinct from MediaLibraryEmpty: that one is the gallery's day-one nudge, this
// one appears mid-task while the editor is trying to pick an image, so it points
// at the upload zone directly above rather than introducing the library. Since
// the library adopts whatever is in `public/images`, reaching this state means
// the site genuinely has no images — not merely that it has never uploaded any.
export default function MediaPickerEmpty() {
  return (
    <p style={{ color: 'var(--color-muted)', textAlign: 'center', padding: 'var(--space-lg)', margin: 0 }}>
      No images in the library yet — upload one above to use it here.
    </p>
  );
}
