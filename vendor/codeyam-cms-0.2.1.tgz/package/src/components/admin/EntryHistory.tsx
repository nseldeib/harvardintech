// The "History" tab of the entry editor.
//
// CodeYam CMS's content lives in git, so an entry's past versions are just the
// commits that touched its file. This island lists them (newest first), lets the
// editor open one to see what it looked like, and restores an older version by
// handing its raw markdown back to the parent editor (`onRestore`) — which loads
// it as unsaved edits and stages it through the normal review → publish pipeline.
// Nothing is force-pushed here.
//
// Both reads are injected (`loadHistory` / `loadRevision`), defaulting to the
// real GitHub-token paths, so isolated-component scenarios and unit tests drive
// every state — loading, populated, viewing, empty, error — without a live repo.
// This mirrors how PublishPage seeds its transports and `initial*` props.
import { useEffect, useState } from 'react';
import type { RepoTarget, FetchFn } from '../../lib/githubCommit';
import { fetchEntryHistory, fetchEntryAtCommit, type EntryRevision } from '../../lib/githubHistory';
import { ensureGithubToken } from '../../lib/githubAuth';
import { markExpired } from '../../lib/authSession';
import RevisionRow from './RevisionRow';
import RevisionViewer from './RevisionViewer';
import { historyGhostBtn, historyErrorText } from './historyStyles';

/** Which sub-view the tab is showing. */
type Phase = 'loading' | 'list' | 'error' | 'viewing';

/** The revision currently open in the read-only viewer, with its fetched body. */
interface Selected {
  revision: EntryRevision;
  /** The entry's raw markdown as of this revision; null while still loading. */
  raw: string | null;
  error?: string;
}

interface Props {
  repo: RepoTarget;
  authEndpoint: string;
  /** Repo-relative path of the entry file, e.g. `src/content/blog/welcome.md`. */
  path: string;
  /** Restore handoff: the parent loads this raw markdown as unsaved edits.
   * Optional so an Astro-hosted isolated scenario (which can't pass a function
   * prop) still renders — there, Restore is a no-op used only for capture. */
  onRestore?: (raw: string) => void;
  /** Override the history-list transport (scenarios / tests). Defaults to GitHub. */
  loadHistory?: () => Promise<EntryRevision[]>;
  /** Override the at-commit content transport (scenarios / tests). Defaults to GitHub. */
  loadRevision?: (sha: string) => Promise<string>;
  /** Seed the revision list for isolated-component scenarios (skips the fetch). */
  initialRevisions?: EntryRevision[];
  /** Open directly into a phase for scenario capture. */
  initialPhase?: Phase;
  /** Seed an open revision (the `viewing` state) for scenario capture. */
  initialSelected?: Selected;
  /** Seed the error message for the `error` state. */
  initialError?: string;
}

export default function EntryHistory({
  repo,
  authEndpoint,
  path,
  onRestore,
  loadHistory,
  loadRevision,
  initialRevisions,
  initialPhase,
  initialSelected,
  initialError,
}: Props) {
  const [phase, setPhase] = useState<Phase>(
    initialPhase ?? (initialRevisions ? 'list' : 'loading'),
  );
  const [revisions, setRevisions] = useState<EntryRevision[]>(initialRevisions ?? []);
  const [selected, setSelected] = useState<Selected | null>(initialSelected ?? null);
  const [error, setError] = useState<string>(initialError ?? '');

  /** Fetch the history list — the injected transport, or the real GitHub read. */
  const runLoadHistory = async (): Promise<EntryRevision[]> => {
    if (loadHistory) return loadHistory();
    const token = await ensureGithubToken(authEndpoint);
    try {
      return await fetchEntryHistory(repo, token, path, globalThis.fetch as unknown as FetchFn);
    } catch (e) {
      // A rejected/expired token shouldn't linger; expire the session so the
      // next attempt re-authenticates — the same guard PublishPage uses.
      markExpired();
      throw e;
    }
  };

  const load = () => {
    setPhase('loading');
    setError('');
    runLoadHistory()
      .then((revs) => {
        setRevisions(revs);
        setPhase('list');
      })
      .catch((e) => {
        setError(e instanceof Error ? e.message : 'Could not load history.');
        setPhase('error');
      });
  };

  useEffect(() => {
    // Seeded scenarios stay on their injected state; live editors fetch on mount.
    if (initialRevisions || initialPhase) return;
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path]);

  const runLoadRevision = (sha: string): Promise<string> => {
    if (loadRevision) return loadRevision(sha);
    return ensureGithubToken(authEndpoint).then((token) =>
      fetchEntryAtCommit(repo, token, path, sha, globalThis.fetch as unknown as FetchFn),
    );
  };

  const openRevision = (revision: EntryRevision) => {
    setSelected({ revision, raw: null });
    setPhase('viewing');
    runLoadRevision(revision.sha)
      .then((raw) => setSelected({ revision, raw }))
      .catch((e) =>
        setSelected({
          revision,
          raw: null,
          error: e instanceof Error ? e.message : 'Could not load this version.',
        }),
      );
  };

  const backToList = () => {
    setSelected(null);
    setPhase('list');
  };

  // ── Loading ────────────────────────────────────────────────────────────────
  if (phase === 'loading') {
    return <p style={{ color: 'var(--color-muted)' }}>Loading version history…</p>;
  }

  // ── Error ────────────────────────────────────────────────────────────────
  if (phase === 'error') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)', alignItems: 'flex-start' }}>
        <p style={{ ...historyErrorText, margin: 0 }}>
          Couldn’t load version history{error ? `: ${error}` : '.'}
        </p>
        <button type="button" style={historyGhostBtn} onClick={load}>
          Try again
        </button>
      </div>
    );
  }

  // ── Viewing one revision ─────────────────────────────────────────────────
  if (phase === 'viewing' && selected) {
    return (
      <RevisionViewer
        revision={selected.revision}
        raw={selected.raw}
        error={selected.error}
        onBack={backToList}
        onRestore={onRestore}
      />
    );
  }

  // ── List ─────────────────────────────────────────────────────────────────
  // The newest commit IS the entry's current content — it's the baseline, not a
  // version to restore "back" to, so it's labelled and its restore is omitted.
  const [current, ...older] = revisions;

  if (revisions.length === 0) {
    return (
      <p style={{ color: 'var(--color-muted)' }}>
        No version history yet — this entry hasn’t been committed to the repo.
      </p>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      <p style={{ margin: 0, fontSize: '0.85rem', color: 'var(--color-muted)' }}>
        Every saved version of this entry, newest first. Open an earlier one to see it, then
        restore it as a pending change.
      </p>

      <RevisionRow revision={current} current />

      {older.length === 0 ? (
        <p style={{ margin: 0, fontSize: '0.82rem', color: 'var(--color-muted)' }}>
          This is the only version so far — there’s nothing earlier to restore yet.
        </p>
      ) : (
        older.map((rev) => <RevisionRow key={rev.sha} revision={rev} onView={openRevision} />)
      )}
    </div>
  );
}
