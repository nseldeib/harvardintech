// The admin sign-in gate. Mounted once in AdminLayout, so it rides along on
// every admin page. While the editor is NOT signed in it renders a full-viewport,
// opaque overlay that hides the admin content server-rendered behind it; once
// signed in it renders nothing and the admin shell shows through.
//
// The gate offers whichever sign-in paths the site enabled (see `cmsConfig`):
//   • token  — paste a fine-grained GitHub token; validated + stored in the
//              browser. Zero infrastructure — the server-free default.
//   • worker — "Sign in with GitHub" via the cms-auth-worker popup, for sites
//              willing to run that relay.
// Both can be on at once; the token form is the primary action and the worker
// button drops to a secondary "or" option beneath it.
//
// The session lives in the shared `authSession` store, so signing in here also
// lights up the header AccountMenu, and an expired token discovered while
// committing (StagingBar) re-shows this gate — with staged edits preserved,
// because they live in their own localStorage keys, not the token this clears.
//
// `initialSession` / `initialToken` / `initialError` + `onSubmitToken` / `onSignIn`
// are scenario/test seams: when a session is injected the gate renders that fixed
// state and drives the injected handlers instead of the live store, so
// isolated-component scenarios capture each state without a popup or a network call.
import { useEffect, useState } from 'react';
import { getSession, signIn, signInWithToken, subscribe, type AuthSession } from '../../lib/authSession';
import type { CmsAuthOptions } from '../../lib/cmsConfig';
import type { RepoTarget } from '../../lib/githubCommit';
import TokenSignInForm from './TokenSignInForm';
import MagicLinkSignIn from './MagicLinkSignIn';
import {
  errorNote,
  expiredNote,
  gateCard,
  gateMark,
  gateOverlay,
  gateSubtitle,
  gateTitle,
  orDivider,
  orRule,
  signInBtn,
  workerBtnSecondary,
} from './authStyles';

interface Props {
  authEndpoint: string;
  /** Which sign-in paths this site presents. */
  auth: CmsAuthOptions;
  /** The publish target — named in the token helper so editors scope correctly. */
  repo: RepoTarget;
  /** The site's display name — shown to invited editors on the magic-link path
   * (which never mentions GitHub). Falls back to the repo name. */
  siteTitle?: string;
  /** Scenario/test seam: render this fixed session instead of the live store. */
  initialSession?: AuthSession;
  /** Scenario/test seam: pre-fill the token input (e.g. the invalid-token state). */
  initialToken?: string;
  /** Scenario/test seam: pre-fill the inline error (e.g. the invalid-token state). */
  initialError?: string;
  /** Scenario/test seam: override the worker sign-in action (defaults to the store). */
  onSignIn?: () => void;
  /** Scenario/test seam: override the token submit action (defaults to the store). */
  onSubmitToken?: (token: string) => void;
}

export default function AuthGate({
  authEndpoint,
  auth,
  repo,
  siteTitle,
  initialSession,
  initialToken,
  initialError,
  onSignIn,
  onSubmitToken,
}: Props) {
  const scenario = initialSession !== undefined;
  const [session, setSession] = useState<AuthSession>(initialSession ?? { status: 'signed-out', user: null });
  const [error, setError] = useState<string>(initialError ?? '');
  // When magic-link is enabled it is the primary, GitHub-invisible surface; a
  // developer can drop to the token/worker card via the secondary link below.
  const [devMode, setDevMode] = useState(false);

  useEffect(() => {
    // In scenario mode stay on the injected session; otherwise track the store.
    if (scenario) return;
    const sync = () => setSession(getSession());
    sync();
    return subscribe(sync);
  }, [scenario]);

  // Signed in: the gate steps out of the way entirely.
  if (session.status === 'signed-in') return null;

  const authenticating = session.status === 'authenticating';

  const submitToken = async (token: string) => {
    setError('');
    if (onSubmitToken) {
      onSubmitToken(token);
      return;
    }
    try {
      await signInWithToken(token);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  };

  const signInWithWorker = async () => {
    if (onSignIn) {
      onSignIn();
      return;
    }
    setError('');
    try {
      await signIn(authEndpoint);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  };

  const showToken = auth.token;
  const showWorker = auth.worker;

  // Magic-link path: the invited, non-technical editor's experience. It owns the
  // whole overlay (its own multi-step flow), so we delegate to it rather than
  // nesting it in the developer card. A site that also enables token/worker gets
  // a quiet "Developer sign-in" link to reveal that card.
  if (auth.magicLink && !devMode) {
    return (
      <>
        <MagicLinkSignIn
          siteTitle={siteTitle || repo.repo || 'this site'}
          initialStatus={session.status === 'expired' ? 'expired' : undefined}
        />
        {(showToken || showWorker) && (
          <button
            type="button"
            onClick={() => setDevMode(true)}
            style={{
              position: 'fixed',
              bottom: 'var(--space-lg)',
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 101,
              background: 'transparent',
              border: 'none',
              color: 'var(--color-muted)',
              fontSize: '0.8rem',
              textDecoration: 'underline',
              cursor: 'pointer',
            }}
          >
            Developer sign-in
          </button>
        )}
      </>
    );
  }

  return (
    <div style={gateOverlay} role="dialog" aria-modal="true" aria-label="Sign in to CodeYam CMS">
      <div style={gateCard}>
        <span style={gateMark} aria-hidden="true">C</span>
        <h1 style={gateTitle}>CodeYam CMS</h1>
        <p style={gateSubtitle}>Sign in to manage this site</p>

        {session.status === 'expired' && (
          <p style={expiredNote}>
            Your session expired. Sign in again to keep working — your unsaved changes are still here.
          </p>
        )}

        {showToken && (
          <TokenSignInForm
            repo={repo}
            disabled={authenticating}
            initialToken={initialToken}
            onSubmit={submitToken}
          />
        )}

        {showToken && showWorker && (
          <div style={orDivider}>
            <span style={orRule} />
            or
            <span style={orRule} />
          </div>
        )}

        {showWorker && (
          <button
            type="button"
            style={showToken ? workerBtnSecondary : signInBtn}
            onClick={signInWithWorker}
            disabled={authenticating}
          >
            {authenticating ? 'Signing in…' : 'Sign in with GitHub'}
          </button>
        )}

        {error && <p style={errorNote}>{error}</p>}
      </div>
    </div>
  );
}
