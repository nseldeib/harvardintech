// One field-definition row in the collection builder: a label, a type picker, an
// optional toggle, the move/remove controls, and a hint line showing the derived
// frontmatter key (or the row's validation error). When the type is a repeatable
// `list`, the row expands to a compact, one-level-deep sub-field editor (scalar
// types only) that mirrors this same row. Presentational — the parent
// CollectionBuilder owns the fields array and forwards each row's edits. Mirrors
// SocialLinkRow / NavItemRow in the other list editors.
import type { HTMLAttributes } from 'react';
import {
  CUSTOM_FIELD_TYPES,
  SUBFIELD_TYPES,
  addDraftField,
  emptyDraftField,
  fieldFinalId,
  moveDraftField,
  removeDraftField,
  updateDraftField,
  type DraftField,
} from '../../lib/collectionRegistry';
import { fieldLabelStyle, fieldInputStyle } from './EntryField';
import { dragRowStyle, addBtnStyle } from './configEditorStyles';
import RowControls from './RowControls';
import DragHandle from './DragHandle';

const cardStyle = {
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-md)',
  background: 'var(--color-bg)',
};

interface Props {
  field: DraftField;
  /** Row position — drives the input ids and the up/down enablement. */
  index: number;
  /** This row's validation message, or null when valid. */
  error: string | null;
  /** Per-sub-field validation messages when this is a list field (else undefined). */
  subErrors?: (string | null)[];
  canUp: boolean;
  canDown: boolean;
  onChange: (patch: Partial<DraftField>) => void;
  onMove: (delta: number) => void;
  onRemove: () => void;
  /** Drag-reorder wiring from `useListDrag` (absent = no drag, buttons only). */
  rowDragProps?: HTMLAttributes<HTMLElement>;
  handleProps?: HTMLAttributes<HTMLSpanElement>;
  isDragging?: boolean;
  isDropTarget?: boolean;
}

export default function CollectionFieldRow({
  field,
  index,
  error,
  subErrors,
  canUp,
  canDown,
  onChange,
  onMove,
  onRemove,
  rowDragProps,
  handleProps,
  isDragging = false,
  isDropTarget = false,
}: Props) {
  const isList = field.type === 'list';
  const subFields = field.fields ?? [];

  // Switching TO a list seeds a starter sub-field so the editor has a row to fill;
  // switching away drops the (now irrelevant) sub-schema.
  const onTypeChange = (type: DraftField['type']) => {
    if (type === 'list') {
      onChange({ type, fields: subFields.length > 0 ? subFields : [emptyDraftField()] });
    } else {
      onChange({ type, fields: undefined });
    }
  };

  const patchSub = (fields: DraftField[]) => onChange({ fields });

  return (
    <div style={{ ...cardStyle, ...dragRowStyle(isDragging, isDropTarget) }} {...rowDragProps}>
      <div style={{ display: 'flex', gap: 'var(--space-sm)', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {handleProps && <DragHandle label="Drag to reorder field" {...handleProps} />}
        <div style={{ flex: '2 1 200px' }}>
          <label style={fieldLabelStyle} htmlFor={`fl-${index}`}>
            Field label
          </label>
          <input
            id={`fl-${index}`}
            value={field.label}
            placeholder="e.g. Company name"
            onChange={(e) => onChange({ label: e.target.value })}
            style={{
              ...fieldInputStyle,
              borderColor: error ? 'var(--color-danger, #c0392b)' : 'var(--color-border)',
            }}
          />
        </div>
        <div style={{ flex: '1 1 130px' }}>
          <label style={fieldLabelStyle} htmlFor={`ft-${index}`}>
            Type
          </label>
          <select
            id={`ft-${index}`}
            value={field.type}
            onChange={(e) => onTypeChange(e.target.value as DraftField['type'])}
            style={fieldInputStyle}
          >
            {CUSTOM_FIELD_TYPES.map((t) => (
              <option key={t.type} value={t.type}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)', paddingTop: '1.5rem' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.85rem' }}>
            <input
              type="checkbox"
              checked={field.optional}
              onChange={(e) => onChange({ optional: e.target.checked })}
            />
            Optional
          </label>
          <RowControls
            canUp={canUp}
            canDown={canDown}
            onUp={() => onMove(-1)}
            onDown={() => onMove(1)}
            onRemove={onRemove}
            removeLabel="Remove field"
          />
        </div>
      </div>
      <p
        style={{
          margin: '0.4rem 0 0',
          fontSize: '0.78rem',
          color: error ? 'var(--color-danger, #c0392b)' : 'var(--color-muted)',
        }}
      >
        {error ?? (fieldFinalId(field) ? `frontmatter key: ${fieldFinalId(field)}` : 'Give this field a label.')}
      </p>

      {isList && (
        <div
          style={{
            marginTop: 'var(--space-md)',
            paddingLeft: 'var(--space-md)',
            borderLeft: '2px solid var(--color-border)',
            display: 'flex',
            flexDirection: 'column',
            gap: 'var(--space-sm)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--color-muted)' }}>
              Fields in each {field.label.trim() || 'item'}
            </span>
            <button
              type="button"
              onClick={() => patchSub(addDraftField(subFields))}
              style={{ ...addBtnStyle, padding: '0.3rem 0.7rem', fontSize: '0.85rem' }}
            >
              + Add sub-field
            </button>
          </div>
          {subFields.map((sub, si) => (
            <SubFieldRow
              key={si}
              field={sub}
              parentIndex={index}
              index={si}
              error={subErrors?.[si] ?? null}
              canUp={si > 0}
              canDown={si < subFields.length - 1}
              onChange={(p) => patchSub(updateDraftField(subFields, si, p))}
              onMove={(delta) => patchSub(moveDraftField(subFields, si, delta))}
              onRemove={() => patchSub(removeDraftField(subFields, si))}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface SubRowProps {
  field: DraftField;
  parentIndex: number;
  index: number;
  error: string | null;
  canUp: boolean;
  canDown: boolean;
  onChange: (patch: Partial<DraftField>) => void;
  onMove: (delta: number) => void;
  onRemove: () => void;
}

/** A compact sub-field row inside a list field: label, scalar type picker,
 * optional toggle, move/remove, and the derived-key / error hint. Exported so it
 * can be shown as an isolated-component scenario, like the other list rows. */
export function SubFieldRow({ field, parentIndex, index, error, canUp, canDown, onChange, onMove, onRemove }: SubRowProps) {
  const idBase = `slf-${parentIndex}-${index}`;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
      <div style={{ display: 'flex', gap: 'var(--space-sm)', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <div style={{ flex: '2 1 160px' }}>
          <label style={fieldLabelStyle} htmlFor={`${idBase}-label`}>
            Sub-field label
          </label>
          <input
            id={`${idBase}-label`}
            value={field.label}
            placeholder="e.g. Name"
            onChange={(e) => onChange({ label: e.target.value })}
            style={{
              ...fieldInputStyle,
              borderColor: error ? 'var(--color-danger, #c0392b)' : 'var(--color-border)',
            }}
          />
        </div>
        <div style={{ flex: '1 1 120px' }}>
          <label style={fieldLabelStyle} htmlFor={`${idBase}-type`}>
            Type
          </label>
          <select
            id={`${idBase}-type`}
            value={field.type}
            onChange={(e) => onChange({ type: e.target.value as DraftField['type'] })}
            style={fieldInputStyle}
          >
            {SUBFIELD_TYPES.map((t) => (
              <option key={t.type} value={t.type}>
                {t.label}
              </option>
            ))}
          </select>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-sm)', paddingTop: '1.5rem' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', fontSize: '0.8rem' }}>
            <input
              type="checkbox"
              checked={field.optional}
              onChange={(e) => onChange({ optional: e.target.checked })}
            />
            Optional
          </label>
          <RowControls
            canUp={canUp}
            canDown={canDown}
            onUp={() => onMove(-1)}
            onDown={() => onMove(1)}
            onRemove={onRemove}
            removeLabel="Remove sub-field"
          />
        </div>
      </div>
      <p
        style={{
          margin: 0,
          fontSize: '0.75rem',
          color: error ? 'var(--color-danger, #c0392b)' : 'var(--color-muted)',
        }}
      >
        {error ?? (fieldFinalId(field) ? `key: ${fieldFinalId(field)}` : 'Give this field a label.')}
      </p>
    </div>
  );
}
