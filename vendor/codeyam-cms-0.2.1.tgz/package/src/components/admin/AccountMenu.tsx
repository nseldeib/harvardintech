// The signed-in editor's identity in the admin header — avatar + GitHub handle
// plus a Sign out control — shown on every admin page. Reads the shared
// `authSession` store, so it lights up the moment the AuthGate sign-in resolves
// and clears the moment the session ends. Renders nothing while signed out (the
// gate covers the page then anyway).
//
// `initialSession` + `onSignOut` are scenario/test seams: when provided the chip
// renders that fixed identity and drives the injected handler instead of the
// live store.
import { useEffect, useState } from 'react';
import { getSession, signOut, subscribe, type AuthSession } from '../../lib/authSession';
import { accountName, accountWrap, avatarImg, signOutBtn } from './authStyles';

interface Props {
  /** Scenario/test seam: render this fixed session instead of the live store. */
  initialSession?: AuthSession;
  /** Scenario/test seam: override sign-out (defaults to the store). */
  onSignOut?: () => void;
}

export default function AccountMenu({ initialSession, onSignOut }: Props) {
  const scenario = initialSession !== undefined;
  const [session, setSession] = useState<AuthSession>(initialSession ?? { status: 'signed-out', user: null });

  useEffect(() => {
    if (scenario) return;
    const sync = () => setSession(getSession());
    sync();
    return subscribe(sync);
  }, [scenario]);

  if (session.status !== 'signed-in' || !session.user) return null;

  const { login, name, avatarUrl } = session.user;

  return (
    <span style={accountWrap}>
      <img src={avatarUrl} alt="" style={avatarImg} />
      <span style={accountName} title={name ?? login}>{login}</span>
      <button type="button" style={signOutBtn} onClick={() => (onSignOut ? onSignOut() : signOut())}>
        Sign out
      </button>
    </span>
  );
}
