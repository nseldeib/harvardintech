// The read-only view of one past version of an entry: a back/restore header, the
// revision's meta, and its raw markdown. "Restore this version" hands the raw
// content back to the parent (which loads it as unsaved edits) — the viewer
// itself neither fetches nor commits. Presentational; the parent owns the
// selected revision, its loading/error state, and the restore + back actions.
import { formatRevisionTime, type EntryRevision } from '../../lib/githubHistory';
import { historyPrimaryBtn, historyGhostBtn, historyErrorText } from './historyStyles';

interface Props {
  revision: EntryRevision;
  /** The entry's raw markdown at this revision; null while it is still loading. */
  raw: string | null;
  /** Set when the version's content failed to load. */
  error?: string;
  /** Optional so an Astro-hosted isolated scenario (which can't pass a function
   * prop) still renders; the real parent always supplies it. */
  onBack?: () => void;
  /** Restore this version — only meaningful once `raw` has loaded. */
  onRestore?: (raw: string) => void;
}

export default function RevisionViewer({ revision, raw, error, onBack, onRestore }: Props) {
  const when = formatRevisionTime(revision.date);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-md)' }}>
        <button type="button" style={historyGhostBtn} onClick={() => onBack?.()}>
          ← Back to history
        </button>
        <span style={{ marginLeft: 'auto' }}>
          <button
            type="button"
            style={{ ...historyPrimaryBtn, opacity: raw == null ? 0.5 : 1, cursor: raw == null ? 'wait' : 'pointer' }}
            disabled={raw == null}
            onClick={() => raw != null && onRestore?.(raw)}
          >
            Restore this version
          </button>
        </span>
      </div>

      <div>
        <strong style={{ fontSize: '0.95rem' }}>{revision.subject}</strong>
        <p style={{ margin: '0.15rem 0 0', fontSize: '0.82rem', color: 'var(--color-muted)' }}>
          {revision.authorName}
          {when ? ` · ${when}` : ''}
        </p>
      </div>

      {error ? (
        <p style={historyErrorText}>{error}</p>
      ) : raw == null ? (
        <p style={{ color: 'var(--color-muted)' }}>Loading this version…</p>
      ) : (
        <pre
          style={{
            margin: 0,
            padding: 'var(--space-md)',
            border: '1px solid var(--color-border)',
            borderRadius: 'var(--radius)',
            background: 'var(--color-surface)',
            fontFamily: 'var(--font-mono)',
            fontSize: '0.8rem',
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            maxHeight: '22rem',
            overflow: 'auto',
          }}
        >
          {raw}
        </pre>
      )}
    </div>
  );
}
