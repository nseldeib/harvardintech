// The admin search input, shared by the dashboard-wide search and the
// per-collection filter so both look and behave identically. Presentational and
// controlled — it owns no query state; the parent island holds the value and
// receives every keystroke via `onChange`. The inline clear button (shown only
// when there is text) calls `onChange('')`, the same reset the empty-results
// message triggers.
import type { CSSProperties } from 'react';

const wrapStyle: CSSProperties = { position: 'relative', marginBottom: 'var(--space-lg)' };

const inputStyle: CSSProperties = {
  width: '100%',
  padding: '0.6rem 2.2rem 0.6rem 0.75rem',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  font: 'inherit',
  background: 'var(--color-bg)',
  color: 'var(--color-fg)',
};

const clearStyle: CSSProperties = {
  position: 'absolute',
  right: '0.5rem',
  top: '50%',
  transform: 'translateY(-50%)',
  border: 'none',
  background: 'transparent',
  color: 'var(--color-muted)',
  cursor: 'pointer',
  fontSize: '1.25rem',
  lineHeight: 1,
  padding: '0.2rem 0.35rem',
};

interface Props {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  /** Accessible label for the search input. */
  ariaLabel: string;
}

export default function SearchBox({ value, onChange, placeholder, ariaLabel }: Props) {
  return (
    <div style={wrapStyle}>
      <input
        type="search"
        aria-label={ariaLabel}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        style={inputStyle}
      />
      {value !== '' && (
        <button type="button" aria-label="Clear search" onClick={() => onChange('')} style={clearStyle}>
          ×
        </button>
      )}
    </div>
  );
}
