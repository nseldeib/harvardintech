// The grouped review body of the Publish page: one ChangeGroup per area, in the
// order groupPendingChanges sorted them. Presentational + intent-forwarding —
// the parent PublishPage owns the staging set and the discard/commit phase; this
// just lays the groups out and applies the single-group auto-expand rule.
import type { ChangeGroup as ChangeGroupData } from '../../lib/pendingChanges';
import ChangeGroup from './ChangeGroup';

interface Props {
  groups: ChangeGroupData[];
  /** Disable per-entry discard while a commit is in flight. */
  committing: boolean;
  onDiscard: (path: string) => void;
}

export default function ChangeGroupList({ groups, committing, onDiscard }: Props) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-md)' }}>
      {groups.map((group) => (
        <ChangeGroup
          key={group.area}
          group={group}
          disabled={committing}
          onDiscard={onDiscard}
          defaultExpanded={groups.length === 1}
        />
      ))}
    </div>
  );
}
