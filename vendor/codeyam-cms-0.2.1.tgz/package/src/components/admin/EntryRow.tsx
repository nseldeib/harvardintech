// One interactive row in a collection's entry list.
//
// The label links into the entry editor; the right side (EntryRowActions) hosts
// the row actions — Archive / Unarchive (flip the publish flag) and Delete —
// each guarded by an inline Confirm / Cancel swap (no modal). Confirming stages
// a PendingChange into the shared browser store, so a row action rides the SAME
// review-and-commit drawer as an editor edit and stays undoable until commit.
// This island owns the store wiring: it subscribes so a staged action shows a
// badge + Undo here (and a deletion strikes the label through), and it builds
// the archive / unarchive / delete change from the entry's raw markdown.
import { useEffect, useState } from 'react';
import type { CollectionName } from '../../lib/adminDashboard';
import { entryContentPath } from '../../lib/entryEditor';
import { buildArchiveChange, buildUnarchiveChange, buildDeleteChange } from '../../lib/entryActions';
import type { ChangeKind } from '../../lib/pendingChanges';
import { loadChanges, stageChange, discardChange, subscribe } from '../../lib/pendingChangesStore';
import EntryRowActions, { type RowAction } from './EntryRowActions';

interface Props {
  collection: CollectionName;
  slug: string;
  href: string;
  label: string;
  /** True when the entry currently carries `draft: true`. */
  draft: boolean;
  /** The entry's raw markdown — source for the staged archive / delete change. */
  raw: string;
  /** The collection's resolved frontmatter key order (built-in core + consumer
   * extras + SEO), so an archive / delete re-serializes without reordering a
   * consumer-declared field. Omitted → the built-in `COLLECTION_FIELDS` order. */
  keyOrder?: string[];
}

const rowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 'var(--space-sm)',
  background: 'var(--color-bg)',
  border: '1px solid var(--color-border)',
  borderRadius: 'var(--radius)',
  padding: 'var(--space-md) var(--space-lg)',
};

export default function EntryRow({ collection, slug, href, label, draft, raw, keyOrder }: Props) {
  const path = entryContentPath(collection, slug);
  const [stagedKind, setStagedKind] = useState<ChangeKind | null>(null);
  const [confirming, setConfirming] = useState<RowAction | null>(null);

  // Reflect this row's staged action from the shared store (and cross-tab).
  useEffect(() => {
    const sync = () => setStagedKind(loadChanges().find((c) => c.path === path)?.kind ?? null);
    sync();
    return subscribe(sync);
  }, [path]);

  const stage = (action: RowAction) => {
    const change =
      action === 'delete'
        ? buildDeleteChange(collection, slug, raw, keyOrder)
        : action === 'archive'
          ? buildArchiveChange(collection, slug, raw, keyOrder)
          : buildUnarchiveChange(collection, slug, raw, keyOrder);
    stageChange(change);
    setConfirming(null);
  };

  return (
    <div style={rowStyle}>
      <a
        href={href}
        data-entry-row={draft ? 'draft' : 'published'}
        style={{
          fontWeight: 600,
          color: 'var(--color-fg)',
          textDecoration: stagedKind === 'delete' ? 'line-through' : 'none',
          opacity: stagedKind ? 0.6 : 1,
        }}
      >
        {label}
      </a>

      <EntryRowActions
        draft={draft}
        stagedKind={stagedKind}
        confirming={confirming}
        onRequest={setConfirming}
        onConfirm={() => confirming && stage(confirming)}
        onCancel={() => setConfirming(null)}
        onUndo={() => discardChange(path)}
      />
    </div>
  );
}
