// The day-one empty state for the /admin/editors roster: shown when no one has
// been invited yet (the production default before the first invite). Nudges the
// owner toward inviting their first teammate and reassures that editors need no
// GitHub account. The React counterpart of the other admin empty states
// (EntryListEmpty, MediaLibraryEmpty), so it can live inside the EditorsManager
// island.
export default function EditorsEmpty() {
  return (
    <p style={{ color: 'var(--color-muted)', fontSize: '0.9rem', margin: 0 }}>
      No editors yet. Invite your first teammate above — they’ll sign in with a secure email
      link, no GitHub account required.
    </p>
  );
}
