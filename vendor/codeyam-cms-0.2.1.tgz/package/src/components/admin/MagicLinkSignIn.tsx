// The editor-facing magic-link sign-in — the GitHub-invisible entry an invited,
// non-technical editor walks through. It renders one of five states
// (landing → link-sent → signing-in → welcome, or expired) using the copy from
// the pure `magicLink` helpers, so no GitHub / commit / branch vocabulary ever
// appears. On the landing screen the editor submits their email and we move to
// "check your email"; the signing-in / welcome / expired states are what they
// see after clicking the emailed link.
//
// `initialStatus` / `initialEmail` are scenario/test seams: an injected status
// renders that fixed state for isolated-component capture instead of starting a
// live flow. The actual link delivery + token minting are the broker's job
// (mocked this cycle) — this component owns only the experience.
import { useState } from 'react';
import {
  describeMagicLink,
  isBusy,
  submitEmail,
  type MagicLinkStatus,
} from '../../lib/magicLink';
import {
  errorNote,
  gateCard,
  gateOverlay,
  gateSubtitle,
  gateTitle,
  signInBtn,
  tokenForm,
  tokenInput,
  tokenLabel,
} from './authStyles';
import { magicBody, magicMark, magicSecondaryBtn, magicSpinner } from './editorsStyles';

interface Props {
  /** The site being edited, e.g. "Harvard in Tech" — named in the copy. */
  siteTitle: string;
  /** Scenario/test seam: render this fixed state instead of starting at landing. */
  initialStatus?: MagicLinkStatus;
  /** Scenario/test seam: pre-fill the email (e.g. the "link sent" confirmation). */
  initialEmail?: string;
}

export default function MagicLinkSignIn({ siteTitle, initialStatus, initialEmail }: Props) {
  const [status, setStatus] = useState<MagicLinkStatus>(initialStatus ?? 'landing');
  const [email, setEmail] = useState(initialEmail ?? '');
  const [error, setError] = useState('');

  const copy = describeMagicLink(status, { siteTitle, email });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = submitEmail(email);
    if (result.error) {
      setError(result.error);
      return;
    }
    setError('');
    setStatus(result.status);
  };

  const requestNewLink = () => {
    setError('');
    setStatus('landing');
  };

  return (
    <div style={gateOverlay} role="dialog" aria-modal="true" aria-label={`Sign in to ${siteTitle}`}>
      <style>{`@keyframes codeyam-spin { to { transform: rotate(360deg); } }`}</style>
      <div style={gateCard}>
        {status === 'signing-in' || status === 'welcome' ? (
          <div style={magicSpinner} aria-hidden="true" />
        ) : (
          <span style={magicMark} aria-hidden="true">
            ✉️
          </span>
        )}

        <h1 style={gateTitle}>{copy.title}</h1>
        <p style={status === 'landing' ? gateSubtitle : magicBody}>{copy.body}</p>

        {status === 'landing' && (
          <form style={tokenForm} onSubmit={onSubmit} noValidate>
            <label style={tokenLabel} htmlFor="magic-email">
              Your email
            </label>
            <input
              id="magic-email"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError('');
              }}
              placeholder="you@example.com"
              style={{ ...tokenInput, fontFamily: 'inherit' }}
            />
            <button type="submit" style={signInBtn}>
              Send my sign-in link
            </button>
            {error && <p style={errorNote}>{error}</p>}
          </form>
        )}

        {status === 'link-sent' && (
          <button type="button" style={magicSecondaryBtn} onClick={requestNewLink}>
            Use a different email
          </button>
        )}

        {status === 'expired' && (
          <button type="button" style={signInBtn} onClick={requestNewLink} disabled={isBusy(status)}>
            Send me a new link
          </button>
        )}
      </div>
    </div>
  );
}
