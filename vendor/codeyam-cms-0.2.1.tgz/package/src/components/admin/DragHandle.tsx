// The braille-dots grip a reorderable list row is grabbed by. Presentational: it
// renders the ⠿ affordance and forwards the pointer handlers that arm the row's
// native drag (see `useListDrag`). Sits beside the ↑/↓ RowControls so a row can
// be reordered by drag OR by keyboard — the drag is the fast path, the buttons
// the accessible one.
import type { HTMLAttributes } from 'react';
import { dragHandleStyle } from './configEditorStyles';

interface Props extends HTMLAttributes<HTMLSpanElement> {
  /** Accessible label, e.g. "Drag to reorder social link". */
  label: string;
}

export default function DragHandle({ label, style, ...rest }: Props) {
  return (
    <span
      role="button"
      aria-label={label}
      title="Drag to reorder"
      {...rest}
      style={{ ...dragHandleStyle, ...style }}
    >
      ⠿
    </span>
  );
}
