// The Publish page's resting state: shown whenever there is nothing staged to
// publish. Unlike the floating StagingBar (which simply hides when the staging
// set is empty), the Publish page is always reachable, so at rest it reassures
// the editor that the site is up to date AND surfaces the last successful
// deploy — when it landed, the commit it published, and a link to the live
// site. Presentational: the parent PublishPage owns fetching the last deploy
// and feeds it down.
import type { RepoTarget } from '../../lib/githubCommit';
import { pagesSiteUrl, formatDeployTime, type LastDeploy } from '../../lib/githubPages';
import { linkBtn, liveLinkBtn } from './stagingStyles';

interface Props {
  repo: RepoTarget;
  /** The most recent deploy, or `null` when the site has never been deployed. */
  lastDeploy?: LastDeploy | null;
  /** True while the last-deploy lookup is still in flight. */
  loading?: boolean;
}

export default function PublishEmptyState({ repo, lastDeploy, loading }: Props) {
  const when = formatDeployTime(lastDeploy?.when);
  const failed = lastDeploy?.stage === 'failed';
  const siteUrl = lastDeploy?.siteUrl || pagesSiteUrl(repo);

  return (
    <div
      style={{
        border: '1px solid var(--color-border)',
        borderRadius: 'var(--radius)',
        background: 'var(--color-bg)',
        padding: 'var(--space-xl, 2rem) var(--space-lg)',
        textAlign: 'center',
      }}
    >
      <div style={{ fontSize: '2.25rem', lineHeight: 1, marginBottom: 'var(--space-md)' }} aria-hidden="true">
        {failed ? '⚠️' : '✓'}
      </div>
      <h2 style={{ margin: '0 0 var(--space-sm)', fontSize: '1.25rem' }}>
        {failed ? 'Nothing to publish' : "You're all caught up"}
      </h2>
      <p style={{ margin: '0 0 var(--space-lg)', color: 'var(--color-muted)' }}>
        No changes to publish — every edit is already committed to{' '}
        <strong>
          {repo.owner}/{repo.repo}
        </strong>{' '}
        on <strong>{repo.branch}</strong>.
      </p>

      <div
        style={{
          borderTop: '1px solid var(--color-border)',
          paddingTop: 'var(--space-lg)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 'var(--space-sm)',
        }}
      >
        {loading ? (
          <span style={{ color: 'var(--color-muted)', fontSize: '0.85rem' }}>Checking the last deploy…</span>
        ) : !lastDeploy ? (
          <span style={{ color: 'var(--color-muted)', fontSize: '0.85rem' }}>
            No deploys yet — publish your first change to take the site live.
          </span>
        ) : (
          <>
            <span style={{ fontSize: '0.85rem', color: 'var(--color-muted)' }}>
              {failed ? 'Last build failed' : 'Last published'}
              {when ? ` · ${when}` : ''}
            </span>
            {lastDeploy.commitUrl && (
              <a href={lastDeploy.commitUrl} target="_blank" rel="noreferrer" style={linkBtn}>
                View last commit
              </a>
            )}
          </>
        )}
        <a href={siteUrl} target="_blank" rel="noreferrer" style={{ ...liveLinkBtn, marginTop: 'var(--space-sm)' }}>
          View live site →
        </a>
      </div>
    </div>
  );
}
