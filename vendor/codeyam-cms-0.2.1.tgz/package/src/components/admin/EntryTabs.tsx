// The Edit / History toggle at the top of the entry editor. Presentational — the
// parent (EntryEditor) owns the `tab` state — so it stays a thin, consistent
// switch, mirroring SplitTabs. Edit shows the editor + preview; History shows
// this entry's git version history.

interface Props {
  tab: 'edit' | 'history';
  /** Optional so an Astro-hosted isolated scenario (which can't pass a function
   * prop) still renders; the real parent always supplies it. */
  onChange?: (tab: 'edit' | 'history') => void;
}

const TABS: { id: 'edit' | 'history'; label: string }[] = [
  { id: 'edit', label: 'Edit' },
  { id: 'history', label: 'History' },
];

export default function EntryTabs({ tab, onChange }: Props) {
  return (
    <div
      role="tablist"
      style={{ display: 'flex', gap: 'var(--space-sm)', borderBottom: '1px solid var(--color-border)' }}
    >
      {TABS.map((t) => (
        <button
          key={t.id}
          type="button"
          role="tab"
          aria-selected={tab === t.id}
          onClick={() => onChange?.(t.id)}
          style={{
            padding: '0.5rem 0.9rem',
            border: 'none',
            borderBottom: `2px solid ${tab === t.id ? 'var(--color-accent)' : 'transparent'}`,
            background: 'transparent',
            color: tab === t.id ? 'var(--color-fg)' : 'var(--color-muted)',
            fontWeight: 600,
            cursor: 'pointer',
            marginBottom: '-1px',
          }}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
