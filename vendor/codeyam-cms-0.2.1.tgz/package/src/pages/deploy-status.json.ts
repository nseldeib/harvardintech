// The deploy marker: a tiny prerendered file stamped with the commit the site
// was built from.
//
// It exists because the GitHub Pages API cannot answer the question the editor
// actually asks. The builds endpoint reports `built` when GitHub finished
// building — not when the CDN started serving the result — so "Live" based on
// that alone can point an editor at bytes that are still the old page. The
// deployed site is the only witness to its own contents, and this is how we ask
// it: when the *served* value of this file changes, the new build is genuinely
// being served, by construction.
//
// Deliberately public and auth-free. It carries nothing sensitive (a commit SHA
// that is already public on a public repo, and a run id), and the editor must be
// able to read it as an anonymous visitor of the deployed site — the same way a
// reader would — or it would be verifying something other than what readers get.
//
// Prerendered, so the value is baked at build time and is a property of THIS
// build. Rendering it on demand would defeat the purpose: it would report
// whatever the server knows now rather than what this deployment contains.
// The payload itself is built by `buildDeployMarker` — which variables are read
// and what an unset one becomes is testable logic, and it cannot be reached by a
// test from inside an APIRoute. This file is left with only the HTTP concern.
import type { APIRoute } from 'astro';
import { buildDeployMarker, readBuildStampEnv } from '../lib/buildEnv';

export const prerender = true;

export const GET: APIRoute = () =>
  new Response(JSON.stringify(buildDeployMarker(readBuildStampEnv(), new Date())), {
    headers: {
      'Content-Type': 'application/json',
      // Advisory only — a CDN may ignore it, which is exactly why the reader
      // also cache-busts with a query parameter.
      'Cache-Control': 'no-cache, no-store, must-revalidate',
    },
  });
