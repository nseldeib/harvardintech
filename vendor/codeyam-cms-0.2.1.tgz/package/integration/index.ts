// The @codeyam/cms Astro integration.
//
// Adding `codeyamCms()` to a consumer's `astro.config.mjs` `integrations: []`
// is what turns a plain Astro project into a CMS-enabled one: it injects the
// `/admin` dashboard routes straight from inside `node_modules/@codeyam/cms`,
// so the consumer gets the whole editor without copying a single admin file into
// their repo — and picks up fixes via `npm update`. The only things a consumer
// owns are the editable config files (`src/data/cms.json`,
// `src/data/collections.json`) the CLI drops in, and their own content
// collections.
//
// Routes are injected by PACKAGE SPECIFIER (`@codeyam/cms/pages/admin/…`)
// rather than by absolute path. Astro's `resolveInjectedRoute` calls
// `require.resolve`, which realpaths through symlinks — and an absolute path
// realpaths under *every* setting. Only the specifier form keeps the resolved
// entrypoint inside `node_modules/@codeyam/cms`, so this workspace-linked
// dogfood repo resolves the CMS exactly the way an npm-installed consumer does.
// That matters beyond fidelity: when the entrypoint realpaths out to
// `packages/cms/src/…`, every island Astro emits from it carries a
// `component-url` on that same prefix, which the editor's same-origin preview
// proxy does not forward — so the dynamic import 404s and no admin island
// hydrates in the Live Preview.
//
// The package's `exports` map is what makes this resolve: its one `"./pages/*"`
// wildcard covers all ten `ADMIN_ROUTES` patterns below. Two companion settings
// keep the rest of the graph on the same path — `--preserve-symlinks` in the
// root `dev`/`build` scripts (governs this `require.resolve`) and Vite's
// `resolve.preserveSymlinks` in `astro.config.mjs` (governs every import made
// *from* this entrypoint). Changing one without the others splits the module
// graph across both paths.
import type { AstroIntegration } from 'astro';

export interface CodeyamCmsOptions {
  /**
   * URL segment the dashboard mounts under. Defaults to `admin`, giving
   * `/admin`, `/admin/settings`, `/admin/[collection]`, etc. Set this to move
   * the whole dashboard (e.g. `cms` → `/cms`).
   */
  route?: string;
  /**
   * Whether to auto-register the `@astrojs/react` renderer if the consumer has
   * not added it themselves. The admin dashboard is built from React islands, so
   * a renderer must be present. Defaults to `true`. Set `false` if you manage
   * the React integration yourself (e.g. with custom Babel options).
   */
  ensureReactRenderer?: boolean;
}

/**
 * The admin dashboard's route map: each public URL pattern (relative to the
 * configured `route` base) paired with the package file that renders it. Kept as
 * data so the base segment is applied uniformly and the list mirrors the files
 * under `src/pages/admin/`.
 */
const ADMIN_ROUTES: Array<{ pattern: string; file: string }> = [
  { pattern: '', file: 'index.astro' },
  { pattern: 'settings', file: 'settings.astro' },
  { pattern: 'editors', file: 'editors.astro' },
  { pattern: 'publish', file: 'publish.astro' },
  { pattern: 'media', file: 'media/index.astro' },
  { pattern: 'new', file: 'new/index.astro' },
  { pattern: 'new/[collection]', file: 'new/[collection].astro' },
  { pattern: 'collections/new', file: 'collections/new.astro' },
  { pattern: '[collection]', file: '[collection]/index.astro' },
  { pattern: '[collection]/[entry]', file: '[collection]/[entry].astro' },
];

/**
 * The argument Astro hands the `astro:config:setup` hook. Derived from the
 * integration type rather than re-declared so the helpers below stay in step
 * with Astro's own signature instead of drifting from a hand-written copy.
 */
type SetupParams = Parameters<NonNullable<AstroIntegration['hooks']['astro:config:setup']>>[0];

/**
 * Normalize the caller's `route` option into a bare URL segment: default to
 * `admin`, and strip any leading/trailing slashes so `/cms/`, `cms`, and `/cms`
 * all mount the dashboard at the same place. Callers concatenate this into
 * patterns, so a stray slash here would produce `//cms` routes.
 */
export function normalizeRouteBase(route?: string): string {
  return (route ?? 'admin').replace(/^\/+|\/+$/g, '');
}

/**
 * Build the public URL pattern for one admin route under `base`. The dashboard
 * root is stored as an empty pattern, which must collapse to `/${base}` rather
 * than a trailing-slash `/${base}/`.
 */
export function adminRoutePattern(base: string, pattern: string): string {
  return pattern ? `/${base}/${pattern}` : `/${base}`;
}

/**
 * Build the entrypoint Astro resolves for one admin route.
 *
 * This must stay a PACKAGE SPECIFIER. Astro resolves injected entrypoints with
 * `require.resolve`, which realpaths an absolute path straight through the
 * workspace symlink to `packages/cms/src/…` — and every island rendered from
 * that entrypoint then carries a `component-url` on the same prefix, which the
 * editor's preview proxy does not forward, so no admin island hydrates. The
 * specifier form keeps resolution inside `node_modules/@codeyam/cms`, which
 * the proxy serves. The package's `exports` map publishes `"./pages/*"`, so this
 * resolves for npm-installed consumers too.
 */
export function adminRouteEntrypoint(file: string): string {
  return `@codeyam/cms/pages/admin/${file}`;
}

/** Mount every admin route under the configured base segment. */
export function injectAdminRoutes(injectRoute: SetupParams['injectRoute'], base: string): void {
  for (const { pattern, file } of ADMIN_ROUTES) {
    injectRoute({
      pattern: adminRoutePattern(base, pattern),
      entrypoint: adminRouteEntrypoint(file),
    });
  }
}

/** Public URL of the deploy marker. NOT under the admin base — see below. */
export const DEPLOY_MARKER_PATTERN = '/deploy-status.json';

/** Package entrypoint for the marker route, in the same specifier form the admin routes use. */
export const DEPLOY_MARKER_ENTRYPOINT = '@codeyam/cms/pages/deploy-status.json.ts';

/**
 * Mount the deploy marker at the site root.
 *
 * Injected by the integration rather than dropped into the consumer's repo by
 * the CLI for the same reason the admin routes are: the capability then arrives
 * with `npm update` instead of requiring every existing consumer to re-run
 * `integrate` before their deploy stepper can tell them the truth.
 *
 * Two properties are deliberate:
 *
 * - **Not under `adminRoutePattern`.** The editor reads this file as an
 *   anonymous visitor of the deployed site, so it must be public and auth-free.
 *   Mounting it under the admin base would put it behind the dashboard and it
 *   could no longer witness what a reader is actually served.
 * - **Consumer files win.** A consumer that already defines its own
 *   `src/pages/deploy-status.json.ts` keeps it: Astro gives a file-based route
 *   precedence over an injected one, so this cannot clobber a hand-rolled marker
 *   or produce a duplicate-route error. Their marker only has to carry a
 *   `commit` that changes per build for the check to work against it.
 */
export function injectDeployMarkerRoute(injectRoute: SetupParams['injectRoute']): void {
  injectRoute({
    pattern: DEPLOY_MARKER_PATTERN,
    entrypoint: DEPLOY_MARKER_ENTRYPOINT,
  });
}

/**
 * Ensure a React renderer is registered. The dashboard is built from React
 * islands, so one must be present. If the consumer already added
 * `@astrojs/react` we leave it be; otherwise we add it so the dashboard works
 * out of the box, degrading to an actionable warning when the package is not
 * installed at all.
 */
export async function registerReactRenderer(
  config: SetupParams['config'],
  updateConfig: SetupParams['updateConfig'],
  logger: SetupParams['logger'],
): Promise<void> {
  const hasReact = config.integrations.some((i) => i.name === '@astrojs/react');
  if (hasReact) return;

  try {
    const react = (await import('@astrojs/react')).default;
    updateConfig({ integrations: [react()] });
    logger.info('Added @astrojs/react (required by the CMS admin islands).');
  } catch {
    logger.warn(
      'The CMS admin dashboard needs @astrojs/react. Install it and add react() to your astro.config integrations, or run `npx codeyam-cms integrate`.',
    );
  }
}

/**
 * The @codeyam/cms Astro integration factory. Drop `codeyamCms()` into your
 * `astro.config.mjs` integrations to mount the CMS dashboard.
 */
export default function codeyamCms(options: CodeyamCmsOptions = {}): AstroIntegration {
  const base = normalizeRouteBase(options.route);
  const ensureReactRenderer = options.ensureReactRenderer ?? true;

  return {
    name: '@codeyam/cms',
    hooks: {
      'astro:config:setup': async ({ injectRoute, config, updateConfig, logger }) => {
        injectAdminRoutes(injectRoute, base);
        injectDeployMarkerRoute(injectRoute);
        if (ensureReactRenderer) {
          await registerReactRenderer(config, updateConfig, logger);
        }
        logger.info(`CMS dashboard mounted at /${base}`);
      },
    },
  };
}
