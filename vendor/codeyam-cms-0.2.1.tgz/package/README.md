# @codeyam/cms

An installable, Git-backed CMS for [Astro](https://astro.build) sites. Install
one package, run one command, and your project gets a `/admin` content dashboard
that commits changes straight to your GitHub repo — perfect for **static sites on
GitHub Pages**, and equally at home on server-rendered Astro.

Unlike a starter template you copy once and own forever, this is a real
dependency: the admin dashboard is injected from `node_modules` by an Astro
integration, so you pick up improvements with `npm update` instead of
re-merging files by hand.

## Install

```bash
npm install @codeyam/cms
npx codeyam-cms integrate
```

`integrate` wires the CMS into the Astro project in the current directory. It is
idempotent — safe to run again any time.

What it does:

1. Confirms you're in an Astro project (bails cleanly if not).
2. Adds `@codeyam/cms` and `@astrojs/react` to your dependencies.
3. Pushes `codeyamCms()` into your `astro.config` `integrations: []`.
4. Drops the two editable config files the CMS reads:
   - `src/data/cms.json` — which GitHub repo/branch to commit to, and how sign-in works.
   - `src/data/collections.json` — your custom collection registry.
5. Prints next steps.

Options:

| Flag | Effect |
| --- | --- |
| `--with-auth-worker` | Also scaffold `cms-auth-worker/` — a Cloudflare Worker OAuth relay for "Sign in with GitHub". |
| `--with-sveltia` | Also scaffold `public/admin/` — the Decap/Sveltia editor bridge. |

## Configure

Open `src/data/cms.json` and point it at your repo:

```json
{
  "repo": { "owner": "your-org", "repo": "your-site", "branch": "main" },
  "authEndpoint": "/auth",
  "auth": { "token": true, "worker": false }
}
```

With `auth.token: true` (the default, zero-infrastructure path) an editor pastes
a GitHub token to sign in — nothing to deploy. Turn on `auth.worker` and deploy
the `cms-auth-worker` for a "Sign in with GitHub" popup instead. Both can be on.

Start your dev server and open **`/admin`**.

## Manual setup (without the CLI)

`astro.config.mjs`:

```js
import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import codeyamCms from '@codeyam/cms';

export default defineConfig({
  integrations: [react(), codeyamCms()],
});
```

`codeyamCms()` options:

| Option | Default | Meaning |
| --- | --- | --- |
| `route` | `'admin'` | URL segment the dashboard mounts under (`/admin`, `/admin/settings`, …). Set to `'cms'` for `/cms`. |
| `ensureReactRenderer` | `true` | Auto-register `@astrojs/react` if you haven't. Set `false` to manage React yourself. |

## Content collections

Define your own collections in `src/content/config.ts`, built from the package's
shared SEO fields and sandbox-aware loader so the CMS knows how to edit them:

```ts
import { defineCollection, z } from 'astro:content';
import { seoFields, draftField, collectionLoader } from '@codeyam/cms/content';

const blog = defineCollection({
  loader: collectionLoader('blog'),
  schema: z.object({
    title: z.string(),
    date: z.coerce.date(),
    ...draftField,
    ...seoFields,
  }),
});

export const collections = { blog };
```

### Drafts

Every collection carries a **Draft** toggle in the editor, which writes
`draft: true` into the entry's frontmatter. Declaring `...draftField` in your
schema is what lets that flag reach your pages — a Zod object *strips* keys it
does not declare, so a schema without it drops `draft` silently and the toggle
has no effect on your site, with no build error to tell you. (Passing such a
collection to `publishedEntries` is a *type* error, so once you filter, a
forgotten `draftField` surfaces at compile time rather than in production.)

Declaring the field only preserves the flag. To act on it, filter with
`publishedEntries`, which hides drafts in a production build and keeps them
visible under `astro dev` so they stay previewable:

```astro
---
import { getCollection } from 'astro:content';
import { publishedEntries } from '@codeyam/cms/content';

const posts = publishedEntries(await getCollection('blog'));
---
```

**Filter your dynamic routes too.** Hiding a draft from a listing while
`getStaticPaths` still generates its page leaves the entry publicly reachable at
its own URL — hidden from navigation but not private, which looks like working
draft support and is arguably worse than none:

```ts
export async function getStaticPaths() {
  const posts = publishedEntries(await getCollection('blog'));
  return posts.map((post) => ({ params: { slug: post.id }, props: { post } }));
}
```

Pass `{ includeDrafts: false }` to hide drafts everywhere including dev, or
`{ includeDrafts: true }` to show them everywhere.

**Absent means published.** The CMS writes `draft: true` when the toggle is on
and removes the key entirely when it is off — it never writes `draft: false`. An
entry with no `draft` key is live, so adopting this field changes nothing about
the content your site already has.

### Extending the built-in collections

The four built-in collections (`pages` / `blog` / `events` / `team`) expose a
fixed set of editable fields. If your site's frontmatter carries extra keys — a
`blog.embedUrl`, a `team.active` toggle — declare them in
`src/data/collections.json` so the dashboard edits them instead of merely
preserving them. Extras are appended after the collection's core fields and
before the SEO group; declaring none keeps today's behavior exactly.

```jsonc
{
  "collections": [],
  "builtins": {
    "blog": [
      { "name": "embedUrl", "label": "Embed URL", "type": "text", "optional": true },
      { "name": "embedHtml", "label": "Embed HTML", "type": "textarea", "optional": true }
    ],
    "team": [
      { "name": "active", "label": "Active", "type": "boolean" }
    ]
  }
}
```

Field `type` is one of `text` · `textarea` · `date` · `image` · `boolean` ·
`list` (see [Repeatable list fields](#repeatable-list-fields)). An extra whose
`name` collides with a core field, the SEO group, or a reserved key (`draft`,
`body`, `slug`, `id`) is ignored.

### Redefining the SEO group

The universal SEO & Social panel defaults to
`seoTitle` / `seoDescription` / `socialImage` / `canonicalUrl`. If your content
uses different keys, add a `seo` section — it replaces the default group across
every collection. The `name`s must match the keys in your `seoFields` schema.

```jsonc
{
  "collections": [],
  "seo": [
    { "name": "metaTitle", "label": "Meta title", "type": "text", "optional": true },
    { "name": "metaDescription", "label": "Meta description", "type": "textarea", "optional": true },
    { "name": "ogImage", "label": "Social image", "type": "image", "optional": true }
  ]
}
```

### Repeatable list fields

A `list` field is a repeatable group of scalar sub-fields, edited in the
dashboard as add / remove / reorder rows. It's what lets a collection hold
structured, repeating content — a chapter's `leads` (each a `name` + `role`) or
its `links` (each a `label` + `url`) — and round-trips to an array-of-objects in
the entry's frontmatter. List fields work in a custom collection or as a built-in
extra; register the collection in `src/data/collections.json`:

```jsonc
{
  "collections": [
    {
      "id": "chapters",
      "label": "Chapters",
      "singular": "chapter",
      "fields": [
        { "name": "title", "label": "Title", "type": "text" },
        {
          "name": "leads",
          "label": "Leads",
          "type": "list",
          "fields": [
            { "name": "name", "label": "Name", "type": "text" },
            { "name": "role", "label": "Role", "type": "text" }
          ]
        },
        {
          "name": "links",
          "label": "Links",
          "type": "list",
          "fields": [
            { "name": "label", "label": "Label", "type": "text" },
            { "name": "url", "label": "URL", "type": "text" }
          ]
        }
      ]
    }
  ]
}
```

A `chapters` entry then edits as:

```yaml
---
title: Chapter 3 — Building for the Web
leads:
  - name: Dr. Amara Osei
    role: Faculty lead
  - name: Jonah Feld
    role: Student coordinator
links:
  - label: Syllabus
    url: https://intech.harvard.edu/ch3/syllabus
---
```

A list's `fields` are **scalar only** (`text` · `textarea` · `date` · `image` ·
`boolean` · `number`) — nested lists are not supported, matching the two-level
cap of the frontmatter engine. An empty list serializes to `key: []`, and a row
left wholly blank is dropped on save. You can also add a list field from the
**Create collection** builder in the dashboard: pick the *Repeatable list* type
and define its sub-fields inline.

## Advanced: import the engine directly

The headless content engine is exported for consumers who want the logic without
the full dashboard:

```ts
import { parseFrontmatter } from '@codeyam/cms/lib/frontmatter';
import { loadCmsConfig } from '@codeyam/cms/lib/cmsConfig';
```

Admin React components and the theme are exported too
(`@codeyam/cms/components/admin/StagingBar.tsx`,
`@codeyam/cms/styles/tokens.css`) for advanced composition.

## How it ships

The package ships **source** (`.astro`, `.tsx`, `.ts`) — your Astro/Vite build
compiles it alongside your own code, which is how the integration can own routes
and islands from inside `node_modules`. The CLI is plain Node with no build step.

## License

MIT
